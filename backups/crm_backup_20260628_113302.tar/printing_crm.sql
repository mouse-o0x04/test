-- CRM Backup — 2026-06-28T11:33:02.031935
-- Database: printing_crm

DROP TABLE IF EXISTS ai_provider_settings CASCADE;
CREATE TABLE ai_provider_settings (
  id integer NOT NULL,
  provider_name character varying(100) NOT NULL,
  base_url character varying(500) NOT NULL,
  api_key character varying(500),
  model_name character varying(255) NOT NULL,
  temperature double precision NOT NULL,
  max_tokens integer NOT NULL,
  system_prompt text,
  is_active boolean NOT NULL,
  created_at timestamp with time zone NOT NULL DEFAULT now(),
  updated_at timestamp with time zone NOT NULL DEFAULT now(),
  PRIMARY KEY (id)
);
INSERT INTO ai_provider_settings (id, provider_name, base_url, api_key, model_name, temperature, max_tokens, system_prompt, is_active, created_at, updated_at) VALUES (1, 'llamacpp', 'http://192.168.1.119:8081', NULL, 'local-model', 0.7, 4096, NULL, TRUE, '2026-06-23T21:09:08+00:00', '2026-06-24T12:39:28+00:00');

DROP TABLE IF EXISTS audit_log CASCADE;
CREATE TABLE audit_log (
  id integer NOT NULL,
  entity_type character varying(50) NOT NULL,
  entity_id integer NOT NULL,
  action character varying(50) NOT NULL,
  old_data text,
  new_data text,
  user_id integer,
  user_name character varying(255),
  created_at timestamp with time zone NOT NULL DEFAULT now(),
  PRIMARY KEY (id)
);
INSERT INTO audit_log (id, entity_type, entity_id, action, old_data, new_data, user_id, user_name, created_at) VALUES (1, 'product', 21, 'update', '{"id": 21, "name": "Светоотражающая сумка для шопинга «Neo Reflector» с ремувкой под нанесение", "description": "Светоотражающая сумка для шопинга с ремувкой под нанесение, серый светоотражающий, темно-синий. Вес 118 г, производство Китай. Материал: полиэстер, металл. Размер: 38 х 42 х 0,4 см. В набор входит ремувка. ", "unit_price": 753.0, "unit_type": "piece", "category": "Рефлектор", "formula": null, "formula_script": null, "raw_material_id": null, "material_coefficient": 1.0, "supplier_url": "https://www.oasiscatalog.com/item/1-000116758", "created_at": "2026-06-24 12:44:20+00:00"}', '{"id": 21, "name": "Светоотражающая сумка для шопинга «Neo Reflector» с ремувкой под нанесение", "description": "Светоотражающая сумка для шопинга с ремувкой под нанесение, серый светоотражающий, темно-синий. Вес 118 г, производство Китай. Материал: полиэстер, металл. Размер: 38 х 42 х 0,4 см. В набор входит ремувка. ", "unit_price": 999.0, "unit_type": "piece", "category": "Рефлектор", "formula": null, "formula_script": null, "raw_material_id": null, "material_coefficient": 1.0, "supplier_url": "https://www.oasiscatalog.com/item/1-000116758", "created_at": "2026-06-24 12:44:20+00:00"}', 1, 'Administrator', '2026-06-28T07:40:31.749104+00:00');
INSERT INTO audit_log (id, entity_type, entity_id, action, old_data, new_data, user_id, user_name, created_at) VALUES (2, 'product', 21, 'update', '{"id": 21, "name": "Светоотражающая сумка для шопинга «Neo Reflector» с ремувкой под нанесение", "description": "Светоотражающая сумка для шопинга с ремувкой под нанесение, серый светоотражающий, темно-синий. Вес 118 г, производство Китай. Материал: полиэстер, металл. Размер: 38 х 42 х 0,4 см. В набор входит ремувка. ", "unit_price": 999.0, "unit_type": "piece", "category": "Рефлектор", "formula": null, "formula_script": null, "raw_material_id": null, "material_coefficient": 1.0, "supplier_url": "https://www.oasiscatalog.com/item/1-000116758", "created_at": "2026-06-24 12:44:20+00:00"}', '{"id": 21, "name": "Светоотражающая сумка для шопинга «Neo Reflector» с ремувкой под нанесение", "description": "Светоотражающая сумка для шопинга с ремувкой под нанесение, серый светоотражающий, темно-синий. Вес 118 г, производство Китай. Материал: полиэстер, металл. Размер: 38 х 42 х 0,4 см. В набор входит ремувка. ", "unit_price": 753.0, "unit_type": "piece", "category": "Рефлектор", "formula": null, "formula_script": null, "raw_material_id": null, "material_coefficient": 1.0, "supplier_url": "https://www.oasiscatalog.com/item/1-000116758", "created_at": "2026-06-24 12:44:20+00:00"}', 1, 'Administrator', '2026-06-28T07:42:06.783839+00:00');
INSERT INTO audit_log (id, entity_type, entity_id, action, old_data, new_data, user_id, user_name, created_at) VALUES (3, 'raw_material', 1, 'update', '{"id": 1, "name": "банер 1.6", "description": null, "width_mm": null, "height_mm": null, "roll_width_m": 1.6, "roll_length_m": 50.0, "density": null, "color_finish": null, "unit_type": "piece", "unit_price": 92.0, "display_format_script": null, "stock_calculation_script": null, "created_at": "2026-06-27 11:01:34.682754+00:00"}', '{"id": 1, "name": "банер 1.6", "description": "тест аудита", "width_mm": null, "height_mm": null, "roll_width_m": 1.6, "roll_length_m": 50.0, "density": null, "color_finish": null, "unit_type": "piece", "unit_price": 92.0, "display_format_script": null, "stock_calculation_script": null, "created_at": "2026-06-27 11:01:34.682754+00:00"}', 1, 'Administrator', '2026-06-28T07:54:00.873183+00:00');
INSERT INTO audit_log (id, entity_type, entity_id, action, old_data, new_data, user_id, user_name, created_at) VALUES (4, 'raw_material', 1, 'update', '{"id": 1, "name": "банер 1.6", "description": "тест аудита", "width_mm": null, "height_mm": null, "roll_width_m": 1.6, "roll_length_m": 50.0, "density": null, "color_finish": null, "unit_type": "piece", "unit_price": 92.0, "display_format_script": null, "stock_calculation_script": null, "created_at": "2026-06-27 11:01:34.682754+00:00"}', '{"id": 1, "name": "банер 1.6", "description": null, "width_mm": null, "height_mm": null, "roll_width_m": 1.6, "roll_length_m": 50.0, "density": null, "color_finish": null, "unit_type": "piece", "unit_price": 92.0, "display_format_script": null, "stock_calculation_script": null, "created_at": "2026-06-27 11:01:34.682754+00:00"}', 1, 'Administrator', '2026-06-28T07:54:11.754267+00:00');
INSERT INTO audit_log (id, entity_type, entity_id, action, old_data, new_data, user_id, user_name, created_at) VALUES (5, 'warehouse', 23, 'update', '{"id": 23, "product_id": null, "raw_material_id": 2, "quantity": 497.5, "min_quantity": 100, "defective_quantity": 0, "defective_reason": "", "stock_calculation_script": "sheet_stock_calc", "display_format_script": null, "updated_at": "2026-06-27 19:31:26.241786+00:00"}', '{"id": 23, "product_id": null, "raw_material_id": 2, "quantity": 500.0, "min_quantity": 100, "defective_quantity": 0, "defective_reason": "", "stock_calculation_script": "sheet_stock_calc", "display_format_script": null, "updated_at": "2026-06-27 19:31:26.241786+00:00"}', 1, 'Administrator', '2026-06-28T08:11:50.809858+00:00');
INSERT INTO audit_log (id, entity_type, entity_id, action, old_data, new_data, user_id, user_name, created_at) VALUES (6, 'product', 21, 'update', '{"id": 21, "name": "Светоотражающая сумка для шопинга «Neo Reflector» с ремувкой под нанесение", "description": "Светоотражающая сумка для шопинга с ремувкой под нанесение, серый светоотражающий, темно-синий. Вес 118 г, производство Китай. Материал: полиэстер, металл. Размер: 38 х 42 х 0,4 см. В набор входит ремувка. ", "unit_price": 753.0, "unit_type": "piece", "category": "Рефлектор", "formula": null, "formula_script": null, "raw_material_id": null, "material_coefficient": 1.0, "supplier_url": "https://www.oasiscatalog.com/item/1-000116758", "created_at": "2026-06-24 12:44:20+00:00"}', '{"id": 21, "name": "Светоотражающая сумка для шопинга «Neo Reflector» с ремувкой под нанесение", "description": "Светоотражающая сумка для шопинга с ремувкой под нанесение, серый светоотражающий, темно-синий. Вес 118 г, производство Китай. Материал: полиэстер, металл. Размер: 38 х 42 х 0,4 см. В набор входит ремувка. ", "unit_price": 900.0, "unit_type": "piece", "category": "Рефлектор", "formula": null, "formula_script": null, "raw_material_id": null, "material_coefficient": 1.0, "supplier_url": "https://www.oasiscatalog.com/item/1-000116758", "created_at": "2026-06-24 12:44:20+00:00"}', 1, 'Administrator', '2026-06-28T08:16:34.540300+00:00');
INSERT INTO audit_log (id, entity_type, entity_id, action, old_data, new_data, user_id, user_name, created_at) VALUES (7, 'warehouse', 25, 'update', '{"id": 25, "product_id": null, "raw_material_id": 3, "quantity": 459.0, "min_quantity": 100, "defective_quantity": 0, "defective_reason": null, "stock_calculation_script": null, "display_format_script": null, "updated_at": "2026-06-28 10:35:25.477361+00:00"}', '{"id": 25, "product_id": null, "raw_material_id": 3, "quantity": 459.0, "min_quantity": 100, "defective_quantity": 0, "defective_reason": "", "stock_calculation_script": "sheet_stock_calc", "display_format_script": null, "updated_at": "2026-06-28 10:35:25.477361+00:00"}', 1, 'Administrator', '2026-06-28T10:47:27.224961+00:00');
INSERT INTO audit_log (id, entity_type, entity_id, action, old_data, new_data, user_id, user_name, created_at) VALUES (8, 'raw_material', 3, 'update', '{"id": 3, "name": "бумага 250 мат", "description": null, "width_mm": 450, "height_mm": 320, "roll_width_m": null, "roll_length_m": null, "density": null, "color_finish": null, "unit_type": "sheet", "unit_price": 7.5, "display_format_script": null, "stock_calculation_script": null, "created_at": "2026-06-27 19:10:12.126721+00:00"}', '{"id": 3, "name": "бумага 250 мат", "description": null, "width_mm": 450, "height_mm": 320, "roll_width_m": null, "roll_length_m": null, "density": null, "color_finish": null, "unit_type": "sheet", "unit_price": 7.5, "display_format_script": null, "stock_calculation_script": null, "created_at": "2026-06-27 19:10:12.126721+00:00"}', 1, 'Administrator', '2026-06-28T10:49:26.125905+00:00');
INSERT INTO audit_log (id, entity_type, entity_id, action, old_data, new_data, user_id, user_name, created_at) VALUES (9, 'product', 24, 'update', '{"id": 24, "name": "Диплом А4", "description": null, "unit_price": 45.33749999999999, "unit_type": "sheet", "category": null, "formula": null, "formula_script": null, "raw_material_id": 3, "material_coefficient": 1.0, "supplier_url": null, "created_at": "2026-06-27 19:12:53.502028+00:00"}', '{"id": 24, "name": "Диплом А4", "description": null, "unit_price": 45.33749999999999, "unit_type": "sheet", "category": null, "formula": null, "formula_script": null, "raw_material_id": 3, "material_coefficient": 0.5, "supplier_url": null, "created_at": "2026-06-27 19:12:53.502028+00:00"}', 1, 'Administrator', '2026-06-28T10:49:50.627915+00:00');
INSERT INTO audit_log (id, entity_type, entity_id, action, old_data, new_data, user_id, user_name, created_at) VALUES (10, 'warehouse', 25, 'update', '{"id": 25, "product_id": null, "raw_material_id": 3, "quantity": 449.0, "min_quantity": 100, "defective_quantity": 0, "defective_reason": "", "stock_calculation_script": "sheet_stock_calc", "display_format_script": null, "updated_at": "2026-06-28 10:50:16.552084+00:00"}', '{"id": 25, "product_id": null, "raw_material_id": 3, "quantity": 449.0, "min_quantity": 100, "defective_quantity": 0, "defective_reason": "", "stock_calculation_script": "sheet_stock_calc", "display_format_script": "sheet_stock_calc", "updated_at": "2026-06-28 10:50:16.552084+00:00"}', 1, 'Administrator', '2026-06-28T10:50:46.941943+00:00');
INSERT INTO audit_log (id, entity_type, entity_id, action, old_data, new_data, user_id, user_name, created_at) VALUES (11, 'warehouse', 25, 'update', '{"id": 25, "product_id": null, "raw_material_id": 3, "quantity": 449.0, "min_quantity": 100, "defective_quantity": 0, "defective_reason": "", "stock_calculation_script": "sheet_stock_calc", "display_format_script": "sheet_stock_calc", "updated_at": "2026-06-28 10:51:10.869425+00:00"}', '{"id": 25, "product_id": null, "raw_material_id": 3, "quantity": 449.0, "min_quantity": 100, "defective_quantity": 0, "defective_reason": "", "stock_calculation_script": "sheet_stock_calc", "display_format_script": "sheet_stock_calc", "updated_at": "2026-06-28 10:51:10.869425+00:00"}', 1, 'Administrator', '2026-06-28T10:52:54.160199+00:00');

DROP TABLE IF EXISTS client_company CASCADE;
CREATE TABLE client_company (
  client_id integer NOT NULL,
  company_detail_id integer NOT NULL,
  PRIMARY KEY (client_id, company_detail_id)
);

DROP TABLE IF EXISTS clients CASCADE;
CREATE TABLE clients (
  id integer NOT NULL,
  name character varying(255) NOT NULL,
  email character varying(255),
  phone character varying(50),
  company character varying(255),
  address text,
  created_at timestamp with time zone NOT NULL DEFAULT now(),
  updated_at timestamp with time zone NOT NULL DEFAULT now(),
  PRIMARY KEY (id)
);
INSERT INTO clients (id, name, email, phone, company, address, created_at, updated_at) VALUES (14, 'бебус', NULL, NULL, NULL, NULL, '2026-06-27T19:04:14.539496+00:00', '2026-06-27T19:04:14.539496+00:00');

DROP TABLE IF EXISTS company_details CASCADE;
CREATE TABLE company_details (
  id integer NOT NULL,
  company_name character varying(255) NOT NULL,
  inn character varying(12),
  kpp character varying(9),
  ogrn character varying(15),
  ogrnip character varying(15),
  legal_address text,
  actual_address text,
  settlement_account character varying(20),
  bank_name character varying(255),
  bik character varying(9),
  correspondent_account character varying(20),
  contact_person character varying(255),
  phone character varying(50),
  email character varying(255),
  created_at timestamp with time zone NOT NULL DEFAULT now(),
  updated_at timestamp with time zone NOT NULL DEFAULT now(),
  PRIMARY KEY (id)
);
INSERT INTO company_details (id, company_name, inn, kpp, ogrn, ogrnip, legal_address, actual_address, settlement_account, bank_name, bik, correspondent_account, contact_person, phone, email, created_at, updated_at) VALUES (1, 'ООО Рога и Копыта', '4163119785', NULL, '1560157888921', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2026-06-23T21:07:05+00:00', '2026-06-23T21:07:05+00:00');
INSERT INTO company_details (id, company_name, inn, kpp, ogrn, ogrnip, legal_address, actual_address, settlement_account, bank_name, bik, correspondent_account, contact_person, phone, email, created_at, updated_at) VALUES (2, 'ЗАО Технологии', '7825844140', NULL, '3808074611645', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2026-06-23T21:07:05+00:00', '2026-06-23T21:07:05+00:00');
INSERT INTO company_details (id, company_name, inn, kpp, ogrn, ogrnip, legal_address, actual_address, settlement_account, bank_name, bik, correspondent_account, contact_person, phone, email, created_at, updated_at) VALUES (3, 'ООО МедиаПро', '8574149614', NULL, '2628231594989', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2026-06-23T21:07:05+00:00', '2026-06-23T21:07:05+00:00');
INSERT INTO company_details (id, company_name, inn, kpp, ogrn, ogrnip, legal_address, actual_address, settlement_account, bank_name, bik, correspondent_account, contact_person, phone, email, created_at, updated_at) VALUES (4, 'ИП Волков', '9776552803', NULL, '7661160537249', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2026-06-23T21:07:05+00:00', '2026-06-23T21:07:05+00:00');
INSERT INTO company_details (id, company_name, inn, kpp, ogrn, ogrnip, legal_address, actual_address, settlement_account, bank_name, bik, correspondent_account, contact_person, phone, email, created_at, updated_at) VALUES (5, 'АО ИнвестГрупп', '4026113008', NULL, '7683402910416', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2026-06-23T21:07:05+00:00', '2026-06-23T21:07:05+00:00');
INSERT INTO company_details (id, company_name, inn, kpp, ogrn, ogrnip, legal_address, actual_address, settlement_account, bank_name, bik, correspondent_account, contact_person, phone, email, created_at, updated_at) VALUES (6, 'ООО ПринтМастер', '3783290795', NULL, '5306688806356', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2026-06-23T21:07:05+00:00', '2026-06-23T21:07:05+00:00');
INSERT INTO company_details (id, company_name, inn, kpp, ogrn, ogrnip, legal_address, actual_address, settlement_account, bank_name, bik, correspondent_account, contact_person, phone, email, created_at, updated_at) VALUES (7, 'ЗАО СтройСервис', '2351531223', NULL, '9781728240661', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2026-06-23T21:07:05+00:00', '2026-06-23T21:07:05+00:00');
INSERT INTO company_details (id, company_name, inn, kpp, ogrn, ogrnip, legal_address, actual_address, settlement_account, bank_name, bik, correspondent_account, contact_person, phone, email, created_at, updated_at) VALUES (8, 'ООО ЛогоСтудия', '7609857128', NULL, '8024777783792', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2026-06-23T21:07:05+00:00', '2026-06-23T21:07:05+00:00');
INSERT INTO company_details (id, company_name, inn, kpp, ogrn, ogrnip, legal_address, actual_address, settlement_account, bank_name, bik, correspondent_account, contact_person, phone, email, created_at, updated_at) VALUES (9, 'ИП Новиков', '1470939445', NULL, '3815898439108', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2026-06-23T21:07:05+00:00', '2026-06-23T21:07:05+00:00');
INSERT INTO company_details (id, company_name, inn, kpp, ogrn, ogrnip, legal_address, actual_address, settlement_account, bank_name, bik, correspondent_account, contact_person, phone, email, created_at, updated_at) VALUES (10, 'АО ФармМед', '5047709743', NULL, '5693329282832', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2026-06-23T21:07:05+00:00', '2026-06-23T21:07:05+00:00');
INSERT INTO company_details (id, company_name, inn, kpp, ogrn, ogrnip, legal_address, actual_address, settlement_account, bank_name, bik, correspondent_account, contact_person, phone, email, created_at, updated_at) VALUES (11, 'ООО Аврора', '2948728483', NULL, '9930004312372', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2026-06-23T21:07:05+00:00', '2026-06-23T21:07:05+00:00');
INSERT INTO company_details (id, company_name, inn, kpp, ogrn, ogrnip, legal_address, actual_address, settlement_account, bank_name, bik, correspondent_account, contact_person, phone, email, created_at, updated_at) VALUES (12, 'ИП Попов', '4944899549', NULL, '6701994049204', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2026-06-23T21:07:05+00:00', '2026-06-23T21:07:05+00:00');

DROP TABLE IF EXISTS custom_field_values CASCADE;
CREATE TABLE custom_field_values (
  id integer NOT NULL,
  entity character varying(50) NOT NULL,
  entity_id integer NOT NULL,
  field_id integer NOT NULL,
  value_text text,
  value_number integer,
  value_boolean boolean,
  value_json text,
  PRIMARY KEY (id)
);

DROP TABLE IF EXISTS custom_fields CASCADE;
CREATE TABLE custom_fields (
  id integer NOT NULL,
  entity character varying(50) NOT NULL,
  field_key character varying(100) NOT NULL,
  label character varying(255) NOT NULL,
  field_type character varying(50) NOT NULL,
  required boolean NOT NULL,
  options text,
  sort_order integer NOT NULL,
  created_at timestamp with time zone NOT NULL DEFAULT now(),
  PRIMARY KEY (id)
);

DROP TABLE IF EXISTS hermes_agents CASCADE;
CREATE TABLE hermes_agents (
  id integer NOT NULL,
  name character varying(255) NOT NULL,
  agent_type character varying(50) NOT NULL,
  config json NOT NULL,
  is_active boolean NOT NULL,
  last_seen timestamp with time zone,
  webhook_url character varying(500),
  created_at timestamp with time zone NOT NULL DEFAULT now(),
  PRIMARY KEY (id)
);

DROP TABLE IF EXISTS hermes_events CASCADE;
CREATE TABLE hermes_events (
  id integer NOT NULL,
  agent_id integer NOT NULL,
  event_type character varying(100) NOT NULL,
  payload json NOT NULL,
  status character varying(50) NOT NULL,
  response json,
  created_at timestamp with time zone NOT NULL DEFAULT now(),
  PRIMARY KEY (id)
);

DROP TABLE IF EXISTS knowledge_folders CASCADE;
CREATE TABLE knowledge_folders (
  id integer NOT NULL,
  name character varying(255) NOT NULL,
  parent_id integer,
  created_at timestamp with time zone NOT NULL DEFAULT now(),
  updated_at timestamp with time zone NOT NULL DEFAULT now(),
  PRIMARY KEY (id)
);

DROP TABLE IF EXISTS knowledge_notes CASCADE;
CREATE TABLE knowledge_notes (
  id integer NOT NULL,
  title character varying(255) NOT NULL,
  content text NOT NULL,
  folder_id integer,
  tags text,
  created_at timestamp with time zone NOT NULL DEFAULT now(),
  updated_at timestamp with time zone NOT NULL DEFAULT now(),
  PRIMARY KEY (id)
);

DROP TABLE IF EXISTS order_history CASCADE;
CREATE TABLE order_history (
  id integer NOT NULL,
  order_id integer NOT NULL,
  action character varying(50) NOT NULL,
  field character varying(100),
  old_value text,
  new_value text,
  user_id integer,
  user_name character varying(255),
  user_role character varying(100),
  created_at timestamp with time zone NOT NULL DEFAULT now(),
  PRIMARY KEY (id)
);
INSERT INTO order_history (id, order_id, action, field, old_value, new_value, user_id, user_name, user_role, created_at) VALUES (155, 83, 'created', NULL, NULL, 'Заказ #83 создан', 1, 'Administrator', 'admin', '2026-06-28T09:36:41.204088+00:00');
INSERT INTO order_history (id, order_id, action, field, old_value, new_value, user_id, user_name, user_role, created_at) VALUES (156, 84, 'created', NULL, NULL, 'Заказ #84 создан', 1, 'Administrator', 'admin', '2026-06-28T09:37:00.461746+00:00');
INSERT INTO order_history (id, order_id, action, field, old_value, new_value, user_id, user_name, user_role, created_at) VALUES (157, 85, 'created', NULL, NULL, 'Заказ #85 создан', 1, 'Administrator', 'admin', '2026-06-28T09:37:15.606468+00:00');
INSERT INTO order_history (id, order_id, action, field, old_value, new_value, user_id, user_name, user_role, created_at) VALUES (158, 84, 'item_completed', 'item', NULL, 'Диплом А4', 1, 'Administrator', 'admin', '2026-06-28T09:37:46.404621+00:00');
INSERT INTO order_history (id, order_id, action, field, old_value, new_value, user_id, user_name, user_role, created_at) VALUES (159, 84, 'status_changed', 'status', 'Новый', 'Готов', 1, 'Administrator', 'admin', '2026-06-28T09:37:46.439933+00:00');
INSERT INTO order_history (id, order_id, action, field, old_value, new_value, user_id, user_name, user_role, created_at) VALUES (160, 83, 'item_completed', 'item', NULL, 'Диплом А4', 1, 'Administrator', 'admin', '2026-06-28T09:56:27.553727+00:00');
INSERT INTO order_history (id, order_id, action, field, old_value, new_value, user_id, user_name, user_role, created_at) VALUES (161, 83, 'status_changed', 'status', 'Новый', 'Готов', 1, 'Administrator', 'admin', '2026-06-28T09:56:27.586970+00:00');
INSERT INTO order_history (id, order_id, action, field, old_value, new_value, user_id, user_name, user_role, created_at) VALUES (162, 86, 'created', NULL, NULL, 'Заказ #86 создан', 1, 'Administrator', 'admin', '2026-06-28T09:58:53.104465+00:00');
INSERT INTO order_history (id, order_id, action, field, old_value, new_value, user_id, user_name, user_role, created_at) VALUES (163, 86, 'item_completed', 'item', NULL, 'Диплом А4', 1, 'Administrator', 'admin', '2026-06-28T09:59:06.810082+00:00');
INSERT INTO order_history (id, order_id, action, field, old_value, new_value, user_id, user_name, user_role, created_at) VALUES (164, 86, 'status_changed', 'status', 'Новый', 'Готов', 1, 'Administrator', 'admin', '2026-06-28T09:59:06.862448+00:00');
INSERT INTO order_history (id, order_id, action, field, old_value, new_value, user_id, user_name, user_role, created_at) VALUES (165, 87, 'created', NULL, NULL, 'Заказ #87 создан', 1, 'Administrator', 'admin', '2026-06-28T10:04:18.612951+00:00');
INSERT INTO order_history (id, order_id, action, field, old_value, new_value, user_id, user_name, user_role, created_at) VALUES (166, 87, 'item_completed', 'item', NULL, 'Диплом А4', 1, 'Administrator', 'admin', '2026-06-28T10:04:25.485840+00:00');
INSERT INTO order_history (id, order_id, action, field, old_value, new_value, user_id, user_name, user_role, created_at) VALUES (167, 87, 'status_changed', 'status', 'Новый', 'Готов', 1, 'Administrator', 'admin', '2026-06-28T10:04:25.522392+00:00');
INSERT INTO order_history (id, order_id, action, field, old_value, new_value, user_id, user_name, user_role, created_at) VALUES (168, 85, 'item_completed', 'item', NULL, 'Диплом А4', 1, 'Administrator', 'admin', '2026-06-28T10:04:47.039210+00:00');
INSERT INTO order_history (id, order_id, action, field, old_value, new_value, user_id, user_name, user_role, created_at) VALUES (169, 85, 'status_changed', 'status', 'Новый', 'Готов', 1, 'Administrator', 'admin', '2026-06-28T10:04:47.072834+00:00');
INSERT INTO order_history (id, order_id, action, field, old_value, new_value, user_id, user_name, user_role, created_at) VALUES (170, 88, 'created', NULL, NULL, 'Заказ #88 создан', 1, 'Administrator', 'admin', '2026-06-28T10:11:32.535439+00:00');
INSERT INTO order_history (id, order_id, action, field, old_value, new_value, user_id, user_name, user_role, created_at) VALUES (171, 88, 'item_completed', 'item', NULL, 'Диплом А4', 1, 'Administrator', 'admin', '2026-06-28T10:11:35.896583+00:00');
INSERT INTO order_history (id, order_id, action, field, old_value, new_value, user_id, user_name, user_role, created_at) VALUES (172, 88, 'status_changed', 'status', 'Новый', 'Готов', 1, 'Administrator', 'admin', '2026-06-28T10:11:35.930840+00:00');
INSERT INTO order_history (id, order_id, action, field, old_value, new_value, user_id, user_name, user_role, created_at) VALUES (173, 89, 'created', NULL, NULL, 'Заказ #89 создан', 1, 'Administrator', 'admin', '2026-06-28T10:33:17.125047+00:00');
INSERT INTO order_history (id, order_id, action, field, old_value, new_value, user_id, user_name, user_role, created_at) VALUES (174, 89, 'item_completed', 'item', NULL, 'Диплом А4', 1, 'Administrator', 'admin', '2026-06-28T10:33:24.368204+00:00');
INSERT INTO order_history (id, order_id, action, field, old_value, new_value, user_id, user_name, user_role, created_at) VALUES (175, 89, 'status_changed', 'status', 'Новый', 'Готов', 1, 'Administrator', 'admin', '2026-06-28T10:33:24.418621+00:00');
INSERT INTO order_history (id, order_id, action, field, old_value, new_value, user_id, user_name, user_role, created_at) VALUES (176, 90, 'created', NULL, NULL, 'Заказ #90 создан', 1, 'Administrator', 'admin', '2026-06-28T10:34:55.641854+00:00');
INSERT INTO order_history (id, order_id, action, field, old_value, new_value, user_id, user_name, user_role, created_at) VALUES (177, 90, 'status_changed', 'status', 'Новый', 'В работе', 1, 'Administrator', 'admin', '2026-06-28T10:35:25.500412+00:00');
INSERT INTO order_history (id, order_id, action, field, old_value, new_value, user_id, user_name, user_role, created_at) VALUES (178, 91, 'created', NULL, NULL, 'Заказ #91 создан', 1, 'Administrator', 'admin', '2026-06-28T10:47:46.699662+00:00');
INSERT INTO order_history (id, order_id, action, field, old_value, new_value, user_id, user_name, user_role, created_at) VALUES (179, 91, 'updated', 'description', NULL, 'Диплом А4 — 5 sheet', 1, 'Administrator', 'admin', '2026-06-28T10:48:07.100813+00:00');
INSERT INTO order_history (id, order_id, action, field, old_value, new_value, user_id, user_name, user_role, created_at) VALUES (180, 91, 'status_changed', 'status', 'Новый', 'В работе', 1, 'Administrator', 'admin', '2026-06-28T10:48:07.108844+00:00');
INSERT INTO order_history (id, order_id, action, field, old_value, new_value, user_id, user_name, user_role, created_at) VALUES (181, 92, 'created', NULL, NULL, 'Заказ #92 создан', 1, 'Administrator', 'admin', '2026-06-28T10:50:02.558841+00:00');
INSERT INTO order_history (id, order_id, action, field, old_value, new_value, user_id, user_name, user_role, created_at) VALUES (182, 92, 'updated', 'description', NULL, 'Диплом А4 — 5 sheet', 1, 'Administrator', 'admin', '2026-06-28T10:50:16.608010+00:00');
INSERT INTO order_history (id, order_id, action, field, old_value, new_value, user_id, user_name, user_role, created_at) VALUES (183, 92, 'status_changed', 'status', 'Новый', 'В работе', 1, 'Administrator', 'admin', '2026-06-28T10:50:16.616832+00:00');
INSERT INTO order_history (id, order_id, action, field, old_value, new_value, user_id, user_name, user_role, created_at) VALUES (184, 92, 'status_changed', 'status', 'В работе', 'Новый', 1, 'Administrator', 'admin', '2026-06-28T10:51:00.680423+00:00');
INSERT INTO order_history (id, order_id, action, field, old_value, new_value, user_id, user_name, user_role, created_at) VALUES (185, 92, 'status_changed', 'status', 'Новый', 'В работе', 1, 'Administrator', 'admin', '2026-06-28T10:51:10.922395+00:00');
INSERT INTO order_history (id, order_id, action, field, old_value, new_value, user_id, user_name, user_role, created_at) VALUES (186, 91, 'item_completed', 'item', NULL, 'Диплом А4', 1, 'Administrator', 'admin', '2026-06-28T10:51:51.401864+00:00');
INSERT INTO order_history (id, order_id, action, field, old_value, new_value, user_id, user_name, user_role, created_at) VALUES (187, 91, 'status_changed', 'status', 'В работе', 'Готов', 1, 'Administrator', 'admin', '2026-06-28T10:51:51.427090+00:00');
INSERT INTO order_history (id, order_id, action, field, old_value, new_value, user_id, user_name, user_role, created_at) VALUES (188, 90, 'item_completed', 'item', NULL, 'Диплом А4', 1, 'Administrator', 'admin', '2026-06-28T10:51:56.153932+00:00');
INSERT INTO order_history (id, order_id, action, field, old_value, new_value, user_id, user_name, user_role, created_at) VALUES (189, 90, 'status_changed', 'status', 'В работе', 'Готов', 1, 'Administrator', 'admin', '2026-06-28T10:51:56.182625+00:00');
INSERT INTO order_history (id, order_id, action, field, old_value, new_value, user_id, user_name, user_role, created_at) VALUES (190, 92, 'item_completed', 'item', NULL, 'Диплом А4', 1, 'Administrator', 'admin', '2026-06-28T10:51:59.392722+00:00');
INSERT INTO order_history (id, order_id, action, field, old_value, new_value, user_id, user_name, user_role, created_at) VALUES (191, 92, 'status_changed', 'status', 'В работе', 'Готов', 1, 'Administrator', 'admin', '2026-06-28T10:51:59.415547+00:00');
INSERT INTO order_history (id, order_id, action, field, old_value, new_value, user_id, user_name, user_role, created_at) VALUES (192, 93, 'created', NULL, NULL, 'Заказ #93 создан', 1, 'Administrator', 'admin', '2026-06-28T10:53:12.559401+00:00');
INSERT INTO order_history (id, order_id, action, field, old_value, new_value, user_id, user_name, user_role, created_at) VALUES (193, 93, 'item_completed', 'item', NULL, 'Диплом А4', 1, 'Administrator', 'admin', '2026-06-28T10:53:22.323833+00:00');
INSERT INTO order_history (id, order_id, action, field, old_value, new_value, user_id, user_name, user_role, created_at) VALUES (194, 93, 'status_changed', 'status', 'Новый', 'Готов', 1, 'Administrator', 'admin', '2026-06-28T10:53:22.364109+00:00');
INSERT INTO order_history (id, order_id, action, field, old_value, new_value, user_id, user_name, user_role, created_at) VALUES (195, 84, 'status_changed', 'status', 'Готов', 'Новый', 1, 'Administrator', 'admin', '2026-06-28T11:11:38.287587+00:00');
INSERT INTO order_history (id, order_id, action, field, old_value, new_value, user_id, user_name, user_role, created_at) VALUES (196, 84, 'status_changed', 'status', 'Новый', 'Готов', 1, 'Administrator', 'admin', '2026-06-28T11:11:42.246837+00:00');

DROP TABLE IF EXISTS order_items CASCADE;
CREATE TABLE order_items (
  id integer NOT NULL,
  order_id integer NOT NULL,
  product_id integer,
  product_name_snapshot character varying(255),
  product_unit_snapshot character varying(50),
  product_formula_snapshot text,
  product_formula_script_snapshot character varying(255),
  raw_material_id integer,
  raw_material_qty double precision,
  cut_width_mm double precision,
  cut_height_mm double precision,
  quantity integer NOT NULL,
  unit_price double precision NOT NULL,
  is_completed boolean NOT NULL,
  is_printed boolean NOT NULL,
  PRIMARY KEY (id)
);
INSERT INTO order_items (id, order_id, product_id, product_name_snapshot, product_unit_snapshot, product_formula_snapshot, product_formula_script_snapshot, raw_material_id, raw_material_qty, cut_width_mm, cut_height_mm, quantity, unit_price, is_completed, is_printed) VALUES (228, 83, 24, 'Диплом А4', 'sheet', NULL, NULL, NULL, NULL, NULL, NULL, 5, 45.34, TRUE, TRUE);
INSERT INTO order_items (id, order_id, product_id, product_name_snapshot, product_unit_snapshot, product_formula_snapshot, product_formula_script_snapshot, raw_material_id, raw_material_qty, cut_width_mm, cut_height_mm, quantity, unit_price, is_completed, is_printed) VALUES (231, 86, 24, 'Диплом А4', 'sheet', NULL, NULL, NULL, NULL, NULL, NULL, 5, 45.34, TRUE, TRUE);
INSERT INTO order_items (id, order_id, product_id, product_name_snapshot, product_unit_snapshot, product_formula_snapshot, product_formula_script_snapshot, raw_material_id, raw_material_qty, cut_width_mm, cut_height_mm, quantity, unit_price, is_completed, is_printed) VALUES (232, 87, 24, 'Диплом А4', 'sheet', NULL, NULL, NULL, NULL, NULL, NULL, 1, 45.34, TRUE, TRUE);
INSERT INTO order_items (id, order_id, product_id, product_name_snapshot, product_unit_snapshot, product_formula_snapshot, product_formula_script_snapshot, raw_material_id, raw_material_qty, cut_width_mm, cut_height_mm, quantity, unit_price, is_completed, is_printed) VALUES (230, 85, 24, 'Диплом А4', 'sheet', NULL, NULL, NULL, NULL, NULL, NULL, 1, 45.34, TRUE, TRUE);
INSERT INTO order_items (id, order_id, product_id, product_name_snapshot, product_unit_snapshot, product_formula_snapshot, product_formula_script_snapshot, raw_material_id, raw_material_qty, cut_width_mm, cut_height_mm, quantity, unit_price, is_completed, is_printed) VALUES (233, 88, 24, 'Диплом А4', 'sheet', NULL, NULL, NULL, NULL, NULL, NULL, 2, 45.34, TRUE, TRUE);
INSERT INTO order_items (id, order_id, product_id, product_name_snapshot, product_unit_snapshot, product_formula_snapshot, product_formula_script_snapshot, raw_material_id, raw_material_qty, cut_width_mm, cut_height_mm, quantity, unit_price, is_completed, is_printed) VALUES (234, 89, 24, 'Диплом А4', 'sheet', NULL, NULL, NULL, NULL, NULL, NULL, 4, 45.34, TRUE, TRUE);
INSERT INTO order_items (id, order_id, product_id, product_name_snapshot, product_unit_snapshot, product_formula_snapshot, product_formula_script_snapshot, raw_material_id, raw_material_qty, cut_width_mm, cut_height_mm, quantity, unit_price, is_completed, is_printed) VALUES (237, 91, 24, 'Диплом А4', 'sheet', NULL, NULL, NULL, NULL, NULL, NULL, 5, 45.34, TRUE, TRUE);
INSERT INTO order_items (id, order_id, product_id, product_name_snapshot, product_unit_snapshot, product_formula_snapshot, product_formula_script_snapshot, raw_material_id, raw_material_qty, cut_width_mm, cut_height_mm, quantity, unit_price, is_completed, is_printed) VALUES (235, 90, 24, 'Диплом А4', 'sheet', NULL, NULL, NULL, NULL, NULL, NULL, 5, 45.34, TRUE, TRUE);
INSERT INTO order_items (id, order_id, product_id, product_name_snapshot, product_unit_snapshot, product_formula_snapshot, product_formula_script_snapshot, raw_material_id, raw_material_qty, cut_width_mm, cut_height_mm, quantity, unit_price, is_completed, is_printed) VALUES (241, 92, 24, 'Диплом А4', 'sheet', NULL, NULL, NULL, NULL, NULL, NULL, 5, 45.34, TRUE, TRUE);
INSERT INTO order_items (id, order_id, product_id, product_name_snapshot, product_unit_snapshot, product_formula_snapshot, product_formula_script_snapshot, raw_material_id, raw_material_qty, cut_width_mm, cut_height_mm, quantity, unit_price, is_completed, is_printed) VALUES (242, 93, 24, 'Диплом А4', 'sheet', NULL, NULL, NULL, NULL, NULL, NULL, 5, 45.34, TRUE, TRUE);
INSERT INTO order_items (id, order_id, product_id, product_name_snapshot, product_unit_snapshot, product_formula_snapshot, product_formula_script_snapshot, raw_material_id, raw_material_qty, cut_width_mm, cut_height_mm, quantity, unit_price, is_completed, is_printed) VALUES (229, 84, 24, 'Диплом А4', 'sheet', NULL, NULL, NULL, NULL, NULL, NULL, 13, 45.34, TRUE, TRUE);

DROP TABLE IF EXISTS order_settings CASCADE;
CREATE TABLE order_settings (
  id integer NOT NULL,
  setting_type character varying(50) NOT NULL,
  name character varying(255) NOT NULL,
  color character varying(20) NOT NULL,
  sort_order integer NOT NULL,
  PRIMARY KEY (id)
);
INSERT INTO order_settings (id, setting_type, name, color, sort_order) VALUES (1, 'status_color', 'Новый', '#3b82f6', 0);
INSERT INTO order_settings (id, setting_type, name, color, sort_order) VALUES (2, 'status_color', 'В работе', '#fa8c16', 0);
INSERT INTO order_settings (id, setting_type, name, color, sort_order) VALUES (3, 'status_color', 'Готов', '#52c41a', 0);
INSERT INTO order_settings (id, setting_type, name, color, sort_order) VALUES (4, 'status_color', 'Отдали', '#8c8c8c', 0);
INSERT INTO order_settings (id, setting_type, name, color, sort_order) VALUES (6, 'worker_color', 'admin', '#1677ff', 1);
INSERT INTO order_settings (id, setting_type, name, color, sort_order) VALUES (5, 'worker_color', 'biba', 'rgb(22,255,127)', 0);
INSERT INTO order_settings (id, setting_type, name, color, sort_order) VALUES (7, 'designer_color', 'biba', 'rgb(255,22,135)', 0);
INSERT INTO order_settings (id, setting_type, name, color, sort_order) VALUES (8, 'designer_color', 'admin', '#1677ff', 1);

DROP TABLE IF EXISTS orders CASCADE;
CREATE TABLE orders (
  id integer NOT NULL,
  client_id integer NOT NULL,
  total_price double precision NOT NULL,
  status character varying(50) NOT NULL,
  description text,
  notes text,
  deadline timestamp with time zone,
  designer character varying(255),
  workers text,
  layout_type character varying(100),
  path text,
  source character varying(100),
  created_by integer,
  created_by_name character varying(255),
  created_by_role character varying(100),
  created_at timestamp with time zone NOT NULL DEFAULT now(),
  updated_at timestamp with time zone NOT NULL DEFAULT now(),
  PRIMARY KEY (id)
);
INSERT INTO orders (id, client_id, total_price, status, description, notes, deadline, designer, workers, layout_type, path, source, created_by, created_by_name, created_by_role, created_at, updated_at) VALUES (83, 14, 226.69, 'ready', NULL, NULL, NULL, 'admin', '["biba"]', NULL, NULL, NULL, 1, 'Administrator', 'admin', '2026-06-28T09:36:41.186414+00:00', '2026-06-28T09:56:27.566419+00:00');
INSERT INTO orders (id, client_id, total_price, status, description, notes, deadline, designer, workers, layout_type, path, source, created_by, created_by_name, created_by_role, created_at, updated_at) VALUES (86, 14, 226.69, 'ready', NULL, NULL, NULL, 'admin', '["biba"]', NULL, NULL, NULL, 1, 'Administrator', 'admin', '2026-06-28T09:58:53.082738+00:00', '2026-06-28T09:59:06.830274+00:00');
INSERT INTO orders (id, client_id, total_price, status, description, notes, deadline, designer, workers, layout_type, path, source, created_by, created_by_name, created_by_role, created_at, updated_at) VALUES (87, 14, 45.34, 'ready', NULL, NULL, NULL, 'admin', '["biba"]', NULL, NULL, NULL, 1, 'Administrator', 'admin', '2026-06-28T10:04:18.598331+00:00', '2026-06-28T10:04:25.500410+00:00');
INSERT INTO orders (id, client_id, total_price, status, description, notes, deadline, designer, workers, layout_type, path, source, created_by, created_by_name, created_by_role, created_at, updated_at) VALUES (85, 14, 45.34, 'ready', NULL, NULL, NULL, 'admin', '["biba"]', NULL, NULL, NULL, 1, 'Administrator', 'admin', '2026-06-28T09:37:15.593282+00:00', '2026-06-28T10:04:47.054809+00:00');
INSERT INTO orders (id, client_id, total_price, status, description, notes, deadline, designer, workers, layout_type, path, source, created_by, created_by_name, created_by_role, created_at, updated_at) VALUES (88, 14, 90.67, 'ready', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 'Administrator', 'admin', '2026-06-28T10:11:32.521646+00:00', '2026-06-28T10:11:35.910542+00:00');
INSERT INTO orders (id, client_id, total_price, status, description, notes, deadline, designer, workers, layout_type, path, source, created_by, created_by_name, created_by_role, created_at, updated_at) VALUES (89, 14, 181.35, 'ready', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 'Administrator', 'admin', '2026-06-28T10:33:17.106428+00:00', '2026-06-28T10:33:24.392098+00:00');
INSERT INTO orders (id, client_id, total_price, status, description, notes, deadline, designer, workers, layout_type, path, source, created_by, created_by_name, created_by_role, created_at, updated_at) VALUES (91, 14, 226.69, 'ready', 'Диплом А4 — 5 sheet', NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 'Administrator', 'admin', '2026-06-28T10:47:46.676421+00:00', '2026-06-28T10:51:51.417819+00:00');
INSERT INTO orders (id, client_id, total_price, status, description, notes, deadline, designer, workers, layout_type, path, source, created_by, created_by_name, created_by_role, created_at, updated_at) VALUES (90, 14, 226.69, 'ready', 'Тест - проверка истории списаний', NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 'Administrator', 'admin', '2026-06-28T10:34:55.623517+00:00', '2026-06-28T10:51:56.170807+00:00');
INSERT INTO orders (id, client_id, total_price, status, description, notes, deadline, designer, workers, layout_type, path, source, created_by, created_by_name, created_by_role, created_at, updated_at) VALUES (92, 14, 226.69, 'ready', 'Диплом А4 — 5 sheet', NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 'Administrator', 'admin', '2026-06-28T10:50:02.543833+00:00', '2026-06-28T10:51:59.407534+00:00');
INSERT INTO orders (id, client_id, total_price, status, description, notes, deadline, designer, workers, layout_type, path, source, created_by, created_by_name, created_by_role, created_at, updated_at) VALUES (93, 14, 226.69, 'ready', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 'Administrator', 'admin', '2026-06-28T10:53:12.544368+00:00', '2026-06-28T10:53:22.340230+00:00');
INSERT INTO orders (id, client_id, total_price, status, description, notes, deadline, designer, workers, layout_type, path, source, created_by, created_by_name, created_by_role, created_at, updated_at) VALUES (84, 14, 589.39, 'ready', NULL, NULL, NULL, 'admin', '["biba"]', NULL, NULL, NULL, 1, 'Administrator', 'admin', '2026-06-28T09:37:00.445025+00:00', '2026-06-28T11:11:42.216837+00:00');

DROP TABLE IF EXISTS permissions CASCADE;
CREATE TABLE permissions (
  id integer NOT NULL,
  name character varying(100) NOT NULL,
  description character varying(255),
  PRIMARY KEY (id)
);
INSERT INTO permissions (id, name, description) VALUES (1, 'clients.view', 'View clients');
INSERT INTO permissions (id, name, description) VALUES (2, 'clients.create', 'Create clients');
INSERT INTO permissions (id, name, description) VALUES (3, 'clients.edit', 'Edit clients');
INSERT INTO permissions (id, name, description) VALUES (4, 'clients.delete', 'Delete clients');
INSERT INTO permissions (id, name, description) VALUES (5, 'products.view', 'View products');
INSERT INTO permissions (id, name, description) VALUES (6, 'products.create', 'Create products');
INSERT INTO permissions (id, name, description) VALUES (7, 'products.edit', 'Edit products');
INSERT INTO permissions (id, name, description) VALUES (8, 'products.delete', 'Delete products');
INSERT INTO permissions (id, name, description) VALUES (9, 'orders.view', 'View orders');
INSERT INTO permissions (id, name, description) VALUES (10, 'orders.create', 'Create orders');
INSERT INTO permissions (id, name, description) VALUES (11, 'orders.edit', 'Edit orders');
INSERT INTO permissions (id, name, description) VALUES (12, 'orders.delete', 'Delete orders');
INSERT INTO permissions (id, name, description) VALUES (13, 'warehouse.view', 'View warehouse');
INSERT INTO permissions (id, name, description) VALUES (14, 'warehouse.create', 'Create warehouse items');
INSERT INTO permissions (id, name, description) VALUES (15, 'warehouse.edit', 'Edit warehouse items');
INSERT INTO permissions (id, name, description) VALUES (16, 'warehouse.delete', 'Delete warehouse items');
INSERT INTO permissions (id, name, description) VALUES (17, 'hermes.view', 'View hermes agents');
INSERT INTO permissions (id, name, description) VALUES (18, 'hermes.manage', 'Manage hermes agents');
INSERT INTO permissions (id, name, description) VALUES (19, 'users.view', 'View users');
INSERT INTO permissions (id, name, description) VALUES (20, 'users.manage', 'Manage users');
INSERT INTO permissions (id, name, description) VALUES (21, 'roles.manage', 'Manage roles');
INSERT INTO permissions (id, name, description) VALUES (22, 'prices.view', 'View prices');
INSERT INTO permissions (id, name, description) VALUES (23, 'prices.revenue', 'View total revenue');

DROP TABLE IF EXISTS products CASCADE;
CREATE TABLE products (
  id integer NOT NULL,
  name character varying(255) NOT NULL,
  description text,
  unit_price double precision NOT NULL,
  unit_type character varying(50) NOT NULL,
  category character varying(100),
  formula text,
  formula_script character varying(255),
  raw_material_id integer,
  material_coefficient double precision NOT NULL,
  created_at timestamp with time zone NOT NULL DEFAULT now(),
  supplier_url character varying(500),
  PRIMARY KEY (id)
);
INSERT INTO products (id, name, description, unit_price, unit_type, category, formula, formula_script, raw_material_id, material_coefficient, created_at, supplier_url) VALUES (21, 'Светоотражающая сумка для шопинга «Neo Reflector» с ремувкой под нанесение', 'Светоотражающая сумка для шопинга с ремувкой под нанесение, серый светоотражающий, темно-синий. Вес 118 г, производство Китай. Материал: полиэстер, металл. Размер: 38 х 42 х 0,4 см. В набор входит ремувка. ', 900.0, 'piece', 'Рефлектор', NULL, NULL, NULL, 1.0, '2026-06-24T12:44:20+00:00', 'https://www.oasiscatalog.com/item/1-000116758');
INSERT INTO products (id, name, description, unit_price, unit_type, category, formula, formula_script, raw_material_id, material_coefficient, created_at, supplier_url) VALUES (24, 'Диплом А4', NULL, 45.33749999999999, 'sheet', NULL, NULL, NULL, 3, 0.5, '2026-06-27T19:12:53.502028+00:00', NULL);

DROP TABLE IF EXISTS raw_materials CASCADE;
CREATE TABLE raw_materials (
  id integer NOT NULL,
  name character varying(255) NOT NULL,
  description text,
  width_mm integer,
  height_mm integer,
  roll_width_m double precision,
  roll_length_m double precision,
  density character varying(100),
  color_finish character varying(100),
  unit_type character varying(50) NOT NULL,
  unit_price double precision NOT NULL,
  display_format_script character varying(255),
  created_at timestamp with time zone NOT NULL DEFAULT now(),
  stock_calculation_script character varying(255),
  PRIMARY KEY (id)
);
INSERT INTO raw_materials (id, name, description, width_mm, height_mm, roll_width_m, roll_length_m, density, color_finish, unit_type, unit_price, display_format_script, created_at, stock_calculation_script) VALUES (2, 'бумага 300 мат', NULL, 450, 320, NULL, NULL, NULL, NULL, 'sheet', 0.0, NULL, '2026-06-27T11:37:00.556097+00:00', NULL);
INSERT INTO raw_materials (id, name, description, width_mm, height_mm, roll_width_m, roll_length_m, density, color_finish, unit_type, unit_price, display_format_script, created_at, stock_calculation_script) VALUES (3, 'бумага 250 мат', NULL, 450, 320, NULL, NULL, NULL, NULL, 'sheet', 7.5, NULL, '2026-06-27T19:10:12.126721+00:00', NULL);
INSERT INTO raw_materials (id, name, description, width_mm, height_mm, roll_width_m, roll_length_m, density, color_finish, unit_type, unit_price, display_format_script, created_at, stock_calculation_script) VALUES (1, 'банер 1.6', NULL, NULL, NULL, 1.6, 50.0, NULL, NULL, 'piece', 92.0, NULL, '2026-06-27T11:01:34.682754+00:00', NULL);

DROP TABLE IF EXISTS role_permissions CASCADE;
CREATE TABLE role_permissions (
  role_id integer NOT NULL,
  permission_id integer NOT NULL,
  PRIMARY KEY (role_id, permission_id)
);
INSERT INTO role_permissions (role_id, permission_id) VALUES (1, 1);
INSERT INTO role_permissions (role_id, permission_id) VALUES (2, 1);
INSERT INTO role_permissions (role_id, permission_id) VALUES (3, 1);
INSERT INTO role_permissions (role_id, permission_id) VALUES (4, 1);
INSERT INTO role_permissions (role_id, permission_id) VALUES (6, 1);
INSERT INTO role_permissions (role_id, permission_id) VALUES (1, 5);
INSERT INTO role_permissions (role_id, permission_id) VALUES (2, 5);
INSERT INTO role_permissions (role_id, permission_id) VALUES (3, 5);
INSERT INTO role_permissions (role_id, permission_id) VALUES (4, 5);
INSERT INTO role_permissions (role_id, permission_id) VALUES (5, 5);
INSERT INTO role_permissions (role_id, permission_id) VALUES (6, 5);
INSERT INTO role_permissions (role_id, permission_id) VALUES (1, 18);
INSERT INTO role_permissions (role_id, permission_id) VALUES (2, 18);
INSERT INTO role_permissions (role_id, permission_id) VALUES (1, 11);
INSERT INTO role_permissions (role_id, permission_id) VALUES (2, 11);
INSERT INTO role_permissions (role_id, permission_id) VALUES (3, 11);
INSERT INTO role_permissions (role_id, permission_id) VALUES (1, 2);
INSERT INTO role_permissions (role_id, permission_id) VALUES (2, 2);
INSERT INTO role_permissions (role_id, permission_id) VALUES (3, 2);
INSERT INTO role_permissions (role_id, permission_id) VALUES (1, 6);
INSERT INTO role_permissions (role_id, permission_id) VALUES (2, 6);
INSERT INTO role_permissions (role_id, permission_id) VALUES (3, 6);
INSERT INTO role_permissions (role_id, permission_id) VALUES (1, 19);
INSERT INTO role_permissions (role_id, permission_id) VALUES (2, 19);
INSERT INTO role_permissions (role_id, permission_id) VALUES (4, 19);
INSERT INTO role_permissions (role_id, permission_id) VALUES (6, 19);
INSERT INTO role_permissions (role_id, permission_id) VALUES (1, 13);
INSERT INTO role_permissions (role_id, permission_id) VALUES (2, 13);
INSERT INTO role_permissions (role_id, permission_id) VALUES (4, 13);
INSERT INTO role_permissions (role_id, permission_id) VALUES (5, 13);
INSERT INTO role_permissions (role_id, permission_id) VALUES (6, 13);
INSERT INTO role_permissions (role_id, permission_id) VALUES (1, 20);
INSERT INTO role_permissions (role_id, permission_id) VALUES (1, 12);
INSERT INTO role_permissions (role_id, permission_id) VALUES (2, 12);
INSERT INTO role_permissions (role_id, permission_id) VALUES (1, 7);
INSERT INTO role_permissions (role_id, permission_id) VALUES (2, 7);
INSERT INTO role_permissions (role_id, permission_id) VALUES (3, 7);
INSERT INTO role_permissions (role_id, permission_id) VALUES (5, 7);
INSERT INTO role_permissions (role_id, permission_id) VALUES (1, 21);
INSERT INTO role_permissions (role_id, permission_id) VALUES (1, 14);
INSERT INTO role_permissions (role_id, permission_id) VALUES (2, 14);
INSERT INTO role_permissions (role_id, permission_id) VALUES (1, 8);
INSERT INTO role_permissions (role_id, permission_id) VALUES (2, 8);
INSERT INTO role_permissions (role_id, permission_id) VALUES (1, 22);
INSERT INTO role_permissions (role_id, permission_id) VALUES (2, 22);
INSERT INTO role_permissions (role_id, permission_id) VALUES (3, 22);
INSERT INTO role_permissions (role_id, permission_id) VALUES (1, 3);
INSERT INTO role_permissions (role_id, permission_id) VALUES (2, 3);
INSERT INTO role_permissions (role_id, permission_id) VALUES (3, 3);
INSERT INTO role_permissions (role_id, permission_id) VALUES (1, 15);
INSERT INTO role_permissions (role_id, permission_id) VALUES (2, 15);
INSERT INTO role_permissions (role_id, permission_id) VALUES (5, 15);
INSERT INTO role_permissions (role_id, permission_id) VALUES (1, 9);
INSERT INTO role_permissions (role_id, permission_id) VALUES (2, 9);
INSERT INTO role_permissions (role_id, permission_id) VALUES (3, 9);
INSERT INTO role_permissions (role_id, permission_id) VALUES (4, 9);
INSERT INTO role_permissions (role_id, permission_id) VALUES (6, 9);
INSERT INTO role_permissions (role_id, permission_id) VALUES (1, 23);
INSERT INTO role_permissions (role_id, permission_id) VALUES (2, 23);
INSERT INTO role_permissions (role_id, permission_id) VALUES (1, 16);
INSERT INTO role_permissions (role_id, permission_id) VALUES (2, 16);
INSERT INTO role_permissions (role_id, permission_id) VALUES (1, 4);
INSERT INTO role_permissions (role_id, permission_id) VALUES (2, 4);
INSERT INTO role_permissions (role_id, permission_id) VALUES (1, 17);
INSERT INTO role_permissions (role_id, permission_id) VALUES (2, 17);
INSERT INTO role_permissions (role_id, permission_id) VALUES (4, 17);
INSERT INTO role_permissions (role_id, permission_id) VALUES (6, 17);
INSERT INTO role_permissions (role_id, permission_id) VALUES (1, 10);
INSERT INTO role_permissions (role_id, permission_id) VALUES (2, 10);
INSERT INTO role_permissions (role_id, permission_id) VALUES (3, 10);

DROP TABLE IF EXISTS roles CASCADE;
CREATE TABLE roles (
  id integer NOT NULL,
  name character varying(100) NOT NULL,
  description character varying(255),
  PRIMARY KEY (id)
);
INSERT INTO roles (id, name, description) VALUES (1, 'admin', 'Администратор');
INSERT INTO roles (id, name, description) VALUES (2, 'director', 'Руководитель');
INSERT INTO roles (id, name, description) VALUES (3, 'manager', 'Менеджер');
INSERT INTO roles (id, name, description) VALUES (4, 'designer', 'Дизайнер');
INSERT INTO roles (id, name, description) VALUES (5, 'production', 'Работник производства');
INSERT INTO roles (id, name, description) VALUES (6, 'user', 'Пользователь');

DROP TABLE IF EXISTS stock_writeoffs CASCADE;
CREATE TABLE stock_writeoffs (
  id integer NOT NULL,
  item_type character varying(20) NOT NULL,
  product_id integer,
  raw_material_id integer,
  quantity double precision NOT NULL,
  reason text,
  created_by integer,
  created_by_name character varying(255),
  created_at timestamp with time zone NOT NULL DEFAULT now(),
  order_id integer,
  PRIMARY KEY (id)
);
INSERT INTO stock_writeoffs (id, item_type, product_id, raw_material_id, quantity, reason, created_by, created_by_name, created_at, order_id) VALUES (10, 'raw_material', NULL, 3, 5.0, NULL, 1, 'Administrator', '2026-06-27T19:34:02.753921+00:00', NULL);
INSERT INTO stock_writeoffs (id, item_type, product_id, raw_material_id, quantity, reason, created_by, created_by_name, created_at, order_id) VALUES (11, 'raw_material', NULL, 1, 3.0, NULL, 1, 'Administrator', '2026-06-27T19:44:40.814586+00:00', NULL);
INSERT INTO stock_writeoffs (id, item_type, product_id, raw_material_id, quantity, reason, created_by, created_by_name, created_at, order_id) VALUES (12, 'raw_material', NULL, 2, 15.0, NULL, 1, 'Administrator', '2026-06-28T08:12:14.919846+00:00', NULL);
INSERT INTO stock_writeoffs (id, item_type, product_id, raw_material_id, quantity, reason, created_by, created_by_name, created_at, order_id) VALUES (13, 'raw_material', NULL, 3, 5.0, 'Заказ #86', NULL, NULL, '2026-06-28T09:59:06.830274+00:00', 86);
INSERT INTO stock_writeoffs (id, item_type, product_id, raw_material_id, quantity, reason, created_by, created_by_name, created_at, order_id) VALUES (14, 'raw_material', NULL, 3, 1.0, 'Заказ #87', NULL, NULL, '2026-06-28T10:04:25.500410+00:00', 87);
INSERT INTO stock_writeoffs (id, item_type, product_id, raw_material_id, quantity, reason, created_by, created_by_name, created_at, order_id) VALUES (15, 'raw_material', NULL, 3, 1.0, 'Заказ #85', NULL, NULL, '2026-06-28T10:04:47.054809+00:00', 85);
INSERT INTO stock_writeoffs (id, item_type, product_id, raw_material_id, quantity, reason, created_by, created_by_name, created_at, order_id) VALUES (16, 'raw_material', NULL, 3, 2.0, 'Заказ #88', NULL, NULL, '2026-06-28T10:11:35.910542+00:00', 88);
INSERT INTO stock_writeoffs (id, item_type, product_id, raw_material_id, quantity, reason, created_by, created_by_name, created_at, order_id) VALUES (17, 'raw_material', NULL, 3, 4.0, 'Заказ #89', NULL, NULL, '2026-06-28T10:33:24.392098+00:00', 89);
INSERT INTO stock_writeoffs (id, item_type, product_id, raw_material_id, quantity, reason, created_by, created_by_name, created_at, order_id) VALUES (18, 'raw_material', NULL, 3, 5.0, 'Заказ #90', NULL, NULL, '2026-06-28T10:35:25.477361+00:00', 90);
INSERT INTO stock_writeoffs (id, item_type, product_id, raw_material_id, quantity, reason, created_by, created_by_name, created_at, order_id) VALUES (19, 'raw_material', NULL, 3, 5.0, 'Заказ #91', NULL, NULL, '2026-06-28T10:48:07.034200+00:00', 91);
INSERT INTO stock_writeoffs (id, item_type, product_id, raw_material_id, quantity, reason, created_by, created_by_name, created_at, order_id) VALUES (20, 'raw_material', NULL, 3, 5.0, 'Заказ #91', NULL, NULL, '2026-06-28T10:48:07.034200+00:00', 91);
INSERT INTO stock_writeoffs (id, item_type, product_id, raw_material_id, quantity, reason, created_by, created_by_name, created_at, order_id) VALUES (23, 'raw_material', NULL, 3, 5.0, 'Заказ #92', NULL, NULL, '2026-06-28T10:51:10.869425+00:00', 92);
INSERT INTO stock_writeoffs (id, item_type, product_id, raw_material_id, quantity, reason, created_by, created_by_name, created_at, order_id) VALUES (24, 'raw_material', NULL, 3, 5.0, 'Заказ #92', NULL, NULL, '2026-06-28T10:51:10.869425+00:00', 92);
INSERT INTO stock_writeoffs (id, item_type, product_id, raw_material_id, quantity, reason, created_by, created_by_name, created_at, order_id) VALUES (25, 'raw_material', NULL, 3, 5.0, 'Заказ #93', NULL, NULL, '2026-06-28T10:53:22.340230+00:00', 93);
INSERT INTO stock_writeoffs (id, item_type, product_id, raw_material_id, quantity, reason, created_by, created_by_name, created_at, order_id) VALUES (26, 'raw_material', NULL, 3, 13.0, 'Заказ #84', NULL, NULL, '2026-06-28T11:11:42.216837+00:00', 84);

DROP TABLE IF EXISTS user_filter_states CASCADE;
CREATE TABLE user_filter_states (
  id integer NOT NULL,
  user_id integer NOT NULL,
  entity character varying(50) NOT NULL,
  filters text NOT NULL,
  sort_field character varying(100),
  sort_direction character varying(10) NOT NULL,
  search character varying(255),
  created_at timestamp with time zone NOT NULL DEFAULT now(),
  updated_at timestamp with time zone NOT NULL DEFAULT now(),
  PRIMARY KEY (id)
);
INSERT INTO user_filter_states (id, user_id, entity, filters, sort_field, sort_direction, search, created_at, updated_at) VALUES (3, 1, 'products', '{}', NULL, 'asc', '', '2026-06-24T12:44:45+00:00', '2026-06-24T12:44:47+00:00');
INSERT INTO user_filter_states (id, user_id, entity, filters, sort_field, sort_direction, search, created_at, updated_at) VALUES (1, 1, 'dashboard', '{"status": "ready"}', NULL, 'asc', '', '2026-06-23T21:09:24+00:00', '2026-06-26T10:51:35.055708+00:00');
INSERT INTO user_filter_states (id, user_id, entity, filters, sort_field, sort_direction, search, created_at, updated_at) VALUES (4, 1, 'clients', '{}', 'id', 'desc', '', '2026-06-24T13:10:47+00:00', '2026-06-27T12:29:03.724117+00:00');
INSERT INTO user_filter_states (id, user_id, entity, filters, sort_field, sort_direction, search, created_at, updated_at) VALUES (2, 1, 'orders', '{}', 'total_price', 'desc', '', '2026-06-23T21:10:18+00:00', '2026-06-28T09:35:15.574602+00:00');

DROP TABLE IF EXISTS user_roles CASCADE;
CREATE TABLE user_roles (
  user_id integer NOT NULL,
  role_id integer NOT NULL,
  PRIMARY KEY (user_id, role_id)
);
INSERT INTO user_roles (user_id, role_id) VALUES (1, 1);
INSERT INTO user_roles (user_id, role_id) VALUES (2, 3);

DROP TABLE IF EXISTS users CASCADE;
CREATE TABLE users (
  id integer NOT NULL,
  username character varying(100) NOT NULL,
  email character varying(255) NOT NULL,
  hashed_password character varying(500) NOT NULL,
  full_name character varying(255),
  is_active boolean NOT NULL,
  is_superuser boolean NOT NULL,
  created_at timestamp with time zone NOT NULL DEFAULT now(),
  PRIMARY KEY (id)
);
INSERT INTO users (id, username, email, hashed_password, full_name, is_active, is_superuser, created_at) VALUES (2, 'biba', 'biba@biba.coc', '$2b$12$yyrXUq23DgCdw4FZY4GPi.vJxRNjFCDRY0PD2wb8AWFK.bc3sp6X6', 'biba', TRUE, FALSE, '2026-06-26T11:25:52.315903+00:00');
INSERT INTO users (id, username, email, hashed_password, full_name, is_active, is_superuser, created_at) VALUES (1, 'admin', 'admin@crm.local', '$2b$12$sfaEsAV9MiK./xkFELUtQOlEA6.QPVso5BGyflailipvifChhtrBy', 'Administrator', TRUE, TRUE, '2026-06-23T21:06:56+00:00');

DROP TABLE IF EXISTS warehouse CASCADE;
CREATE TABLE warehouse (
  id integer NOT NULL,
  product_id integer,
  raw_material_id integer,
  quantity double precision NOT NULL,
  min_quantity integer NOT NULL,
  defective_quantity integer NOT NULL,
  defective_reason character varying(500),
  updated_at timestamp with time zone NOT NULL DEFAULT now(),
  stock_calculation_script character varying(255),
  display_format_script character varying(255),
  PRIMARY KEY (id)
);
INSERT INTO warehouse (id, product_id, raw_material_id, quantity, min_quantity, defective_quantity, defective_reason, updated_at, stock_calculation_script, display_format_script) VALUES (24, NULL, 1, 247.0, 1, 0, '', '2026-06-28T08:22:04.003845+00:00', 'roll_stock_calc', NULL);
INSERT INTO warehouse (id, product_id, raw_material_id, quantity, min_quantity, defective_quantity, defective_reason, updated_at, stock_calculation_script, display_format_script) VALUES (23, NULL, 2, 483.5, 100, 0, '', '2026-06-28T09:35:57.664851+00:00', 'sheet_stock_calc', NULL);
INSERT INTO warehouse (id, product_id, raw_material_id, quantity, min_quantity, defective_quantity, defective_reason, updated_at, stock_calculation_script, display_format_script) VALUES (25, NULL, 3, 444.0, 100, 0, '', '2026-06-28T11:11:42.216837+00:00', 'sheet_stock_calc', 'sheet_stock_calc');
