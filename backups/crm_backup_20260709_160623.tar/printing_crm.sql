-- CRM Backup — 2026-07-09T16:06:23.441007
-- Database: printing_crm

DROP SEQUENCE IF EXISTS 'ai_provider_settings_id_seq'::regclass CASCADE;
CREATE SEQUENCE 'ai_provider_settings_id_seq'::regclass START WITH 1 INCREMENT BY 1 NO MINVALUE NO MAXVALUE CACHE 1;
DROP TABLE IF EXISTS ai_provider_settings CASCADE;
CREATE TABLE ai_provider_settings (
  id integer NOT NULL,
  provider_name character varying(100) NOT NULL,
  base_url character varying(500) NOT NULL,
  api_key character varying(500),
  model_name character varying(255) NOT NULL,
  temperature double precision NOT NULL,
  max_tokens integer NOT NULL,
  system_prompt text,
  is_active boolean NOT NULL,
  created_at timestamp with time zone NOT NULL DEFAULT now(),
  updated_at timestamp with time zone NOT NULL DEFAULT now(),
  timeout integer DEFAULT 120,
  PRIMARY KEY (id)
);
ALTER TABLE ai_provider_settings ALTER COLUMN id SET DEFAULT nextval(''ai_provider_settings_id_seq'::regclass'::regclass);
INSERT INTO ai_provider_settings (id, provider_name, base_url, api_key, model_name, temperature, max_tokens, system_prompt, is_active, created_at, updated_at, timeout) VALUES (1, 'llamacpp', 'http://192.168.1.119:8081', NULL, 'local-model', 0.7, 4096, NULL, TRUE, '2026-06-23T21:09:08+00:00', '2026-07-02T15:21:04.548856+00:00', 300);
SELECT setval(''ai_provider_settings_id_seq'::regclass', 1);

DROP SEQUENCE IF EXISTS 'audit_log_id_seq'::regclass CASCADE;
CREATE SEQUENCE 'audit_log_id_seq'::regclass START WITH 105 INCREMENT BY 1 NO MINVALUE NO MAXVALUE CACHE 1;
DROP TABLE IF EXISTS audit_log CASCADE;
CREATE TABLE audit_log (
  id integer NOT NULL,
  entity_type character varying(50) NOT NULL,
  entity_id integer NOT NULL,
  action character varying(50) NOT NULL,
  old_data text,
  new_data text,
  user_id integer,
  user_name character varying(255),
  created_at timestamp with time zone NOT NULL DEFAULT now(),
  PRIMARY KEY (id)
);
ALTER TABLE audit_log ALTER COLUMN id SET DEFAULT nextval(''audit_log_id_seq'::regclass'::regclass);
INSERT INTO audit_log (id, entity_type, entity_id, action, old_data, new_data, user_id, user_name, created_at) VALUES (1, 'product', 21, 'update', '{"id": 21, "name": "Светоотражающая сумка для шопинга «Neo Reflector» с ремувкой под нанесение", "description": "Светоотражающая сумка для шопинга с ремувкой под нанесение, серый светоотражающий, темно-синий. Вес 118 г, производство Китай. Материал: полиэстер, металл. Размер: 38 х 42 х 0,4 см. В набор входит ремувка. ", "unit_price": 753.0, "unit_type": "piece", "category": "Рефлектор", "formula": null, "formula_script": null, "raw_material_id": null, "material_coefficient": 1.0, "supplier_url": "https://www.oasiscatalog.com/item/1-000116758", "created_at": "2026-06-24 12:44:20+00:00"}', '{"id": 21, "name": "Светоотражающая сумка для шопинга «Neo Reflector» с ремувкой под нанесение", "description": "Светоотражающая сумка для шопинга с ремувкой под нанесение, серый светоотражающий, темно-синий. Вес 118 г, производство Китай. Материал: полиэстер, металл. Размер: 38 х 42 х 0,4 см. В набор входит ремувка. ", "unit_price": 999.0, "unit_type": "piece", "category": "Рефлектор", "formula": null, "formula_script": null, "raw_material_id": null, "material_coefficient": 1.0, "supplier_url": "https://www.oasiscatalog.com/item/1-000116758", "created_at": "2026-06-24 12:44:20+00:00"}', 1, 'Administrator', '2026-06-28T07:40:31.749104+00:00');
INSERT INTO audit_log (id, entity_type, entity_id, action, old_data, new_data, user_id, user_name, created_at) VALUES (2, 'product', 21, 'update', '{"id": 21, "name": "Светоотражающая сумка для шопинга «Neo Reflector» с ремувкой под нанесение", "description": "Светоотражающая сумка для шопинга с ремувкой под нанесение, серый светоотражающий, темно-синий. Вес 118 г, производство Китай. Материал: полиэстер, металл. Размер: 38 х 42 х 0,4 см. В набор входит ремувка. ", "unit_price": 999.0, "unit_type": "piece", "category": "Рефлектор", "formula": null, "formula_script": null, "raw_material_id": null, "material_coefficient": 1.0, "supplier_url": "https://www.oasiscatalog.com/item/1-000116758", "created_at": "2026-06-24 12:44:20+00:00"}', '{"id": 21, "name": "Светоотражающая сумка для шопинга «Neo Reflector» с ремувкой под нанесение", "description": "Светоотражающая сумка для шопинга с ремувкой под нанесение, серый светоотражающий, темно-синий. Вес 118 г, производство Китай. Материал: полиэстер, металл. Размер: 38 х 42 х 0,4 см. В набор входит ремувка. ", "unit_price": 753.0, "unit_type": "piece", "category": "Рефлектор", "formula": null, "formula_script": null, "raw_material_id": null, "material_coefficient": 1.0, "supplier_url": "https://www.oasiscatalog.com/item/1-000116758", "created_at": "2026-06-24 12:44:20+00:00"}', 1, 'Administrator', '2026-06-28T07:42:06.783839+00:00');
INSERT INTO audit_log (id, entity_type, entity_id, action, old_data, new_data, user_id, user_name, created_at) VALUES (3, 'raw_material', 1, 'update', '{"id": 1, "name": "банер 1.6", "description": null, "width_mm": null, "height_mm": null, "roll_width_m": 1.6, "roll_length_m": 50.0, "density": null, "color_finish": null, "unit_type": "piece", "unit_price": 92.0, "display_format_script": null, "stock_calculation_script": null, "created_at": "2026-06-27 11:01:34.682754+00:00"}', '{"id": 1, "name": "банер 1.6", "description": "тест аудита", "width_mm": null, "height_mm": null, "roll_width_m": 1.6, "roll_length_m": 50.0, "density": null, "color_finish": null, "unit_type": "piece", "unit_price": 92.0, "display_format_script": null, "stock_calculation_script": null, "created_at": "2026-06-27 11:01:34.682754+00:00"}', 1, 'Administrator', '2026-06-28T07:54:00.873183+00:00');
INSERT INTO audit_log (id, entity_type, entity_id, action, old_data, new_data, user_id, user_name, created_at) VALUES (4, 'raw_material', 1, 'update', '{"id": 1, "name": "банер 1.6", "description": "тест аудита", "width_mm": null, "height_mm": null, "roll_width_m": 1.6, "roll_length_m": 50.0, "density": null, "color_finish": null, "unit_type": "piece", "unit_price": 92.0, "display_format_script": null, "stock_calculation_script": null, "created_at": "2026-06-27 11:01:34.682754+00:00"}', '{"id": 1, "name": "банер 1.6", "description": null, "width_mm": null, "height_mm": null, "roll_width_m": 1.6, "roll_length_m": 50.0, "density": null, "color_finish": null, "unit_type": "piece", "unit_price": 92.0, "display_format_script": null, "stock_calculation_script": null, "created_at": "2026-06-27 11:01:34.682754+00:00"}', 1, 'Administrator', '2026-06-28T07:54:11.754267+00:00');
INSERT INTO audit_log (id, entity_type, entity_id, action, old_data, new_data, user_id, user_name, created_at) VALUES (5, 'warehouse', 23, 'update', '{"id": 23, "product_id": null, "raw_material_id": 2, "quantity": 497.5, "min_quantity": 100, "defective_quantity": 0, "defective_reason": "", "stock_calculation_script": "sheet_stock_calc", "display_format_script": null, "updated_at": "2026-06-27 19:31:26.241786+00:00"}', '{"id": 23, "product_id": null, "raw_material_id": 2, "quantity": 500.0, "min_quantity": 100, "defective_quantity": 0, "defective_reason": "", "stock_calculation_script": "sheet_stock_calc", "display_format_script": null, "updated_at": "2026-06-27 19:31:26.241786+00:00"}', 1, 'Administrator', '2026-06-28T08:11:50.809858+00:00');
INSERT INTO audit_log (id, entity_type, entity_id, action, old_data, new_data, user_id, user_name, created_at) VALUES (6, 'product', 21, 'update', '{"id": 21, "name": "Светоотражающая сумка для шопинга «Neo Reflector» с ремувкой под нанесение", "description": "Светоотражающая сумка для шопинга с ремувкой под нанесение, серый светоотражающий, темно-синий. Вес 118 г, производство Китай. Материал: полиэстер, металл. Размер: 38 х 42 х 0,4 см. В набор входит ремувка. ", "unit_price": 753.0, "unit_type": "piece", "category": "Рефлектор", "formula": null, "formula_script": null, "raw_material_id": null, "material_coefficient": 1.0, "supplier_url": "https://www.oasiscatalog.com/item/1-000116758", "created_at": "2026-06-24 12:44:20+00:00"}', '{"id": 21, "name": "Светоотражающая сумка для шопинга «Neo Reflector» с ремувкой под нанесение", "description": "Светоотражающая сумка для шопинга с ремувкой под нанесение, серый светоотражающий, темно-синий. Вес 118 г, производство Китай. Материал: полиэстер, металл. Размер: 38 х 42 х 0,4 см. В набор входит ремувка. ", "unit_price": 900.0, "unit_type": "piece", "category": "Рефлектор", "formula": null, "formula_script": null, "raw_material_id": null, "material_coefficient": 1.0, "supplier_url": "https://www.oasiscatalog.com/item/1-000116758", "created_at": "2026-06-24 12:44:20+00:00"}', 1, 'Administrator', '2026-06-28T08:16:34.540300+00:00');
INSERT INTO audit_log (id, entity_type, entity_id, action, old_data, new_data, user_id, user_name, created_at) VALUES (7, 'warehouse', 25, 'update', '{"id": 25, "product_id": null, "raw_material_id": 3, "quantity": 459.0, "min_quantity": 100, "defective_quantity": 0, "defective_reason": null, "stock_calculation_script": null, "display_format_script": null, "updated_at": "2026-06-28 10:35:25.477361+00:00"}', '{"id": 25, "product_id": null, "raw_material_id": 3, "quantity": 459.0, "min_quantity": 100, "defective_quantity": 0, "defective_reason": "", "stock_calculation_script": "sheet_stock_calc", "display_format_script": null, "updated_at": "2026-06-28 10:35:25.477361+00:00"}', 1, 'Administrator', '2026-06-28T10:47:27.224961+00:00');
INSERT INTO audit_log (id, entity_type, entity_id, action, old_data, new_data, user_id, user_name, created_at) VALUES (8, 'raw_material', 3, 'update', '{"id": 3, "name": "бумага 250 мат", "description": null, "width_mm": 450, "height_mm": 320, "roll_width_m": null, "roll_length_m": null, "density": null, "color_finish": null, "unit_type": "sheet", "unit_price": 7.5, "display_format_script": null, "stock_calculation_script": null, "created_at": "2026-06-27 19:10:12.126721+00:00"}', '{"id": 3, "name": "бумага 250 мат", "description": null, "width_mm": 450, "height_mm": 320, "roll_width_m": null, "roll_length_m": null, "density": null, "color_finish": null, "unit_type": "sheet", "unit_price": 7.5, "display_format_script": null, "stock_calculation_script": null, "created_at": "2026-06-27 19:10:12.126721+00:00"}', 1, 'Administrator', '2026-06-28T10:49:26.125905+00:00');
INSERT INTO audit_log (id, entity_type, entity_id, action, old_data, new_data, user_id, user_name, created_at) VALUES (9, 'product', 24, 'update', '{"id": 24, "name": "Диплом А4", "description": null, "unit_price": 45.33749999999999, "unit_type": "sheet", "category": null, "formula": null, "formula_script": null, "raw_material_id": 3, "material_coefficient": 1.0, "supplier_url": null, "created_at": "2026-06-27 19:12:53.502028+00:00"}', '{"id": 24, "name": "Диплом А4", "description": null, "unit_price": 45.33749999999999, "unit_type": "sheet", "category": null, "formula": null, "formula_script": null, "raw_material_id": 3, "material_coefficient": 0.5, "supplier_url": null, "created_at": "2026-06-27 19:12:53.502028+00:00"}', 1, 'Administrator', '2026-06-28T10:49:50.627915+00:00');
INSERT INTO audit_log (id, entity_type, entity_id, action, old_data, new_data, user_id, user_name, created_at) VALUES (10, 'warehouse', 25, 'update', '{"id": 25, "product_id": null, "raw_material_id": 3, "quantity": 449.0, "min_quantity": 100, "defective_quantity": 0, "defective_reason": "", "stock_calculation_script": "sheet_stock_calc", "display_format_script": null, "updated_at": "2026-06-28 10:50:16.552084+00:00"}', '{"id": 25, "product_id": null, "raw_material_id": 3, "quantity": 449.0, "min_quantity": 100, "defective_quantity": 0, "defective_reason": "", "stock_calculation_script": "sheet_stock_calc", "display_format_script": "sheet_stock_calc", "updated_at": "2026-06-28 10:50:16.552084+00:00"}', 1, 'Administrator', '2026-06-28T10:50:46.941943+00:00');
INSERT INTO audit_log (id, entity_type, entity_id, action, old_data, new_data, user_id, user_name, created_at) VALUES (11, 'warehouse', 25, 'update', '{"id": 25, "product_id": null, "raw_material_id": 3, "quantity": 449.0, "min_quantity": 100, "defective_quantity": 0, "defective_reason": "", "stock_calculation_script": "sheet_stock_calc", "display_format_script": "sheet_stock_calc", "updated_at": "2026-06-28 10:51:10.869425+00:00"}', '{"id": 25, "product_id": null, "raw_material_id": 3, "quantity": 449.0, "min_quantity": 100, "defective_quantity": 0, "defective_reason": "", "stock_calculation_script": "sheet_stock_calc", "display_format_script": "sheet_stock_calc", "updated_at": "2026-06-28 10:51:10.869425+00:00"}', 1, 'Administrator', '2026-06-28T10:52:54.160199+00:00');
INSERT INTO audit_log (id, entity_type, entity_id, action, old_data, new_data, user_id, user_name, created_at) VALUES (12, 'warehouse', 24, 'update', '{"id": 24, "product_id": null, "raw_material_id": 1, "quantity": 247.0, "min_quantity": 1, "defective_quantity": 0, "defective_reason": "", "stock_calculation_script": "roll_stock_calc", "display_format_script": null, "updated_at": "2026-06-28 08:22:04.003845+00:00"}', '{"id": 24, "product_id": null, "raw_material_id": 1, "quantity": 497.0, "min_quantity": 1, "defective_quantity": 0, "defective_reason": "", "stock_calculation_script": "roll_stock_calc", "display_format_script": null, "updated_at": "2026-06-28 08:22:04.003845+00:00"}', 1, 'Administrator', '2026-06-29T08:19:40.589902+00:00');
INSERT INTO audit_log (id, entity_type, entity_id, action, old_data, new_data, user_id, user_name, created_at) VALUES (13, 'product', 25, 'create', NULL, '{"name": "Test Multi-Material", "description": null, "unit_price": 100.0, "unit_type": "шт", "category": null, "formula": null, "formula_script": null, "raw_material_id": null, "material_coefficient": 1.0, "supplier_url": null, "raw_materials": [{"raw_material_id": 1, "coefficient": 1.5}, {"raw_material_id": 2, "coefficient": 0.5}]}', 1, 'Administrator', '2026-06-29T09:46:23.390526+00:00');
INSERT INTO audit_log (id, entity_type, entity_id, action, old_data, new_data, user_id, user_name, created_at) VALUES (14, 'product', 25, 'update', '{"id": 25, "name": "Test Multi-Material", "description": null, "unit_price": 100.0, "unit_type": "шт", "category": null, "formula": null, "formula_script": null, "raw_material_id": 1, "material_coefficient": 1.5, "supplier_url": null, "created_at": "2026-06-29 09:46:23.390526+00:00"}', '{"id": 25, "name": "Test Multi-Material v2", "description": null, "unit_price": 200.0, "unit_type": "шт", "category": null, "formula": null, "formula_script": null, "raw_material_id": 1, "material_coefficient": 1.0, "supplier_url": null, "created_at": "2026-06-29 09:46:23.390526+00:00"}', 1, 'Administrator', '2026-06-29T09:46:31.568922+00:00');
INSERT INTO audit_log (id, entity_type, entity_id, action, old_data, new_data, user_id, user_name, created_at) VALUES (15, 'product', 25, 'update', '{"id": 25, "name": "Test Multi-Material v2", "description": null, "unit_price": 200.0, "unit_type": "шт", "category": null, "formula": null, "formula_script": null, "raw_material_id": 1, "material_coefficient": 1.0, "supplier_url": null, "created_at": "2026-06-29 09:46:23.390526+00:00"}', '{"id": 25, "name": "Test Multi-Material", "description": null, "unit_price": 100.0, "unit_type": "шт", "category": null, "formula": null, "formula_script": null, "raw_material_id": 1, "material_coefficient": 1.0, "supplier_url": null, "created_at": "2026-06-29 09:46:23.390526+00:00"}', 1, 'Administrator', '2026-06-29T09:46:40.292845+00:00');
INSERT INTO audit_log (id, entity_type, entity_id, action, old_data, new_data, user_id, user_name, created_at) VALUES (16, 'product', 25, 'delete', '{"id": 25, "name": "Test Multi-Material", "description": null, "unit_price": 100.0, "unit_type": "шт", "category": null, "formula": null, "formula_script": null, "raw_material_id": 1, "material_coefficient": 1.0, "supplier_url": null, "created_at": "2026-06-29 09:46:23.390526+00:00"}', NULL, 1, 'Administrator', '2026-06-29T09:47:54.004120+00:00');
INSERT INTO audit_log (id, entity_type, entity_id, action, old_data, new_data, user_id, user_name, created_at) VALUES (17, 'product', 25, 'create', NULL, '{"name": "Баннер 1000×500", "description": null, "unit_price": 300.0, "unit_type": "шт", "category": null, "formula": null, "formula_script": null, "raw_material_id": null, "material_coefficient": 1.0, "supplier_url": null, "default_cut_width_mm": 1000.0, "default_cut_height_mm": 500.0, "raw_materials": [{"raw_material_id": 1, "coefficient": 1.0}]}', 1, 'Administrator', '2026-06-29T10:59:40.801962+00:00');
INSERT INTO audit_log (id, entity_type, entity_id, action, old_data, new_data, user_id, user_name, created_at) VALUES (18, 'product', 25, 'delete', '{"id": 25, "name": "Баннер 1000×500", "description": null, "unit_price": 300.0, "unit_type": "шт", "category": null, "formula": null, "formula_script": null, "raw_material_id": 1, "material_coefficient": 1.0, "supplier_url": null, "default_cut_width_mm": 1000.0, "default_cut_height_mm": 500.0, "created_at": "2026-06-29 10:59:40.801962+00:00"}', NULL, 1, 'Administrator', '2026-06-29T11:00:04.979935+00:00');
INSERT INTO audit_log (id, entity_type, entity_id, action, old_data, new_data, user_id, user_name, created_at) VALUES (19, 'warehouse', 25, 'update', '{"id": 25, "product_id": null, "raw_material_id": 3, "quantity": 444.0, "min_quantity": 100, "defective_quantity": 0, "defective_reason": "", "stock_calculation_script": "sheet_stock_calc", "display_format_script": "sheet_stock_calc", "updated_at": "2026-06-28 11:11:42.216837+00:00"}', '{"id": 25, "product_id": null, "raw_material_id": 3, "quantity": 450.0, "min_quantity": 100, "defective_quantity": 0, "defective_reason": "", "stock_calculation_script": "sheet_stock_calc", "display_format_script": "sheet_stock_calc", "updated_at": "2026-06-28 11:11:42.216837+00:00"}', 1, 'Administrator', '2026-06-29T13:31:55.268324+00:00');
INSERT INTO audit_log (id, entity_type, entity_id, action, old_data, new_data, user_id, user_name, created_at) VALUES (20, 'warehouse', 24, 'update', '{"id": 24, "product_id": null, "raw_material_id": 1, "quantity": 474.0, "min_quantity": 1, "defective_quantity": 0, "defective_reason": "", "stock_calculation_script": "roll_stock_calc", "display_format_script": null, "updated_at": "2026-06-29 15:15:15.767283+00:00"}', '{"id": 24, "product_id": null, "raw_material_id": 1, "quantity": 524.0, "min_quantity": 1, "defective_quantity": 0, "defective_reason": "", "stock_calculation_script": "roll_stock_calc", "display_format_script": null, "updated_at": "2026-06-29 15:15:15.767283+00:00"}', 1, 'Administrator', '2026-06-29T15:15:52.759201+00:00');
INSERT INTO audit_log (id, entity_type, entity_id, action, old_data, new_data, user_id, user_name, created_at) VALUES (37, 'raw_material', 5, 'create', NULL, '{"name": "Автотест Сырьё", "description": null, "width_mm": 1000, "height_mm": 1000, "roll_width_m": null, "roll_length_m": null, "density": null, "color_finish": null, "unit_type": "piece", "unit_price": 0.0, "display_format_script": null, "stock_calculation_script": null}', 1, 'Administrator', '2026-07-01T19:59:41.737865+00:00');
INSERT INTO audit_log (id, entity_type, entity_id, action, old_data, new_data, user_id, user_name, created_at) VALUES (21, 'product', 25, 'create', NULL, '{"name": "Диплом А4 300", "description": null, "unit_price": 40.392, "unit_type": "sheet", "category": null, "formula": null, "formula_script": null, "raw_material_id": 2, "material_coefficient": 0.5, "supplier_url": null, "default_cut_width_mm": null, "default_cut_height_mm": null, "raw_materials": [{"raw_material_id": 2, "coefficient": 0.5}]}', 1, 'Administrator', '2026-06-29T18:20:03.119069+00:00');
INSERT INTO audit_log (id, entity_type, entity_id, action, old_data, new_data, user_id, user_name, created_at) VALUES (22, 'product', 24, 'update', '{"id": 24, "name": "Диплом А4", "description": null, "unit_price": 45.33749999999999, "unit_type": "sheet", "category": null, "formula": null, "formula_script": null, "raw_material_id": 3, "material_coefficient": 0.5, "supplier_url": null, "default_cut_width_mm": null, "default_cut_height_mm": null, "created_at": "2026-06-27 19:12:53.502028+00:00"}', '{"id": 24, "name": "Диплом А4", "description": null, "unit_price": 45.33749999999999, "unit_type": "sheet", "category": null, "formula": null, "formula_script": null, "raw_material_id": 3, "material_coefficient": 0.5, "supplier_url": null, "default_cut_width_mm": 210.0, "default_cut_height_mm": 297.0, "created_at": "2026-06-27 19:12:53.502028+00:00"}', 1, 'Administrator', '2026-06-29T18:37:36.495370+00:00');
INSERT INTO audit_log (id, entity_type, entity_id, action, old_data, new_data, user_id, user_name, created_at) VALUES (23, 'product', 25, 'update', '{"id": 25, "name": "Диплом А4 300", "description": null, "unit_price": 40.392, "unit_type": "sheet", "category": null, "formula": null, "formula_script": null, "raw_material_id": 2, "material_coefficient": 0.5, "supplier_url": null, "default_cut_width_mm": null, "default_cut_height_mm": null, "created_at": "2026-06-29 18:20:03.119069+00:00"}', '{"id": 25, "name": "Диплом А4 300", "description": null, "unit_price": 40.392, "unit_type": "sheet", "category": null, "formula": null, "formula_script": null, "raw_material_id": 2, "material_coefficient": 0.5, "supplier_url": null, "default_cut_width_mm": 210.0, "default_cut_height_mm": 297.0, "created_at": "2026-06-29 18:20:03.119069+00:00"}', 1, 'Administrator', '2026-06-29T18:37:36.600043+00:00');
INSERT INTO audit_log (id, entity_type, entity_id, action, old_data, new_data, user_id, user_name, created_at) VALUES (24, 'raw_material', 1, 'update', '{"id": 1, "name": "банер 1.6", "description": null, "width_mm": null, "height_mm": null, "roll_width_m": 1.6, "roll_length_m": 50.0, "density": null, "color_finish": null, "unit_type": "piece", "unit_price": 92.0, "display_format_script": null, "stock_calculation_script": null, "created_at": "2026-06-27 11:01:34.682754+00:00"}', '{"id": 1, "name": "банер 1.6", "description": null, "width_mm": null, "height_mm": null, "roll_width_m": 1.6, "roll_length_m": 50.0, "density": null, "color_finish": null, "unit_type": "roll", "unit_price": 92.0, "display_format_script": null, "stock_calculation_script": null, "created_at": "2026-06-27 11:01:34.682754+00:00"}', 1, 'Administrator', '2026-06-29T19:20:50.520558+00:00');
INSERT INTO audit_log (id, entity_type, entity_id, action, old_data, new_data, user_id, user_name, created_at) VALUES (25, 'raw_material', 4, 'create', NULL, '{"name": "Ламинация пакетная 125 мкм", "description": null, "width_mm": 210, "height_mm": 297, "roll_width_m": null, "roll_length_m": null, "density": null, "color_finish": null, "unit_type": "sheet", "unit_price": 6.0, "display_format_script": null, "stock_calculation_script": null}', 3, 'Дмитрий', '2026-06-29T20:13:55.938290+00:00');
INSERT INTO audit_log (id, entity_type, entity_id, action, old_data, new_data, user_id, user_name, created_at) VALUES (26, 'warehouse', 26, 'create', NULL, '{"product_id": null, "raw_material_id": 4, "quantity": 250.0, "min_quantity": 125, "defective_quantity": 0, "defective_reason": null, "stock_calculation_script": null, "display_format_script": null}', 3, 'Дмитрий', '2026-06-29T20:15:55.851881+00:00');
INSERT INTO audit_log (id, entity_type, entity_id, action, old_data, new_data, user_id, user_name, created_at) VALUES (27, 'product', 26, 'create', NULL, '{"name": "Меню А4 с ламинацией 125", "description": null, "unit_price": 61.9, "unit_type": "sheet", "category": null, "formula": null, "formula_script": null, "raw_material_id": 3, "material_coefficient": 1.0, "supplier_url": null, "default_cut_width_mm": 210.0, "default_cut_height_mm": 297.0, "raw_materials": [{"raw_material_id": 3, "coefficient": 1.0}, {"raw_material_id": 4, "coefficient": 1.0}]}', 3, 'Дмитрий', '2026-06-29T20:17:40.922369+00:00');
INSERT INTO audit_log (id, entity_type, entity_id, action, old_data, new_data, user_id, user_name, created_at) VALUES (28, 'warehouse', 24, 'update', '{"id": 24, "product_id": null, "raw_material_id": 1, "quantity": 524.0, "min_quantity": 1, "defective_quantity": 0, "defective_reason": "", "stock_calculation_script": "roll_stock_calc", "display_format_script": null, "updated_at": "2026-06-29 15:15:52.759201+00:00"}', '{"id": 24, "product_id": null, "raw_material_id": 1, "quantity": 557.0, "min_quantity": 1, "defective_quantity": 0, "defective_reason": "", "stock_calculation_script": "roll_stock_calc", "display_format_script": null, "updated_at": "2026-06-29 15:15:52.759201+00:00"}', 1, 'Administrator', '2026-06-30T15:52:48.485961+00:00');
INSERT INTO audit_log (id, entity_type, entity_id, action, old_data, new_data, user_id, user_name, created_at) VALUES (29, 'warehouse', 25, 'update', '{"id": 25, "product_id": null, "raw_material_id": 3, "quantity": 0.0, "min_quantity": 100, "defective_quantity": 0, "defective_reason": "", "stock_calculation_script": "sheet_stock_calc", "display_format_script": "sheet_stock_calc", "updated_at": "2026-07-01 18:23:03.449324+00:00"}', '{"id": 25, "product_id": null, "raw_material_id": 3, "quantity": 500.0, "min_quantity": 100, "defective_quantity": 0, "defective_reason": "", "stock_calculation_script": "sheet_stock_calc", "display_format_script": "sheet_stock_calc", "updated_at": "2026-07-01 18:23:03.449324+00:00"}', 1, 'Administrator', '2026-07-01T18:45:48.931842+00:00');
INSERT INTO audit_log (id, entity_type, entity_id, action, old_data, new_data, user_id, user_name, created_at) VALUES (30, 'product', 27, 'create', NULL, '{"name": "Автотест Продукт A4", "description": null, "unit_price": 100.0, "unit_type": "sheet", "category": null, "formula": null, "formula_script": null, "raw_material_id": null, "material_coefficient": 1.0, "supplier_url": null, "default_cut_width_mm": 210.0, "default_cut_height_mm": 297.0, "raw_materials": []}', 1, 'Administrator', '2026-07-01T19:59:41.244026+00:00');
INSERT INTO audit_log (id, entity_type, entity_id, action, old_data, new_data, user_id, user_name, created_at) VALUES (31, 'product', 28, 'create', NULL, '{"name": "Продукт с сырьём", "description": null, "unit_price": 50.0, "unit_type": "sheet", "category": null, "formula": null, "formula_script": null, "raw_material_id": 1, "material_coefficient": 1.0, "supplier_url": null, "default_cut_width_mm": null, "default_cut_height_mm": null, "raw_materials": []}', 1, 'Administrator', '2026-07-01T19:59:41.310924+00:00');
INSERT INTO audit_log (id, entity_type, entity_id, action, old_data, new_data, user_id, user_name, created_at) VALUES (32, 'product', 29, 'create', NULL, '{"name": "До обновления", "description": null, "unit_price": 10.0, "unit_type": "sheet", "category": null, "formula": null, "formula_script": null, "raw_material_id": null, "material_coefficient": 1.0, "supplier_url": null, "default_cut_width_mm": null, "default_cut_height_mm": null, "raw_materials": []}', 1, 'Administrator', '2026-07-01T19:59:41.350171+00:00');
INSERT INTO audit_log (id, entity_type, entity_id, action, old_data, new_data, user_id, user_name, created_at) VALUES (33, 'product', 29, 'update', '{"id": 29, "name": "До обновления", "description": null, "unit_price": 10.0, "unit_type": "sheet", "category": null, "formula": null, "formula_script": null, "raw_material_id": null, "material_coefficient": 1.0, "supplier_url": null, "default_cut_width_mm": null, "default_cut_height_mm": null, "created_at": "2026-07-01 19:59:41.350171+00:00"}', '{"id": 29, "name": "После обновления", "description": null, "unit_price": 20.0, "unit_type": "sheet", "category": null, "formula": null, "formula_script": null, "raw_material_id": null, "material_coefficient": 1.0, "supplier_url": null, "default_cut_width_mm": null, "default_cut_height_mm": null, "created_at": "2026-07-01 19:59:41.350171+00:00"}', 1, 'Administrator', '2026-07-01T19:59:41.381090+00:00');
INSERT INTO audit_log (id, entity_type, entity_id, action, old_data, new_data, user_id, user_name, created_at) VALUES (34, 'product', 30, 'create', NULL, '{"name": "Удаляемый", "description": null, "unit_price": 1.0, "unit_type": "sheet", "category": null, "formula": null, "formula_script": null, "raw_material_id": null, "material_coefficient": 1.0, "supplier_url": null, "default_cut_width_mm": null, "default_cut_height_mm": null, "raw_materials": []}', 1, 'Administrator', '2026-07-01T19:59:41.422925+00:00');
INSERT INTO audit_log (id, entity_type, entity_id, action, old_data, new_data, user_id, user_name, created_at) VALUES (35, 'product', 30, 'delete', '{"id": 30, "name": "Удаляемый", "description": null, "unit_price": 1.0, "unit_type": "sheet", "category": null, "formula": null, "formula_script": null, "raw_material_id": null, "material_coefficient": 1.0, "supplier_url": null, "default_cut_width_mm": null, "default_cut_height_mm": null, "created_at": "2026-07-01 19:59:41.422925+00:00"}', NULL, 1, 'Administrator', '2026-07-01T19:59:41.447875+00:00');
INSERT INTO audit_log (id, entity_type, entity_id, action, old_data, new_data, user_id, user_name, created_at) VALUES (36, 'warehouse', 23, 'update', '{"id": 23, "product_id": null, "raw_material_id": 2, "quantity": 450.1667, "min_quantity": 100, "defective_quantity": 0, "defective_reason": "", "stock_calculation_script": "sheet_stock_calc", "display_format_script": null, "updated_at": "2026-07-01 17:50:38.456315+00:00"}', '{"id": 23, "product_id": null, "raw_material_id": 2, "quantity": 500.1667, "min_quantity": 100, "defective_quantity": 0, "defective_reason": "", "stock_calculation_script": "sheet_stock_calc", "display_format_script": null, "updated_at": "2026-07-01 17:50:38.456315+00:00"}', 1, 'Administrator', '2026-07-01T19:59:41.640938+00:00');
INSERT INTO audit_log (id, entity_type, entity_id, action, old_data, new_data, user_id, user_name, created_at) VALUES (38, 'raw_material', 6, 'create', NULL, '{"name": "Удаляемое сырьё", "description": null, "width_mm": null, "height_mm": null, "roll_width_m": null, "roll_length_m": null, "density": null, "color_finish": null, "unit_type": "piece", "unit_price": 0.0, "display_format_script": null, "stock_calculation_script": null}', 1, 'Administrator', '2026-07-01T19:59:41.784160+00:00');
INSERT INTO audit_log (id, entity_type, entity_id, action, old_data, new_data, user_id, user_name, created_at) VALUES (39, 'product', 31, 'create', NULL, '{"name": "Автотест Продукт A4", "description": null, "unit_price": 100.0, "unit_type": "sheet", "category": null, "formula": null, "formula_script": null, "raw_material_id": null, "material_coefficient": 1.0, "supplier_url": null, "default_cut_width_mm": 210.0, "default_cut_height_mm": 297.0, "raw_materials": []}', 1, 'Administrator', '2026-07-01T20:01:46.082981+00:00');
INSERT INTO audit_log (id, entity_type, entity_id, action, old_data, new_data, user_id, user_name, created_at) VALUES (40, 'product', 32, 'create', NULL, '{"name": "Продукт с сырьём", "description": null, "unit_price": 50.0, "unit_type": "sheet", "category": null, "formula": null, "formula_script": null, "raw_material_id": 1, "material_coefficient": 1.0, "supplier_url": null, "default_cut_width_mm": null, "default_cut_height_mm": null, "raw_materials": []}', 1, 'Administrator', '2026-07-01T20:01:46.144766+00:00');
INSERT INTO audit_log (id, entity_type, entity_id, action, old_data, new_data, user_id, user_name, created_at) VALUES (41, 'product', 33, 'create', NULL, '{"name": "До обновления", "description": null, "unit_price": 10.0, "unit_type": "sheet", "category": null, "formula": null, "formula_script": null, "raw_material_id": null, "material_coefficient": 1.0, "supplier_url": null, "default_cut_width_mm": null, "default_cut_height_mm": null, "raw_materials": []}', 1, 'Administrator', '2026-07-01T20:01:46.176873+00:00');
INSERT INTO audit_log (id, entity_type, entity_id, action, old_data, new_data, user_id, user_name, created_at) VALUES (42, 'product', 33, 'update', '{"id": 33, "name": "До обновления", "description": null, "unit_price": 10.0, "unit_type": "sheet", "category": null, "formula": null, "formula_script": null, "raw_material_id": null, "material_coefficient": 1.0, "supplier_url": null, "default_cut_width_mm": null, "default_cut_height_mm": null, "created_at": "2026-07-01 20:01:46.176873+00:00"}', '{"id": 33, "name": "После обновления", "description": null, "unit_price": 20.0, "unit_type": "sheet", "category": null, "formula": null, "formula_script": null, "raw_material_id": null, "material_coefficient": 1.0, "supplier_url": null, "default_cut_width_mm": null, "default_cut_height_mm": null, "created_at": "2026-07-01 20:01:46.176873+00:00"}', 1, 'Administrator', '2026-07-01T20:01:46.201834+00:00');
INSERT INTO audit_log (id, entity_type, entity_id, action, old_data, new_data, user_id, user_name, created_at) VALUES (43, 'product', 34, 'create', NULL, '{"name": "Удаляемый", "description": null, "unit_price": 1.0, "unit_type": "sheet", "category": null, "formula": null, "formula_script": null, "raw_material_id": null, "material_coefficient": 1.0, "supplier_url": null, "default_cut_width_mm": null, "default_cut_height_mm": null, "raw_materials": []}', 1, 'Administrator', '2026-07-01T20:01:46.238877+00:00');
INSERT INTO audit_log (id, entity_type, entity_id, action, old_data, new_data, user_id, user_name, created_at) VALUES (44, 'product', 34, 'delete', '{"id": 34, "name": "Удаляемый", "description": null, "unit_price": 1.0, "unit_type": "sheet", "category": null, "formula": null, "formula_script": null, "raw_material_id": null, "material_coefficient": 1.0, "supplier_url": null, "default_cut_width_mm": null, "default_cut_height_mm": null, "created_at": "2026-07-01 20:01:46.238877+00:00"}', NULL, 1, 'Administrator', '2026-07-01T20:01:46.262904+00:00');
INSERT INTO audit_log (id, entity_type, entity_id, action, old_data, new_data, user_id, user_name, created_at) VALUES (45, 'warehouse', 27, 'create', NULL, '{"product_id": null, "raw_material_id": 5, "quantity": 100.0, "min_quantity": 10, "defective_quantity": 0, "defective_reason": null, "stock_calculation_script": null, "display_format_script": null}', 1, 'Administrator', '2026-07-01T20:01:46.420134+00:00');
INSERT INTO audit_log (id, entity_type, entity_id, action, old_data, new_data, user_id, user_name, created_at) VALUES (46, 'warehouse', 23, 'update', '{"id": 23, "product_id": null, "raw_material_id": 2, "quantity": 500.1667, "min_quantity": 100, "defective_quantity": 0, "defective_reason": "", "stock_calculation_script": "sheet_stock_calc", "display_format_script": null, "updated_at": "2026-07-01 19:59:41.640938+00:00"}', '{"id": 23, "product_id": null, "raw_material_id": 2, "quantity": 550.1667, "min_quantity": 100, "defective_quantity": 0, "defective_reason": "", "stock_calculation_script": "sheet_stock_calc", "display_format_script": null, "updated_at": "2026-07-01 19:59:41.640938+00:00"}', 1, 'Administrator', '2026-07-01T20:01:46.486949+00:00');
INSERT INTO audit_log (id, entity_type, entity_id, action, old_data, new_data, user_id, user_name, created_at) VALUES (47, 'raw_material', 7, 'create', NULL, '{"name": "Автотест Сырьё", "description": null, "width_mm": 1000, "height_mm": 1000, "roll_width_m": null, "roll_length_m": null, "density": null, "color_finish": null, "unit_type": "piece", "unit_price": 0.0, "display_format_script": null, "stock_calculation_script": null}', 1, 'Administrator', '2026-07-01T20:01:46.574901+00:00');
INSERT INTO audit_log (id, entity_type, entity_id, action, old_data, new_data, user_id, user_name, created_at) VALUES (48, 'raw_material', 8, 'create', NULL, '{"name": "Удаляемое сырьё", "description": null, "width_mm": null, "height_mm": null, "roll_width_m": null, "roll_length_m": null, "density": null, "color_finish": null, "unit_type": "piece", "unit_price": 0.0, "display_format_script": null, "stock_calculation_script": null}', 1, 'Administrator', '2026-07-01T20:01:46.609509+00:00');
INSERT INTO audit_log (id, entity_type, entity_id, action, old_data, new_data, user_id, user_name, created_at) VALUES (49, 'raw_material', 8, 'delete', '{"id": 8, "name": "Удаляемое сырьё", "description": null, "width_mm": null, "height_mm": null, "roll_width_m": null, "roll_length_m": null, "density": null, "color_finish": null, "unit_type": "piece", "unit_price": 0.0, "display_format_script": null, "stock_calculation_script": null, "created_at": "2026-07-01 20:01:46.609509+00:00"}', NULL, 1, 'Administrator', '2026-07-01T20:01:46.635860+00:00');
INSERT INTO audit_log (id, entity_type, entity_id, action, old_data, new_data, user_id, user_name, created_at) VALUES (50, 'product', 33, 'delete', '{"id": 33, "name": "После обновления", "description": null, "unit_price": 20.0, "unit_type": "sheet", "category": null, "formula": null, "formula_script": null, "raw_material_id": null, "material_coefficient": 1.0, "supplier_url": null, "default_cut_width_mm": null, "default_cut_height_mm": null, "created_at": "2026-07-01 20:01:46.176873+00:00"}', NULL, 1, 'Administrator', '2026-07-02T20:32:54.478474+00:00');
INSERT INTO audit_log (id, entity_type, entity_id, action, old_data, new_data, user_id, user_name, created_at) VALUES (51, 'product', 32, 'delete', '{"id": 32, "name": "Продукт с сырьём", "description": null, "unit_price": 50.0, "unit_type": "sheet", "category": null, "formula": null, "formula_script": null, "raw_material_id": 1, "material_coefficient": 1.0, "supplier_url": null, "default_cut_width_mm": null, "default_cut_height_mm": null, "created_at": "2026-07-01 20:01:46.144766+00:00"}', NULL, 1, 'Administrator', '2026-07-02T20:33:04.651373+00:00');
INSERT INTO audit_log (id, entity_type, entity_id, action, old_data, new_data, user_id, user_name, created_at) VALUES (52, 'product', 31, 'delete', '{"id": 31, "name": "Автотест Продукт A4", "description": null, "unit_price": 100.0, "unit_type": "sheet", "category": null, "formula": null, "formula_script": null, "raw_material_id": null, "material_coefficient": 1.0, "supplier_url": null, "default_cut_width_mm": 210.0, "default_cut_height_mm": 297.0, "created_at": "2026-07-01 20:01:46.082981+00:00"}', NULL, 1, 'Administrator', '2026-07-02T20:33:05.986918+00:00');
INSERT INTO audit_log (id, entity_type, entity_id, action, old_data, new_data, user_id, user_name, created_at) VALUES (53, 'product', 29, 'delete', '{"id": 29, "name": "После обновления", "description": null, "unit_price": 20.0, "unit_type": "sheet", "category": null, "formula": null, "formula_script": null, "raw_material_id": null, "material_coefficient": 1.0, "supplier_url": null, "default_cut_width_mm": null, "default_cut_height_mm": null, "created_at": "2026-07-01 19:59:41.350171+00:00"}', NULL, 1, 'Administrator', '2026-07-02T20:33:08.237430+00:00');
INSERT INTO audit_log (id, entity_type, entity_id, action, old_data, new_data, user_id, user_name, created_at) VALUES (54, 'product', 28, 'delete', '{"id": 28, "name": "Продукт с сырьём", "description": null, "unit_price": 50.0, "unit_type": "sheet", "category": null, "formula": null, "formula_script": null, "raw_material_id": 1, "material_coefficient": 1.0, "supplier_url": null, "default_cut_width_mm": null, "default_cut_height_mm": null, "created_at": "2026-07-01 19:59:41.310924+00:00"}', NULL, 1, 'Administrator', '2026-07-02T20:33:17.364988+00:00');
INSERT INTO audit_log (id, entity_type, entity_id, action, old_data, new_data, user_id, user_name, created_at) VALUES (55, 'product', 27, 'delete', '{"id": 27, "name": "Автотест Продукт A4", "description": null, "unit_price": 100.0, "unit_type": "sheet", "category": null, "formula": null, "formula_script": null, "raw_material_id": null, "material_coefficient": 1.0, "supplier_url": null, "default_cut_width_mm": 210.0, "default_cut_height_mm": 297.0, "created_at": "2026-07-01 19:59:41.244026+00:00"}', NULL, 1, 'Administrator', '2026-07-02T20:33:24.405932+00:00');
INSERT INTO audit_log (id, entity_type, entity_id, action, old_data, new_data, user_id, user_name, created_at) VALUES (56, 'product', 24, 'update', '{"id": 24, "name": "Диплом А4", "description": null, "unit_price": 45.33749999999999, "unit_type": "sheet", "category": null, "formula": null, "formula_script": null, "raw_material_id": 3, "material_coefficient": 0.5, "supplier_url": null, "default_cut_width_mm": 210.0, "default_cut_height_mm": 297.0, "created_at": "2026-06-27 19:12:53.502028+00:00"}', '{"id": 24, "name": "Диплом А4", "description": null, "unit_price": 45.0, "unit_type": "sheet", "category": null, "formula": null, "formula_script": null, "raw_material_id": 3, "material_coefficient": 0.5, "supplier_url": null, "default_cut_width_mm": 210.0, "default_cut_height_mm": 297.0, "created_at": "2026-06-27 19:12:53.502028+00:00"}', 4, 'Даша', '2026-07-03T14:32:52.716209+00:00');
INSERT INTO audit_log (id, entity_type, entity_id, action, old_data, new_data, user_id, user_name, created_at) VALUES (57, 'raw_material', 8, 'create', NULL, '{"name": "акрил 3 мм прозрачный", "description": null, "width_mm": 3000, "height_mm": 2000, "roll_width_m": null, "roll_length_m": null, "density": null, "color_finish": null, "unit_type": "sheet", "unit_price": 7500.0, "display_format_script": null, "stock_calculation_script": null}', 1, 'Administrator', '2026-07-04T08:43:21.731222+00:00');
INSERT INTO audit_log (id, entity_type, entity_id, action, old_data, new_data, user_id, user_name, created_at) VALUES (58, 'warehouse', 28, 'create', NULL, '{"product_id": null, "raw_material_id": 8, "quantity": 3.0, "min_quantity": 1, "defective_quantity": 0, "defective_reason": null, "stock_calculation_script": null, "display_format_script": null}', 1, 'Administrator', '2026-07-04T08:43:30.764212+00:00');
INSERT INTO audit_log (id, entity_type, entity_id, action, old_data, new_data, user_id, user_name, created_at) VALUES (59, 'warehouse', 28, 'update', '{"id": 28, "product_id": null, "raw_material_id": 8, "quantity": 3.0, "min_quantity": 1, "defective_quantity": 0, "defective_reason": null, "stock_calculation_script": null, "display_format_script": null, "updated_at": "2026-07-04 08:43:30.764212+00:00"}', '{"id": 28, "product_id": null, "raw_material_id": 8, "quantity": 3.0, "min_quantity": 1, "defective_quantity": 0, "defective_reason": "", "stock_calculation_script": "sheet_stock_calc", "display_format_script": "sheet_stock_calc", "updated_at": "2026-07-04 08:43:30.764212+00:00"}', 1, 'Administrator', '2026-07-04T08:44:21.000440+00:00');
INSERT INTO audit_log (id, entity_type, entity_id, action, old_data, new_data, user_id, user_name, created_at) VALUES (60, 'warehouse', 28, 'update', '{"id": 28, "product_id": null, "raw_material_id": 8, "quantity": 2.708333, "min_quantity": 1, "defective_quantity": 0, "defective_reason": "", "stock_calculation_script": "sheet_stock_calc", "display_format_script": "sheet_stock_calc", "updated_at": "2026-07-04 19:12:54.988371+00:00"}', '{"id": 28, "product_id": null, "raw_material_id": 8, "quantity": 2.71, "min_quantity": 1, "defective_quantity": 0, "defective_reason": "", "stock_calculation_script": "sheet_stock_calc_v2", "display_format_script": "sheet_stock_calc_v2", "updated_at": "2026-07-04 19:12:54.988371+00:00"}', 1, 'Administrator', '2026-07-04T19:14:01.080781+00:00');
INSERT INTO audit_log (id, entity_type, entity_id, action, old_data, new_data, user_id, user_name, created_at) VALUES (61, 'warehouse', 28, 'update', '{"id": 28, "product_id": null, "raw_material_id": 8, "quantity": 2.71, "min_quantity": 1, "defective_quantity": 0, "defective_reason": "", "stock_calculation_script": "sheet_stock_calc_v2", "display_format_script": "sheet_stock_calc_v2", "updated_at": "2026-07-04 19:14:01.080781+00:00"}', '{"id": 28, "product_id": null, "raw_material_id": 8, "quantity": 3.0, "min_quantity": 1, "defective_quantity": 0, "defective_reason": "", "stock_calculation_script": "sheet_stock_calc_v2", "display_format_script": "sheet_stock_calc_v2", "updated_at": "2026-07-04 19:14:01.080781+00:00"}', 1, 'Administrator', '2026-07-04T19:14:13.914917+00:00');
INSERT INTO audit_log (id, entity_type, entity_id, action, old_data, new_data, user_id, user_name, created_at) VALUES (62, 'warehouse', 28, 'update', '{"id": 28, "product_id": null, "raw_material_id": 8, "quantity": 2.5, "min_quantity": 1, "defective_quantity": 0, "defective_reason": "", "stock_calculation_script": "sheet_stock_calc_v2", "display_format_script": "sheet_stock_calc_v2", "updated_at": "2026-07-04 19:21:09.615545+00:00"}', '{"id": 28, "product_id": null, "raw_material_id": 8, "quantity": 2.5, "min_quantity": 1, "defective_quantity": 0, "defective_reason": "", "stock_calculation_script": "sheet_stock_calc_v2", "display_format_script": "sheet_stock_calc_v2", "updated_at": "2026-07-04 19:21:09.615545+00:00"}', 1, 'Administrator', '2026-07-04T20:05:28.851946+00:00');
INSERT INTO audit_log (id, entity_type, entity_id, action, old_data, new_data, user_id, user_name, created_at) VALUES (63, 'warehouse', 28, 'update', '{"id": 28, "product_id": null, "raw_material_id": 8, "quantity": 2.5, "min_quantity": 1, "defective_quantity": 0, "defective_reason": "", "stock_calculation_script": "sheet_stock_calc_v2", "display_format_script": "sheet_stock_calc_v2", "updated_at": "2026-07-04 19:21:09.615545+00:00"}', '{"id": 28, "product_id": null, "raw_material_id": 8, "quantity": 3.0, "min_quantity": 1, "defective_quantity": 0, "defective_reason": "", "stock_calculation_script": "sheet_stock_calc_v2", "display_format_script": "sheet_stock_calc_v2", "updated_at": "2026-07-04 19:21:09.615545+00:00"}', 1, 'Administrator', '2026-07-04T20:05:37.745532+00:00');
INSERT INTO audit_log (id, entity_type, entity_id, action, old_data, new_data, user_id, user_name, created_at) VALUES (64, 'warehouse', 28, 'update', '{"id": 28, "product_id": null, "raw_material_id": 8, "quantity": 2.5, "min_quantity": 1, "defective_quantity": 0, "defective_reason": "", "stock_calculation_script": "sheet_stock_calc_v2", "display_format_script": "sheet_stock_calc_v2", "updated_at": "2026-07-04 20:06:43.091715+00:00"}', '{"id": 28, "product_id": null, "raw_material_id": 8, "quantity": 3.0, "min_quantity": 1, "defective_quantity": 0, "defective_reason": "", "stock_calculation_script": "sheet_stock_calc_v2", "display_format_script": "sheet_stock_calc_v2", "updated_at": "2026-07-04 20:06:43.091715+00:00"}', 1, 'Administrator', '2026-07-04T20:21:00.507954+00:00');
INSERT INTO audit_log (id, entity_type, entity_id, action, old_data, new_data, user_id, user_name, created_at) VALUES (65, 'warehouse', 28, 'update', '{"id": 28, "product_id": null, "raw_material_id": 8, "quantity": 0.0, "min_quantity": 1, "defective_quantity": 0, "defective_reason": "", "stock_calculation_script": "sheet_stock_calc_v2", "display_format_script": "sheet_stock_calc_v2", "updated_at": "2026-07-04 20:43:53.582519+00:00"}', '{"id": 28, "product_id": null, "raw_material_id": 8, "quantity": 5.0, "min_quantity": 1, "defective_quantity": 0, "defective_reason": "", "stock_calculation_script": "sheet_stock_calc_v2", "display_format_script": "sheet_stock_calc_v2", "updated_at": "2026-07-04 20:43:53.582519+00:00"}', 1, 'Administrator', '2026-07-04T20:44:22.328287+00:00');
INSERT INTO audit_log (id, entity_type, entity_id, action, old_data, new_data, user_id, user_name, created_at) VALUES (66, 'warehouse', 28, 'update', '{"id": 28, "product_id": null, "raw_material_id": 8, "quantity": 0.0, "min_quantity": 1, "defective_quantity": 0, "defective_reason": "", "stock_calculation_script": "sheet_stock_calc_v2", "display_format_script": "sheet_stock_calc_v2", "updated_at": "2026-07-04 22:10:51.567906+00:00"}', '{"id": 28, "product_id": null, "raw_material_id": 8, "quantity": 50.0, "min_quantity": 1, "defective_quantity": 0, "defective_reason": "", "stock_calculation_script": "sheet_stock_calc_v2", "display_format_script": "sheet_stock_calc_v2", "updated_at": "2026-07-04 22:10:51.567906+00:00"}', 1, 'Administrator', '2026-07-04T22:17:42.383914+00:00');
INSERT INTO audit_log (id, entity_type, entity_id, action, old_data, new_data, user_id, user_name, created_at) VALUES (67, 'warehouse', 28, 'update', '{"id": 28, "product_id": null, "raw_material_id": 8, "quantity": 44.9664, "min_quantity": 1, "defective_quantity": 0, "defective_reason": "", "stock_calculation_script": "sheet_stock_calc_v2", "display_format_script": "sheet_stock_calc_v2", "updated_at": "2026-07-06 07:42:40.059093+00:00"}', '{"id": 28, "product_id": null, "raw_material_id": 8, "quantity": 45.0, "min_quantity": 1, "defective_quantity": 0, "defective_reason": "", "stock_calculation_script": "sheet_stock_calc_v2", "display_format_script": "sheet_stock_calc_v2", "updated_at": "2026-07-06 07:42:40.059093+00:00"}', 1, 'Administrator', '2026-07-06T11:01:14.067059+00:00');
INSERT INTO audit_log (id, entity_type, entity_id, action, old_data, new_data, user_id, user_name, created_at) VALUES (68, 'product', 27, 'create', NULL, '{"name": "Попсокет", "description": null, "unit_price": 49.0, "unit_type": "piece", "category": null, "formula": null, "formula_script": null, "raw_material_id": null, "material_coefficient": 1.0, "supplier_url": "https://www.oasiscatalog.com/item/1-000037943", "default_cut_width_mm": null, "default_cut_height_mm": null, "raw_materials": []}', 1, 'Administrator', '2026-07-08T08:40:27.739298+00:00');
INSERT INTO audit_log (id, entity_type, entity_id, action, old_data, new_data, user_id, user_name, created_at) VALUES (69, 'product', 27, 'update', '{"id": 27, "name": "Попсокет", "description": null, "unit_price": 49.0, "unit_type": "piece", "category": null, "formula": null, "formula_script": null, "raw_material_id": null, "material_coefficient": 1.0, "supplier_url": "https://www.oasiscatalog.com/item/1-000037943", "default_cut_width_mm": null, "default_cut_height_mm": null, "created_at": "2026-07-08 08:40:27.739298+00:00"}', '{"id": 27, "name": "Попсокет", "description": null, "unit_price": 90.0, "unit_type": "piece", "category": null, "formula": null, "formula_script": null, "raw_material_id": null, "material_coefficient": 1.0, "supplier_url": "https://www.oasiscatalog.com/item/1-000037943", "default_cut_width_mm": null, "default_cut_height_mm": null, "created_at": "2026-07-08 08:40:27.739298+00:00"}', 8, 'Дарья', '2026-07-08T09:28:07.871977+00:00');
INSERT INTO audit_log (id, entity_type, entity_id, action, old_data, new_data, user_id, user_name, created_at) VALUES (70, 'raw_material', 9, 'create', NULL, '{"name": "Бумага 300 мат", "description": null, "width_mm": 450, "height_mm": 320, "roll_width_m": null, "roll_length_m": null, "density": null, "color_finish": null, "unit_type": "sheet", "unit_price": 0.0, "display_format_script": null, "stock_calculation_script": null}', 1, 'Administrator', '2026-07-08T10:11:40.874904+00:00');
INSERT INTO audit_log (id, entity_type, entity_id, action, old_data, new_data, user_id, user_name, created_at) VALUES (71, 'warehouse', 29, 'create', NULL, '{"product_id": null, "raw_material_id": 9, "quantity": 530.0, "min_quantity": 100, "defective_quantity": 0, "defective_reason": null, "stock_calculation_script": null, "display_format_script": null}', 1, 'Administrator', '2026-07-08T10:12:33.111154+00:00');
INSERT INTO audit_log (id, entity_type, entity_id, action, old_data, new_data, user_id, user_name, created_at) VALUES (72, 'warehouse', 29, 'update', '{"id": 29, "product_id": null, "raw_material_id": 9, "quantity": 530.0, "min_quantity": 100, "defective_quantity": 0, "defective_reason": null, "stock_calculation_script": null, "display_format_script": null, "updated_at": "2026-07-08 10:12:33.111154+00:00"}', '{"id": 29, "product_id": null, "raw_material_id": 9, "quantity": 530.0, "min_quantity": 100, "defective_quantity": 0, "defective_reason": "", "stock_calculation_script": "sheet_stock_calc", "display_format_script": "sheet_stock_calc", "updated_at": "2026-07-08 10:12:33.111154+00:00"}', 1, 'Administrator', '2026-07-08T10:12:54.157298+00:00');
INSERT INTO audit_log (id, entity_type, entity_id, action, old_data, new_data, user_id, user_name, created_at) VALUES (73, 'warehouse', 30, 'create', NULL, '{"product_id": 27, "raw_material_id": null, "quantity": 200.0, "min_quantity": 100, "defective_quantity": 0, "defective_reason": "", "stock_calculation_script": null, "display_format_script": null}', 1, 'Administrator', '2026-07-08T10:14:56.528296+00:00');
INSERT INTO audit_log (id, entity_type, entity_id, action, old_data, new_data, user_id, user_name, created_at) VALUES (74, 'raw_material', 10, 'create', NULL, '{"name": "Акрил 4 мм Белый", "description": null, "width_mm": 3000, "height_mm": 2000, "roll_width_m": null, "roll_length_m": null, "density": null, "color_finish": null, "unit_type": "sheet", "unit_price": 0.0, "display_format_script": null, "stock_calculation_script": null}', 1, 'Administrator', '2026-07-08T10:59:17.040241+00:00');
INSERT INTO audit_log (id, entity_type, entity_id, action, old_data, new_data, user_id, user_name, created_at) VALUES (75, 'warehouse', 31, 'create', NULL, '{"product_id": null, "raw_material_id": 10, "quantity": 1.0, "min_quantity": 1, "defective_quantity": 0, "defective_reason": null, "stock_calculation_script": null, "display_format_script": null}', 1, 'Administrator', '2026-07-08T10:59:29.470462+00:00');
INSERT INTO audit_log (id, entity_type, entity_id, action, old_data, new_data, user_id, user_name, created_at) VALUES (76, 'product', 28, 'create', NULL, '{"name": "Канрандаш", "description": "карандаш с цветной уф-печатью с одной стороны", "unit_price": 45.0, "unit_type": "piece", "category": null, "formula": null, "formula_script": null, "raw_material_id": null, "material_coefficient": 1.0, "supplier_url": "https://www.oasiscatalog.com/item/1-000096232", "default_cut_width_mm": null, "default_cut_height_mm": null, "raw_materials": []}', 8, 'Дарья', '2026-07-08T12:50:04.725071+00:00');
INSERT INTO audit_log (id, entity_type, entity_id, action, old_data, new_data, user_id, user_name, created_at) VALUES (77, 'product', 29, 'create', NULL, '{"name": "Бутылка с гравировкой на крышке", "description": null, "unit_price": 395.0, "unit_type": "piece", "category": null, "formula": null, "formula_script": null, "raw_material_id": null, "material_coefficient": 1.0, "supplier_url": "https://www.oasiscatalog.com/item/1-000058567", "default_cut_width_mm": null, "default_cut_height_mm": null, "raw_materials": []}', 8, 'Дарья', '2026-07-08T12:55:54.609957+00:00');
INSERT INTO audit_log (id, entity_type, entity_id, action, old_data, new_data, user_id, user_name, created_at) VALUES (78, 'product', 30, 'create', NULL, '{"name": "Бутылка с металл крышкой УФ-печать", "description": null, "unit_price": 450.0, "unit_type": "piece", "category": null, "formula": null, "formula_script": null, "raw_material_id": null, "material_coefficient": 1.0, "supplier_url": "https://www.oasiscatalog.com/item/1-000058567", "default_cut_width_mm": null, "default_cut_height_mm": null, "raw_materials": []}', 8, 'Дарья', '2026-07-08T13:03:03.529969+00:00');
INSERT INTO audit_log (id, entity_type, entity_id, action, old_data, new_data, user_id, user_name, created_at) VALUES (79, 'warehouse', 31, 'update', '{"id": 31, "product_id": null, "raw_material_id": 10, "quantity": 0.969985, "min_quantity": 1, "defective_quantity": 0, "defective_reason": null, "stock_calculation_script": null, "display_format_script": null, "updated_at": "2026-07-08 13:03:24.376483+00:00"}', '{"id": 31, "product_id": null, "raw_material_id": 10, "quantity": 1.0, "min_quantity": 1, "defective_quantity": 0, "defective_reason": "", "stock_calculation_script": "sheet_stock_calc_v2", "display_format_script": "sheet_stock_calc_v2", "updated_at": "2026-07-08 13:03:24.376483+00:00"}', 1, 'Administrator', '2026-07-08T13:03:56.971353+00:00');
INSERT INTO audit_log (id, entity_type, entity_id, action, old_data, new_data, user_id, user_name, created_at) VALUES (80, 'product', 31, 'create', NULL, '{"name": "бутылка пластик прозрачная", "description": "пластик с уф-печатью ", "unit_price": 400.0, "unit_type": "piece", "category": null, "formula": null, "formula_script": null, "raw_material_id": null, "material_coefficient": 1.0, "supplier_url": "https://www.oasiscatalog.com/item/1-000037895", "default_cut_width_mm": null, "default_cut_height_mm": null, "raw_materials": []}', 8, 'Дарья', '2026-07-08T13:06:01.812195+00:00');
INSERT INTO audit_log (id, entity_type, entity_id, action, old_data, new_data, user_id, user_name, created_at) VALUES (81, 'product', 31, 'update', '{"id": 31, "name": "бутылка пластик прозрачная", "description": "пластик с уф-печатью ", "unit_price": 400.0, "unit_type": "piece", "category": null, "formula": null, "formula_script": null, "raw_material_id": null, "material_coefficient": 1.0, "supplier_url": "https://www.oasiscatalog.com/item/1-000037895", "default_cut_width_mm": null, "default_cut_height_mm": null, "created_at": "2026-07-08 13:06:01.812195+00:00"}', '{"id": 31, "name": "Бутылка пластик прозрачная", "description": "пластик с уф-печатью ", "unit_price": 400.0, "unit_type": "piece", "category": null, "formula": null, "formula_script": null, "raw_material_id": null, "material_coefficient": 1.0, "supplier_url": "https://www.oasiscatalog.com/item/1-000037895", "default_cut_width_mm": null, "default_cut_height_mm": null, "created_at": "2026-07-08 13:06:01.812195+00:00"}', 8, 'Дарья', '2026-07-08T13:07:24.581038+00:00');
INSERT INTO audit_log (id, entity_type, entity_id, action, old_data, new_data, user_id, user_name, created_at) VALUES (82, 'warehouse', 31, 'update', '{"id": 31, "product_id": null, "raw_material_id": 10, "quantity": 1.9699849999999999, "min_quantity": 1, "defective_quantity": 0, "defective_reason": "", "stock_calculation_script": "sheet_stock_calc_v2", "display_format_script": "sheet_stock_calc_v2", "updated_at": "2026-07-08 13:04:10.813773+00:00"}', '{"id": 31, "product_id": null, "raw_material_id": 10, "quantity": 1.0, "min_quantity": 1, "defective_quantity": 0, "defective_reason": "", "stock_calculation_script": "sheet_stock_calc_v2", "display_format_script": "sheet_stock_calc_v2", "updated_at": "2026-07-08 13:04:10.813773+00:00"}', 1, 'Administrator', '2026-07-08T13:27:11.739607+00:00');
INSERT INTO audit_log (id, entity_type, entity_id, action, old_data, new_data, user_id, user_name, created_at) VALUES (83, 'warehouse', 31, 'update', '{"id": 31, "product_id": null, "raw_material_id": 10, "quantity": 1.030015, "min_quantity": 1, "defective_quantity": 0, "defective_reason": "", "stock_calculation_script": "sheet_stock_calc_v2", "display_format_script": "sheet_stock_calc_v2", "updated_at": "2026-07-08 13:27:17.500358+00:00"}', '{"id": 31, "product_id": null, "raw_material_id": 10, "quantity": 1.0, "min_quantity": 1, "defective_quantity": 0, "defective_reason": "", "stock_calculation_script": "sheet_stock_calc_v2", "display_format_script": "sheet_stock_calc_v2", "updated_at": "2026-07-08 13:27:17.500358+00:00"}', 1, 'Administrator', '2026-07-08T13:27:32.307055+00:00');
INSERT INTO audit_log (id, entity_type, entity_id, action, old_data, new_data, user_id, user_name, created_at) VALUES (84, 'warehouse', 31, 'update', '{"id": 31, "product_id": null, "raw_material_id": 10, "quantity": 1.93997, "min_quantity": 1, "defective_quantity": 0, "defective_reason": "", "stock_calculation_script": "sheet_stock_calc_v2", "display_format_script": "sheet_stock_calc_v2", "updated_at": "2026-07-08 13:27:48.617819+00:00"}', '{"id": 31, "product_id": null, "raw_material_id": 10, "quantity": 1.0, "min_quantity": 1, "defective_quantity": 0, "defective_reason": "", "stock_calculation_script": "sheet_stock_calc_v2", "display_format_script": "sheet_stock_calc_v2", "updated_at": "2026-07-08 13:27:48.617819+00:00"}', 1, 'Administrator', '2026-07-08T13:37:09.842286+00:00');
INSERT INTO audit_log (id, entity_type, entity_id, action, old_data, new_data, user_id, user_name, created_at) VALUES (85, 'warehouse', 31, 'update', '{"id": 31, "product_id": null, "raw_material_id": 10, "quantity": 1.0, "min_quantity": 1, "defective_quantity": 0, "defective_reason": "", "stock_calculation_script": "sheet_stock_calc_v2", "display_format_script": "sheet_stock_calc_v2", "updated_at": "2026-07-08 13:37:25.311835+00:00"}', '{"id": 31, "product_id": null, "raw_material_id": 10, "quantity": 0.0, "min_quantity": 1, "defective_quantity": 0, "defective_reason": "", "stock_calculation_script": "sheet_stock_calc_v2", "display_format_script": "sheet_stock_calc_v2", "updated_at": "2026-07-08 13:37:25.311835+00:00"}', 1, 'Administrator', '2026-07-08T13:40:02.094365+00:00');
INSERT INTO audit_log (id, entity_type, entity_id, action, old_data, new_data, user_id, user_name, created_at) VALUES (86, 'warehouse', 31, 'update', '{"id": 31, "product_id": null, "raw_material_id": 10, "quantity": 0.0, "min_quantity": 1, "defective_quantity": 0, "defective_reason": "", "stock_calculation_script": "sheet_stock_calc_v2", "display_format_script": "sheet_stock_calc_v2", "updated_at": "2026-07-08 13:40:02.094365+00:00"}', '{"id": 31, "product_id": null, "raw_material_id": 10, "quantity": 1.0, "min_quantity": 1, "defective_quantity": 0, "defective_reason": "", "stock_calculation_script": "sheet_stock_calc_v2", "display_format_script": "sheet_stock_calc_v2", "updated_at": "2026-07-08 13:40:02.094365+00:00"}', 1, 'Administrator', '2026-07-08T14:20:56.660929+00:00');
INSERT INTO audit_log (id, entity_type, entity_id, action, old_data, new_data, user_id, user_name, created_at) VALUES (87, 'warehouse', 31, 'update', '{"id": 31, "product_id": null, "raw_material_id": 10, "quantity": 1.030015, "min_quantity": 1, "defective_quantity": 0, "defective_reason": "", "stock_calculation_script": "sheet_stock_calc_v2", "display_format_script": "sheet_stock_calc_v2", "updated_at": "2026-07-08 14:21:03.382732+00:00"}', '{"id": 31, "product_id": null, "raw_material_id": 10, "quantity": 1.0, "min_quantity": 1, "defective_quantity": 0, "defective_reason": "", "stock_calculation_script": "sheet_stock_calc_v2", "display_format_script": "sheet_stock_calc_v2", "updated_at": "2026-07-08 14:21:03.382732+00:00"}', 1, 'Administrator', '2026-07-08T14:21:11.713857+00:00');
INSERT INTO audit_log (id, entity_type, entity_id, action, old_data, new_data, user_id, user_name, created_at) VALUES (88, 'product', 33, 'create', NULL, '{"name": "Кружка сублимация станд.", "description": null, "unit_price": 270.0, "unit_type": "piece", "category": null, "formula": null, "formula_script": null, "raw_material_id": null, "material_coefficient": 1.0, "supplier_url": "https://zenonline.ru/cat/00000098574", "default_cut_width_mm": null, "default_cut_height_mm": null, "raw_materials": []}', 8, 'Дарья', '2026-07-09T07:58:54.635094+00:00');
INSERT INTO audit_log (id, entity_type, entity_id, action, old_data, new_data, user_id, user_name, created_at) VALUES (89, 'product', 34, 'create', NULL, '{"name": "Кружка сублимация станд. с коробкой", "description": null, "unit_price": 305.0, "unit_type": "piece", "category": null, "formula": null, "formula_script": null, "raw_material_id": null, "material_coefficient": 1.0, "supplier_url": "https://zenonline.ru/cat/00000098574", "default_cut_width_mm": null, "default_cut_height_mm": null, "raw_materials": []}', 8, 'Дарья', '2026-07-09T08:00:17.133914+00:00');
INSERT INTO audit_log (id, entity_type, entity_id, action, old_data, new_data, user_id, user_name, created_at) VALUES (90, 'product', 35, 'create', NULL, '{"name": "Кружка сублимация станд. с коробкой, наклейка 8х8см", "description": null, "unit_price": 313.0, "unit_type": "piece", "category": null, "formula": null, "formula_script": null, "raw_material_id": null, "material_coefficient": 1.0, "supplier_url": "https://zenonline.ru/cat/00000098574", "default_cut_width_mm": null, "default_cut_height_mm": null, "raw_materials": []}', 8, 'Дарья', '2026-07-09T08:39:15.391236+00:00');
INSERT INTO audit_log (id, entity_type, entity_id, action, old_data, new_data, user_id, user_name, created_at) VALUES (91, 'product', 36, 'create', NULL, '{"name": "ручка пластик уф-печать с 1 стороны", "description": null, "unit_price": 85.0, "unit_type": "piece", "category": null, "formula": null, "formula_script": null, "raw_material_id": null, "material_coefficient": 1.0, "supplier_url": "https://vivagifts.ru/catalog/plastikovye-ruchki/", "default_cut_width_mm": null, "default_cut_height_mm": null, "raw_materials": []}', 8, 'Дарья', '2026-07-09T08:50:49.404294+00:00');
INSERT INTO audit_log (id, entity_type, entity_id, action, old_data, new_data, user_id, user_name, created_at) VALUES (92, 'product', 37, 'create', NULL, '{"name": "вымпел А5 4+0", "description": null, "unit_price": 340.0, "unit_type": "piece", "category": null, "formula": null, "formula_script": null, "raw_material_id": null, "material_coefficient": 1.0, "supplier_url": "https://zenonline.ru/cat/00000041199", "default_cut_width_mm": null, "default_cut_height_mm": null, "raw_materials": []}', 8, 'Дарья', '2026-07-09T09:18:29.113326+00:00');
INSERT INTO audit_log (id, entity_type, entity_id, action, old_data, new_data, user_id, user_name, created_at) VALUES (93, 'product', 38, 'create', NULL, '{"name": "вымпел А5 субл. 4+4", "description": null, "unit_price": 585.0, "unit_type": "piece", "category": null, "formula": null, "formula_script": null, "raw_material_id": null, "material_coefficient": 1.0, "supplier_url": "https://zenonline.ru/cat/00000041199", "default_cut_width_mm": null, "default_cut_height_mm": null, "raw_materials": []}', 8, 'Дарья', '2026-07-09T09:19:21.595091+00:00');
INSERT INTO audit_log (id, entity_type, entity_id, action, old_data, new_data, user_id, user_name, created_at) VALUES (94, 'product', 37, 'update', '{"id": 37, "name": "вымпел А5 4+0", "description": null, "unit_price": 340.0, "unit_type": "piece", "category": null, "formula": null, "formula_script": null, "raw_material_id": null, "material_coefficient": 1.0, "supplier_url": "https://zenonline.ru/cat/00000041199", "default_cut_width_mm": null, "default_cut_height_mm": null, "created_at": "2026-07-09 09:18:29.113326+00:00"}', '{"id": 37, "name": "вымпел А5 субл. 4+0", "description": null, "unit_price": 340.0, "unit_type": "piece", "category": null, "formula": null, "formula_script": null, "raw_material_id": null, "material_coefficient": 1.0, "supplier_url": "https://zenonline.ru/cat/00000041199", "default_cut_width_mm": null, "default_cut_height_mm": null, "created_at": "2026-07-09 09:18:29.113326+00:00"}', 8, 'Дарья', '2026-07-09T09:19:33.534324+00:00');
INSERT INTO audit_log (id, entity_type, entity_id, action, old_data, new_data, user_id, user_name, created_at) VALUES (95, 'warehouse', 32, 'create', NULL, '{"product_id": 32, "raw_material_id": null, "quantity": 99999.0, "min_quantity": 10, "defective_quantity": 0, "defective_reason": "", "stock_calculation_script": null, "display_format_script": null}', 1, 'Administrator', '2026-07-09T09:27:35.710950+00:00');
INSERT INTO audit_log (id, entity_type, entity_id, action, old_data, new_data, user_id, user_name, created_at) VALUES (96, 'product', 39, 'create', NULL, '{"name": "Печать А4, 250г, 4+0", "description": "дипломы/грамоты/сертификаты/благодарности \\nплотность - 250г\\nЦвет - 4+0", "unit_price": 45.0, "unit_type": "piece", "category": "Печать", "formula": null, "formula_script": null, "raw_material_id": 9, "material_coefficient": 1.0, "supplier_url": null, "default_cut_width_mm": null, "default_cut_height_mm": null, "raw_materials": [{"raw_material_id": 9, "coefficient": 1.0}]}', 9, 'Дмитрий', '2026-07-09T09:44:08.670949+00:00');
INSERT INTO audit_log (id, entity_type, entity_id, action, old_data, new_data, user_id, user_name, created_at) VALUES (97, 'raw_material', 11, 'create', NULL, '{"name": "Бумага SRA3 250г, мат", "description": "Бумага SRA3 250г, мат", "width_mm": 310, "height_mm": 450, "roll_width_m": null, "roll_length_m": null, "density": "250", "color_finish": "матовый", "unit_type": "m2", "unit_price": 0.0, "display_format_script": null, "stock_calculation_script": null}', 9, 'Дмитрий', '2026-07-09T09:45:14.717948+00:00');
INSERT INTO audit_log (id, entity_type, entity_id, action, old_data, new_data, user_id, user_name, created_at) VALUES (98, 'raw_material', 9, 'update', '{"id": 9, "name": "Бумага 300 мат", "description": null, "width_mm": 450, "height_mm": 320, "roll_width_m": null, "roll_length_m": null, "density": null, "color_finish": null, "unit_type": "sheet", "unit_price": 0.0, "display_format_script": null, "stock_calculation_script": null, "created_at": "2026-07-08 10:11:40.874904+00:00"}', '{"id": 9, "name": "Бумага SRA3, 300г, мат", "description": null, "width_mm": 450, "height_mm": 320, "roll_width_m": null, "roll_length_m": null, "density": "300", "color_finish": "матовый", "unit_type": "sheet", "unit_price": 0.0, "display_format_script": null, "stock_calculation_script": null, "created_at": "2026-07-08 10:11:40.874904+00:00"}', 9, 'Дмитрий', '2026-07-09T09:45:43.930918+00:00');
INSERT INTO audit_log (id, entity_type, entity_id, action, old_data, new_data, user_id, user_name, created_at) VALUES (99, 'raw_material', 11, 'update', '{"id": 11, "name": "Бумага SRA3 250г, мат", "description": "Бумага SRA3 250г, мат", "width_mm": 310, "height_mm": 450, "roll_width_m": null, "roll_length_m": null, "density": "250", "color_finish": "матовый", "unit_type": "m2", "unit_price": 0.0, "display_format_script": null, "stock_calculation_script": null, "created_at": "2026-07-09 09:45:14.717948+00:00"}', '{"id": 11, "name": "Бумага SRA3 250г, мат", "description": "Бумага SRA3 250г, мат", "width_mm": 310, "height_mm": 450, "roll_width_m": null, "roll_length_m": null, "density": "250", "color_finish": "матовый", "unit_type": "sheet", "unit_price": 0.0, "display_format_script": null, "stock_calculation_script": null, "created_at": "2026-07-09 09:45:14.717948+00:00"}', 9, 'Дмитрий', '2026-07-09T09:45:57.384916+00:00');
INSERT INTO audit_log (id, entity_type, entity_id, action, old_data, new_data, user_id, user_name, created_at) VALUES (100, 'raw_material', 12, 'create', NULL, '{"name": "Бумага SRA3 250г, глянц", "description": null, "width_mm": 310, "height_mm": 450, "roll_width_m": null, "roll_length_m": null, "density": "250", "color_finish": "глянцевый", "unit_type": "sheet", "unit_price": 0.0, "display_format_script": null, "stock_calculation_script": null}', 9, 'Дмитрий', '2026-07-09T09:46:33.013050+00:00');
INSERT INTO audit_log (id, entity_type, entity_id, action, old_data, new_data, user_id, user_name, created_at) VALUES (101, 'raw_material', 9, 'update', '{"id": 9, "name": "Бумага SRA3, 300г, мат", "description": null, "width_mm": 450, "height_mm": 320, "roll_width_m": null, "roll_length_m": null, "density": "300", "color_finish": "матовый", "unit_type": "sheet", "unit_price": 0.0, "display_format_script": null, "stock_calculation_script": null, "created_at": "2026-07-08 10:11:40.874904+00:00"}', '{"id": 9, "name": "Бумага SRA3, 300г, мат", "description": null, "width_mm": 310, "height_mm": 450, "roll_width_m": null, "roll_length_m": null, "density": "300", "color_finish": "матовый", "unit_type": "sheet", "unit_price": 0.0, "display_format_script": null, "stock_calculation_script": null, "created_at": "2026-07-08 10:11:40.874904+00:00"}', 9, 'Дмитрий', '2026-07-09T09:46:40.827288+00:00');
INSERT INTO audit_log (id, entity_type, entity_id, action, old_data, new_data, user_id, user_name, created_at) VALUES (102, 'raw_material', 9, 'update', '{"id": 9, "name": "Бумага SRA3, 300г, мат", "description": null, "width_mm": 310, "height_mm": 450, "roll_width_m": null, "roll_length_m": null, "density": "300", "color_finish": "матовый", "unit_type": "sheet", "unit_price": 0.0, "display_format_script": null, "stock_calculation_script": null, "created_at": "2026-07-08 10:11:40.874904+00:00"}', '{"id": 9, "name": "Бумага SRA3, 300г, мат", "description": null, "width_mm": 320, "height_mm": 450, "roll_width_m": null, "roll_length_m": null, "density": "300", "color_finish": "матовый", "unit_type": "sheet", "unit_price": 0.0, "display_format_script": null, "stock_calculation_script": null, "created_at": "2026-07-08 10:11:40.874904+00:00"}', 9, 'Дмитрий', '2026-07-09T09:47:06.469957+00:00');
INSERT INTO audit_log (id, entity_type, entity_id, action, old_data, new_data, user_id, user_name, created_at) VALUES (103, 'raw_material', 11, 'update', '{"id": 11, "name": "Бумага SRA3 250г, мат", "description": "Бумага SRA3 250г, мат", "width_mm": 310, "height_mm": 450, "roll_width_m": null, "roll_length_m": null, "density": "250", "color_finish": "матовый", "unit_type": "sheet", "unit_price": 0.0, "display_format_script": null, "stock_calculation_script": null, "created_at": "2026-07-09 09:45:14.717948+00:00"}', '{"id": 11, "name": "Бумага SRA3 250г, мат", "description": "Бумага SRA3 250г, мат", "width_mm": 320, "height_mm": 450, "roll_width_m": null, "roll_length_m": null, "density": "250", "color_finish": "матовый", "unit_type": "sheet", "unit_price": 0.0, "display_format_script": null, "stock_calculation_script": null, "created_at": "2026-07-09 09:45:14.717948+00:00"}', 9, 'Дмитрий', '2026-07-09T09:47:10.037853+00:00');
INSERT INTO audit_log (id, entity_type, entity_id, action, old_data, new_data, user_id, user_name, created_at) VALUES (104, 'raw_material', 12, 'update', '{"id": 12, "name": "Бумага SRA3 250г, глянц", "description": null, "width_mm": 310, "height_mm": 450, "roll_width_m": null, "roll_length_m": null, "density": "250", "color_finish": "глянцевый", "unit_type": "sheet", "unit_price": 0.0, "display_format_script": null, "stock_calculation_script": null, "created_at": "2026-07-09 09:46:33.013050+00:00"}', '{"id": 12, "name": "Бумага SRA3 250г, глянц", "description": null, "width_mm": 320, "height_mm": 450, "roll_width_m": null, "roll_length_m": null, "density": "250", "color_finish": "глянцевый", "unit_type": "sheet", "unit_price": 0.0, "display_format_script": null, "stock_calculation_script": null, "created_at": "2026-07-09 09:46:33.013050+00:00"}', 9, 'Дмитрий', '2026-07-09T09:47:14.390948+00:00');
INSERT INTO audit_log (id, entity_type, entity_id, action, old_data, new_data, user_id, user_name, created_at) VALUES (105, 'raw_material', 13, 'create', NULL, '{"name": "Бумага SRA3, 300г, глянц", "description": null, "width_mm": 320, "height_mm": 450, "roll_width_m": null, "roll_length_m": null, "density": "300", "color_finish": "глянцевый", "unit_type": "sheet", "unit_price": 0.0, "display_format_script": null, "stock_calculation_script": null}', 9, 'Дмитрий', '2026-07-09T09:47:47.958288+00:00');
SELECT setval(''audit_log_id_seq'::regclass', 105);

DROP TABLE IF EXISTS client_company CASCADE;
CREATE TABLE client_company (
  client_id integer NOT NULL,
  company_detail_id integer NOT NULL,
  PRIMARY KEY (client_id, company_detail_id)
);

DROP SEQUENCE IF EXISTS 'clients_id_seq'::regclass CASCADE;
CREATE SEQUENCE 'clients_id_seq'::regclass START WITH 49 INCREMENT BY 1 NO MINVALUE NO MAXVALUE CACHE 1;
DROP TABLE IF EXISTS clients CASCADE;
CREATE TABLE clients (
  id integer NOT NULL,
  name character varying(255) NOT NULL,
  email character varying(255),
  phone character varying(50),
  company character varying(255),
  address text,
  created_at timestamp with time zone NOT NULL DEFAULT now(),
  updated_at timestamp with time zone NOT NULL DEFAULT now(),
  PRIMARY KEY (id)
);
ALTER TABLE clients ALTER COLUMN id SET DEFAULT nextval(''clients_id_seq'::regclass'::regclass);
INSERT INTO clients (id, name, email, phone, company, address, created_at, updated_at) VALUES (24, 'Ольга Ремизова', '-', '89303579444', 'Нептун - Кинешма', NULL, '2026-07-07T09:04:34.396374+00:00', '2026-07-07T09:04:34.396374+00:00');
INSERT INTO clients (id, name, email, phone, company, address, created_at, updated_at) VALUES (29, 'Анастасия Ивгу', NULL, '+7 901 191 40 20', NULL, NULL, '2026-07-08T10:20:09.381763+00:00', '2026-07-08T10:20:09.381763+00:00');
INSERT INTO clients (id, name, email, phone, company, address, created_at, updated_at) VALUES (34, 'Вера Б', NULL, NULL, NULL, NULL, '2026-07-08T11:43:48.413058+00:00', '2026-07-08T11:43:48.413058+00:00');
INSERT INTO clients (id, name, email, phone, company, address, created_at, updated_at) VALUES (36, 'Александр Антонюк', NULL, NULL, 'Парк Харинка', NULL, '2026-07-08T12:01:49.256273+00:00', '2026-07-08T12:01:49.256273+00:00');
INSERT INTO clients (id, name, email, phone, company, address, created_at, updated_at) VALUES (38, 'Елена ', '-', '+79158458210', NULL, NULL, '2026-07-08T12:06:56.634298+00:00', '2026-07-08T12:06:56.634298+00:00');
INSERT INTO clients (id, name, email, phone, company, address, created_at, updated_at) VALUES (42, 'Михаил Муравьёв', NULL, '8-909-248-84-25', NULL, NULL, '2026-07-08T13:30:00.379749+00:00', '2026-07-08T13:30:00.379749+00:00');
INSERT INTO clients (id, name, email, phone, company, address, created_at, updated_at) VALUES (45, 'Тубдиспансер', NULL, '+7 961 116 04 91', NULL, NULL, '2026-07-09T08:21:07.987121+00:00', '2026-07-09T08:21:07.987121+00:00');
INSERT INTO clients (id, name, email, phone, company, address, created_at, updated_at) VALUES (43, 'Валерия Трунтягина (вобла)', NULL, '89158150137', 'ручная гравировка', NULL, '2026-07-08T14:49:22.282784+00:00', '2026-07-09T09:02:39.759567+00:00');
INSERT INTO clients (id, name, email, phone, company, address, created_at, updated_at) VALUES (25, 'Никита Воронов', NULL, '+7 908 561 71 73', 'Стартин', NULL, '2026-07-08T08:29:31.378695+00:00', '2026-07-09T09:31:57.208910+00:00');
INSERT INTO clients (id, name, email, phone, company, address, created_at, updated_at) VALUES (28, 'Алла из макса', NULL, '+7 909 249 65 94', NULL, NULL, '2026-07-08T09:30:56.285832+00:00', '2026-07-09T09:32:17.338932+00:00');
INSERT INTO clients (id, name, email, phone, company, address, created_at, updated_at) VALUES (31, 'Андрей Интердом', 'interdom.nikolaev@mail.ru', '+7 910 695 95 95', 'Интердом', NULL, '2026-07-08T11:30:43.355190+00:00', '2026-07-09T09:33:43.634331+00:00');
INSERT INTO clients (id, name, email, phone, company, address, created_at, updated_at) VALUES (33, 'Лусине Инь Янь', NULL, NULL, NULL, 'ВК', '2026-07-08T11:36:09.604894+00:00', '2026-07-09T09:33:53.625580+00:00');
INSERT INTO clients (id, name, email, phone, company, address, created_at, updated_at) VALUES (41, 'Жадан', NULL, '+7 903 632 41 22', NULL, NULL, '2026-07-08T13:14:59.136375+00:00', '2026-07-09T09:34:17.004910+00:00');
INSERT INTO clients (id, name, email, phone, company, address, created_at, updated_at) VALUES (40, 'Полозова Первые', NULL, '+7 910 668 57 11', 'Движение Первых', NULL, '2026-07-08T13:08:31.267043+00:00', '2026-07-09T09:34:43.553653+00:00');
INSERT INTO clients (id, name, email, phone, company, address, created_at, updated_at) VALUES (39, 'Купоросова Фурманов', NULL, '+7 910 680 27 15', 'Отдел Спорта', 'Фурманов', '2026-07-08T12:19:54.392820+00:00', '2026-07-09T09:37:22.021133+00:00');
INSERT INTO clients (id, name, email, phone, company, address, created_at, updated_at) VALUES (35, 'Роман Каменщиков', NULL, NULL, '', 'ВК', '2026-07-08T11:51:15.385748+00:00', '2026-07-09T09:37:44.357664+00:00');
INSERT INTO clients (id, name, email, phone, company, address, created_at, updated_at) VALUES (37, 'Анатолий Голубев', NULL, NULL, 'ИВПЭК', NULL, '2026-07-08T12:03:46.221116+00:00', '2026-07-09T09:38:53.298708+00:00');
INSERT INTO clients (id, name, email, phone, company, address, created_at, updated_at) VALUES (30, 'Вера Фатхуллина ', NULL, NULL, 'Школа 58', 'иваново', '2026-07-08T11:07:38.135264+00:00', '2026-07-09T10:10:12.275906+00:00');
INSERT INTO clients (id, name, email, phone, company, address, created_at, updated_at) VALUES (26, 'Александр Сироткин/Шишкин', NULL, NULL, 'Коллинз - Collin`s', NULL, '2026-07-08T08:57:16.256351+00:00', '2026-07-09T10:41:51.783935+00:00');
INSERT INTO clients (id, name, email, phone, company, address, created_at, updated_at) VALUES (47, 'Сабина (Серовски)', NULL, NULL, NULL, NULL, '2026-07-09T11:25:04.682985+00:00', '2026-07-09T11:25:04.682985+00:00');
INSERT INTO clients (id, name, email, phone, company, address, created_at, updated_at) VALUES (48, 'Анастасия Олимпиец', NULL, NULL, NULL, NULL, '2026-07-09T12:47:37.533208+00:00', '2026-07-09T12:47:37.533208+00:00');
INSERT INTO clients (id, name, email, phone, company, address, created_at, updated_at) VALUES (46, 'Алексей', NULL, NULL, NULL, 'макс', '2026-07-09T09:49:44.243004+00:00', '2026-07-09T14:03:12.579212+00:00');
INSERT INTO clients (id, name, email, phone, company, address, created_at, updated_at) VALUES (49, 'Александра Домашенкова', NULL, NULL, NULL, NULL, '2026-07-09T14:14:34.565003+00:00', '2026-07-09T14:14:34.565003+00:00');
SELECT setval(''clients_id_seq'::regclass', 49);

DROP SEQUENCE IF EXISTS 'company_details_id_seq'::regclass CASCADE;
CREATE SEQUENCE 'company_details_id_seq'::regclass START WITH 14 INCREMENT BY 1 NO MINVALUE NO MAXVALUE CACHE 1;
DROP TABLE IF EXISTS company_details CASCADE;
CREATE TABLE company_details (
  id integer NOT NULL,
  company_name character varying(255) NOT NULL,
  inn character varying(12),
  kpp character varying(9),
  ogrn character varying(15),
  ogrnip character varying(15),
  legal_address text,
  actual_address text,
  settlement_account character varying(20),
  bank_name character varying(255),
  bik character varying(9),
  correspondent_account character varying(20),
  contact_person character varying(255),
  phone character varying(50),
  email character varying(255),
  created_at timestamp with time zone NOT NULL DEFAULT now(),
  updated_at timestamp with time zone NOT NULL DEFAULT now(),
  PRIMARY KEY (id)
);
ALTER TABLE company_details ALTER COLUMN id SET DEFAULT nextval(''company_details_id_seq'::regclass'::regclass);
INSERT INTO company_details (id, company_name, inn, kpp, ogrn, ogrnip, legal_address, actual_address, settlement_account, bank_name, bik, correspondent_account, contact_person, phone, email, created_at, updated_at) VALUES (1, 'ООО Рога и Копыта', '4163119785', NULL, '1560157888921', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2026-06-23T21:07:05+00:00', '2026-06-23T21:07:05+00:00');
INSERT INTO company_details (id, company_name, inn, kpp, ogrn, ogrnip, legal_address, actual_address, settlement_account, bank_name, bik, correspondent_account, contact_person, phone, email, created_at, updated_at) VALUES (2, 'ЗАО Технологии', '7825844140', NULL, '3808074611645', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2026-06-23T21:07:05+00:00', '2026-06-23T21:07:05+00:00');
INSERT INTO company_details (id, company_name, inn, kpp, ogrn, ogrnip, legal_address, actual_address, settlement_account, bank_name, bik, correspondent_account, contact_person, phone, email, created_at, updated_at) VALUES (3, 'ООО МедиаПро', '8574149614', NULL, '2628231594989', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2026-06-23T21:07:05+00:00', '2026-06-23T21:07:05+00:00');
INSERT INTO company_details (id, company_name, inn, kpp, ogrn, ogrnip, legal_address, actual_address, settlement_account, bank_name, bik, correspondent_account, contact_person, phone, email, created_at, updated_at) VALUES (4, 'ИП Волков', '9776552803', NULL, '7661160537249', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2026-06-23T21:07:05+00:00', '2026-06-23T21:07:05+00:00');
INSERT INTO company_details (id, company_name, inn, kpp, ogrn, ogrnip, legal_address, actual_address, settlement_account, bank_name, bik, correspondent_account, contact_person, phone, email, created_at, updated_at) VALUES (5, 'АО ИнвестГрупп', '4026113008', NULL, '7683402910416', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2026-06-23T21:07:05+00:00', '2026-06-23T21:07:05+00:00');
INSERT INTO company_details (id, company_name, inn, kpp, ogrn, ogrnip, legal_address, actual_address, settlement_account, bank_name, bik, correspondent_account, contact_person, phone, email, created_at, updated_at) VALUES (6, 'ООО ПринтМастер', '3783290795', NULL, '5306688806356', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2026-06-23T21:07:05+00:00', '2026-06-23T21:07:05+00:00');
INSERT INTO company_details (id, company_name, inn, kpp, ogrn, ogrnip, legal_address, actual_address, settlement_account, bank_name, bik, correspondent_account, contact_person, phone, email, created_at, updated_at) VALUES (7, 'ЗАО СтройСервис', '2351531223', NULL, '9781728240661', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2026-06-23T21:07:05+00:00', '2026-06-23T21:07:05+00:00');
INSERT INTO company_details (id, company_name, inn, kpp, ogrn, ogrnip, legal_address, actual_address, settlement_account, bank_name, bik, correspondent_account, contact_person, phone, email, created_at, updated_at) VALUES (8, 'ООО ЛогоСтудия', '7609857128', NULL, '8024777783792', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2026-06-23T21:07:05+00:00', '2026-06-23T21:07:05+00:00');
INSERT INTO company_details (id, company_name, inn, kpp, ogrn, ogrnip, legal_address, actual_address, settlement_account, bank_name, bik, correspondent_account, contact_person, phone, email, created_at, updated_at) VALUES (9, 'ИП Новиков', '1470939445', NULL, '3815898439108', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2026-06-23T21:07:05+00:00', '2026-06-23T21:07:05+00:00');
INSERT INTO company_details (id, company_name, inn, kpp, ogrn, ogrnip, legal_address, actual_address, settlement_account, bank_name, bik, correspondent_account, contact_person, phone, email, created_at, updated_at) VALUES (10, 'АО ФармМед', '5047709743', NULL, '5693329282832', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2026-06-23T21:07:05+00:00', '2026-06-23T21:07:05+00:00');
INSERT INTO company_details (id, company_name, inn, kpp, ogrn, ogrnip, legal_address, actual_address, settlement_account, bank_name, bik, correspondent_account, contact_person, phone, email, created_at, updated_at) VALUES (11, 'ООО Аврора', '2948728483', NULL, '9930004312372', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2026-06-23T21:07:05+00:00', '2026-06-23T21:07:05+00:00');
INSERT INTO company_details (id, company_name, inn, kpp, ogrn, ogrnip, legal_address, actual_address, settlement_account, bank_name, bik, correspondent_account, contact_person, phone, email, created_at, updated_at) VALUES (12, 'ИП Попов', '4944899549', NULL, '6701994049204', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2026-06-23T21:07:05+00:00', '2026-06-23T21:07:05+00:00');
INSERT INTO company_details (id, company_name, inn, kpp, ogrn, ogrnip, legal_address, actual_address, settlement_account, bank_name, bik, correspondent_account, contact_person, phone, email, created_at, updated_at) VALUES (13, 'ООО «Корпорация МС»', '3703019931', '370301001', '1163702072368', NULL, '155800, Ивановская область, г. Кинешма, ул. Решемская, д.11Б', NULL, '40702810017000014544', 'ТУЛЬСКОЕ ОТДЕЛЕНИЕ N8604 ПАО СБЕРБАНК г Тула', '047003608', '30101810300000000608', 'ольга ремизова', '(+7 493-31) 541-57', 'corporationMS@mail.ru', '2026-07-07T09:13:04.379379+00:00', '2026-07-07T09:13:04.379379+00:00');
INSERT INTO company_details (id, company_name, inn, kpp, ogrn, ogrnip, legal_address, actual_address, settlement_account, bank_name, bik, correspondent_account, contact_person, phone, email, created_at, updated_at) VALUES (14, 'Название: ОГБПОУ ИВПЭК', '3731022950', '370201001', '1023700556956', NULL, '153000 Ивановская обл., г.Иваново, ул. Московская,д.48', NULL, '', '', '', NULL, NULL, '', 'shf.ivpek@yandex.ru', '2026-07-09T09:40:30.650670+00:00', '2026-07-09T09:40:30.650670+00:00');
SELECT setval(''company_details_id_seq'::regclass', 14);

DROP SEQUENCE IF EXISTS 'custom_field_values_id_seq'::regclass CASCADE;
CREATE SEQUENCE 'custom_field_values_id_seq'::regclass START WITH 1 INCREMENT BY 1 NO MINVALUE NO MAXVALUE CACHE 1;
DROP TABLE IF EXISTS custom_field_values CASCADE;
CREATE TABLE custom_field_values (
  id integer NOT NULL,
  entity character varying(50) NOT NULL,
  entity_id integer NOT NULL,
  field_id integer NOT NULL,
  value_text text,
  value_number integer,
  value_boolean boolean,
  value_json text,
  PRIMARY KEY (id)
);
ALTER TABLE custom_field_values ALTER COLUMN id SET DEFAULT nextval(''custom_field_values_id_seq'::regclass'::regclass);
SELECT setval(''custom_field_values_id_seq'::regclass', 0);

DROP SEQUENCE IF EXISTS 'custom_fields_id_seq'::regclass CASCADE;
CREATE SEQUENCE 'custom_fields_id_seq'::regclass START WITH 1 INCREMENT BY 1 NO MINVALUE NO MAXVALUE CACHE 1;
DROP TABLE IF EXISTS custom_fields CASCADE;
CREATE TABLE custom_fields (
  id integer NOT NULL,
  entity character varying(50) NOT NULL,
  field_key character varying(100) NOT NULL,
  label character varying(255) NOT NULL,
  field_type character varying(50) NOT NULL,
  required boolean NOT NULL,
  options text,
  sort_order integer NOT NULL,
  created_at timestamp with time zone NOT NULL DEFAULT now(),
  PRIMARY KEY (id)
);
ALTER TABLE custom_fields ALTER COLUMN id SET DEFAULT nextval(''custom_fields_id_seq'::regclass'::regclass);
SELECT setval(''custom_fields_id_seq'::regclass', 0);

DROP SEQUENCE IF EXISTS 'hermes_agents_id_seq'::regclass CASCADE;
CREATE SEQUENCE 'hermes_agents_id_seq'::regclass START WITH 1 INCREMENT BY 1 NO MINVALUE NO MAXVALUE CACHE 1;
DROP TABLE IF EXISTS hermes_agents CASCADE;
CREATE TABLE hermes_agents (
  id integer NOT NULL,
  name character varying(255) NOT NULL,
  agent_type character varying(50) NOT NULL,
  config json NOT NULL,
  is_active boolean NOT NULL,
  last_seen timestamp with time zone,
  webhook_url character varying(500),
  created_at timestamp with time zone NOT NULL DEFAULT now(),
  PRIMARY KEY (id)
);
ALTER TABLE hermes_agents ALTER COLUMN id SET DEFAULT nextval(''hermes_agents_id_seq'::regclass'::regclass);
SELECT setval(''hermes_agents_id_seq'::regclass', 0);

DROP SEQUENCE IF EXISTS 'hermes_events_id_seq'::regclass CASCADE;
CREATE SEQUENCE 'hermes_events_id_seq'::regclass START WITH 1 INCREMENT BY 1 NO MINVALUE NO MAXVALUE CACHE 1;
DROP TABLE IF EXISTS hermes_events CASCADE;
CREATE TABLE hermes_events (
  id integer NOT NULL,
  agent_id integer NOT NULL,
  event_type character varying(100) NOT NULL,
  payload json NOT NULL,
  status character varying(50) NOT NULL,
  response json,
  created_at timestamp with time zone NOT NULL DEFAULT now(),
  PRIMARY KEY (id)
);
ALTER TABLE hermes_events ALTER COLUMN id SET DEFAULT nextval(''hermes_events_id_seq'::regclass'::regclass);
SELECT setval(''hermes_events_id_seq'::regclass', 0);

DROP SEQUENCE IF EXISTS 'knowledge_folders_id_seq'::regclass CASCADE;
CREATE SEQUENCE 'knowledge_folders_id_seq'::regclass START WITH 1 INCREMENT BY 1 NO MINVALUE NO MAXVALUE CACHE 1;
DROP TABLE IF EXISTS knowledge_folders CASCADE;
CREATE TABLE knowledge_folders (
  id integer NOT NULL,
  name character varying(255) NOT NULL,
  parent_id integer,
  created_at timestamp with time zone NOT NULL DEFAULT now(),
  updated_at timestamp with time zone NOT NULL DEFAULT now(),
  PRIMARY KEY (id)
);
ALTER TABLE knowledge_folders ALTER COLUMN id SET DEFAULT nextval(''knowledge_folders_id_seq'::regclass'::regclass);
SELECT setval(''knowledge_folders_id_seq'::regclass', 0);

DROP SEQUENCE IF EXISTS 'knowledge_notes_id_seq'::regclass CASCADE;
CREATE SEQUENCE 'knowledge_notes_id_seq'::regclass START WITH 1 INCREMENT BY 1 NO MINVALUE NO MAXVALUE CACHE 1;
DROP TABLE IF EXISTS knowledge_notes CASCADE;
CREATE TABLE knowledge_notes (
  id integer NOT NULL,
  title character varying(255) NOT NULL,
  content text NOT NULL,
  folder_id integer,
  tags text,
  created_at timestamp with time zone NOT NULL DEFAULT now(),
  updated_at timestamp with time zone NOT NULL DEFAULT now(),
  PRIMARY KEY (id)
);
ALTER TABLE knowledge_notes ALTER COLUMN id SET DEFAULT nextval(''knowledge_notes_id_seq'::regclass'::regclass);
SELECT setval(''knowledge_notes_id_seq'::regclass', 0);

DROP SEQUENCE IF EXISTS 'offcuts_id_seq'::regclass CASCADE;
CREATE SEQUENCE 'offcuts_id_seq'::regclass START WITH 94 INCREMENT BY 1 NO MINVALUE NO MAXVALUE CACHE 1;
DROP TABLE IF EXISTS offcuts CASCADE;
CREATE TABLE offcuts (
  id integer NOT NULL,
  raw_material_id integer NOT NULL,
  width_mm double precision NOT NULL,
  height_mm double precision NOT NULL,
  quantity integer NOT NULL,
  order_id integer,
  created_at timestamp with time zone NOT NULL DEFAULT now(),
  PRIMARY KEY (id)
);
ALTER TABLE offcuts ALTER COLUMN id SET DEFAULT nextval(''offcuts_id_seq'::regclass'::regclass);
INSERT INTO offcuts (id, raw_material_id, width_mm, height_mm, quantity, order_id, created_at) VALUES (87, 10, 400.0, 1800.0, 1, 186, '2026-07-08T14:21:21.041801+00:00');
INSERT INTO offcuts (id, raw_material_id, width_mm, height_mm, quantity, order_id, created_at) VALUES (88, 10, 2600.0, 200.0, 1, 186, '2026-07-08T14:21:21.041801+00:00');
INSERT INTO offcuts (id, raw_material_id, width_mm, height_mm, quantity, order_id, created_at) VALUES (91, 10, 1300.0, 900.0, 1, 186, '2026-07-08T14:21:21.041801+00:00');
INSERT INTO offcuts (id, raw_material_id, width_mm, height_mm, quantity, order_id, created_at) VALUES (92, 10, 1300.0, 693.0, 1, 186, '2026-07-08T14:21:21.041801+00:00');
INSERT INTO offcuts (id, raw_material_id, width_mm, height_mm, quantity, order_id, created_at) VALUES (93, 10, 1300.0, 693.0, 1, 186, '2026-07-09T09:31:19.560392+00:00');
INSERT INTO offcuts (id, raw_material_id, width_mm, height_mm, quantity, order_id, created_at) VALUES (94, 10, 1300.0, 693.0, 1, 186, '2026-07-09T11:05:14.283525+00:00');
SELECT setval(''offcuts_id_seq'::regclass', 94);

DROP SEQUENCE IF EXISTS 'order_history_id_seq'::regclass CASCADE;
CREATE SEQUENCE 'order_history_id_seq'::regclass START WITH 809 INCREMENT BY 1 NO MINVALUE NO MAXVALUE CACHE 1;
DROP TABLE IF EXISTS order_history CASCADE;
CREATE TABLE order_history (
  id integer NOT NULL,
  order_id integer NOT NULL,
  action character varying(50) NOT NULL,
  field character varying(100),
  old_value text,
  new_value text,
  user_id integer,
  user_name character varying(255),
  user_role character varying(100),
  created_at timestamp with time zone NOT NULL DEFAULT now(),
  PRIMARY KEY (id)
);
ALTER TABLE order_history ALTER COLUMN id SET DEFAULT nextval(''order_history_id_seq'::regclass'::regclass);
INSERT INTO order_history (id, order_id, action, field, old_value, new_value, user_id, user_name, user_role, created_at) VALUES (600, 176, 'created', NULL, NULL, 'Заказ #176 создан', 9, 'Дмитрий', 'manager', '2026-07-07T10:06:59.469349+00:00');
INSERT INTO order_history (id, order_id, action, field, old_value, new_value, user_id, user_name, user_role, created_at) VALUES (601, 176, 'updated', 'designer', NULL, 'Sergey', 9, 'Дмитрий', 'manager', '2026-07-07T10:07:10.503013+00:00');
INSERT INTO order_history (id, order_id, action, field, old_value, new_value, user_id, user_name, user_role, created_at) VALUES (609, 176, 'updated', 'designer', 'Sergey', 'Alena', 11, 'Александра', 'designer', '2026-07-07T11:48:10.439335+00:00');
INSERT INTO order_history (id, order_id, action, field, old_value, new_value, user_id, user_name, user_role, created_at) VALUES (610, 176, 'updated', 'designer', 'Alena', 'Maya', 11, 'Александра', 'designer', '2026-07-07T11:48:12.281829+00:00');
INSERT INTO order_history (id, order_id, action, field, old_value, new_value, user_id, user_name, user_role, created_at) VALUES (611, 176, 'updated', 'designer', 'Maya', 'Sergey', 11, 'Александра', 'designer', '2026-07-07T11:48:14.569712+00:00');
INSERT INTO order_history (id, order_id, action, field, old_value, new_value, user_id, user_name, user_role, created_at) VALUES (616, 176, 'updated', 'designer', 'Sergey', 'Maya', 13, 'Сергей', 'designer', '2026-07-07T12:47:13.319844+00:00');
INSERT INTO order_history (id, order_id, action, field, old_value, new_value, user_id, user_name, user_role, created_at) VALUES (617, 176, 'updated', 'designer', 'Maya', 'Sergey', 13, 'Сергей', 'designer', '2026-07-07T12:47:16.836195+00:00');
INSERT INTO order_history (id, order_id, action, field, old_value, new_value, user_id, user_name, user_role, created_at) VALUES (620, 177, 'created', NULL, NULL, 'Заказ #177 создан', 11, 'Александра', 'designer', '2026-07-08T08:35:05.656713+00:00');
INSERT INTO order_history (id, order_id, action, field, old_value, new_value, user_id, user_name, user_role, created_at) VALUES (621, 177, 'updated', 'workers', '["Sergey"]', '["Sergey", "Сергей"]', 1, 'Administrator', 'admin', '2026-07-08T08:36:58.780866+00:00');
INSERT INTO order_history (id, order_id, action, field, old_value, new_value, user_id, user_name, user_role, created_at) VALUES (622, 177, 'updated', 'workers', '["Sergey", "Сергей"]', '["Сергей"]', 1, 'Administrator', 'admin', '2026-07-08T08:37:15.977852+00:00');
INSERT INTO order_history (id, order_id, action, field, old_value, new_value, user_id, user_name, user_role, created_at) VALUES (623, 177, 'updated', 'source', NULL, 'МАХ', 11, 'Александра', 'designer', '2026-07-08T08:52:35.749852+00:00');
INSERT INTO order_history (id, order_id, action, field, old_value, new_value, user_id, user_name, user_role, created_at) VALUES (624, 176, 'updated', 'designer', 'Sergey', 'Alena', 10, 'Алёна', 'designer', '2026-07-08T08:56:35.026785+00:00');
INSERT INTO order_history (id, order_id, action, field, old_value, new_value, user_id, user_name, user_role, created_at) VALUES (625, 176, 'updated', 'designer', 'Alena', 'Sergey', 10, 'Алёна', 'designer', '2026-07-08T08:56:39.271625+00:00');
INSERT INTO order_history (id, order_id, action, field, old_value, new_value, user_id, user_name, user_role, created_at) VALUES (626, 177, 'updated', 'deadline', '2026-07-07 21:00:00+00:00', '2026-07-09 21:00:00+00:00', 11, 'Александра', 'designer', '2026-07-08T09:04:52.235067+00:00');
INSERT INTO order_history (id, order_id, action, field, old_value, new_value, user_id, user_name, user_role, created_at) VALUES (627, 177, 'updated', 'deadline_start', NULL, '2026-07-07 21:00:00+00:00', 11, 'Александра', 'designer', '2026-07-08T09:04:52.235067+00:00');
INSERT INTO order_history (id, order_id, action, field, old_value, new_value, user_id, user_name, user_role, created_at) VALUES (628, 177, 'updated', 'workers', '["Сергей"]', NULL, 11, 'Александра', 'designer', '2026-07-08T09:04:52.235067+00:00');
INSERT INTO order_history (id, order_id, action, field, old_value, new_value, user_id, user_name, user_role, created_at) VALUES (629, 177, 'updated', 'workers', NULL, '["Сергей"]', 1, 'Administrator', 'admin', '2026-07-08T09:29:01.007618+00:00');
INSERT INTO order_history (id, order_id, action, field, old_value, new_value, user_id, user_name, user_role, created_at) VALUES (630, 177, 'updated', 'workers', '["Сергей"]', NULL, 1, 'Administrator', 'admin', '2026-07-08T09:29:06.991357+00:00');
INSERT INTO order_history (id, order_id, action, field, old_value, new_value, user_id, user_name, user_role, created_at) VALUES (631, 177, 'updated', 'workers', NULL, '["Ри и Се"]', 1, 'Administrator', 'admin', '2026-07-08T09:29:10.057954+00:00');
INSERT INTO order_history (id, order_id, action, field, old_value, new_value, user_id, user_name, user_role, created_at) VALUES (632, 178, 'created', NULL, NULL, 'Заказ #178 создан', 12, 'Майя', 'designer', '2026-07-08T09:35:39.745658+00:00');
INSERT INTO order_history (id, order_id, action, field, old_value, new_value, user_id, user_name, user_role, created_at) VALUES (633, 179, 'created', NULL, NULL, 'Заказ #179 создан', 13, 'Сергей', 'designer', '2026-07-08T10:29:22.201316+00:00');
INSERT INTO order_history (id, order_id, action, field, old_value, new_value, user_id, user_name, user_role, created_at) VALUES (634, 179, 'updated', 'description', NULL, 'Визитки 4+4, бумага перламутровая светло-серая — 200 шт
4+4, бумага перламутровая светло-серая с фольгированием — 250 шт
Конверт — 100 шт
Таблички ПВХ 3мм — 2 шт', 13, 'Сергей', 'designer', '2026-07-08T10:29:59.322093+00:00');
INSERT INTO order_history (id, order_id, action, field, old_value, new_value, user_id, user_name, user_role, created_at) VALUES (635, 179, 'updated', 'layout_type', 'Утвержден', 'В работе', 13, 'Сергей', 'designer', '2026-07-08T10:30:32.285963+00:00');
INSERT INTO order_history (id, order_id, action, field, old_value, new_value, user_id, user_name, user_role, created_at) VALUES (636, 179, 'updated', 'workers', '["Konstantin", "Sergey"]', '["Konstantin"]', 1, 'Administrator', 'admin', '2026-07-08T10:32:27.273961+00:00');
INSERT INTO order_history (id, order_id, action, field, old_value, new_value, user_id, user_name, user_role, created_at) VALUES (637, 179, 'updated', 'workers', '["Konstantin"]', NULL, 1, 'Administrator', 'admin', '2026-07-08T10:32:29.783072+00:00');
INSERT INTO order_history (id, order_id, action, field, old_value, new_value, user_id, user_name, user_role, created_at) VALUES (638, 179, 'updated', 'workers', NULL, '["Ко и Се"]', 1, 'Administrator', 'admin', '2026-07-08T10:32:38.360780+00:00');
INSERT INTO order_history (id, order_id, action, field, old_value, new_value, user_id, user_name, user_role, created_at) VALUES (639, 179, 'updated', 'layout_type', 'В работе', 'Утвержден', 13, 'Сергей', 'designer', '2026-07-08T10:37:01.853089+00:00');
INSERT INTO order_history (id, order_id, action, field, old_value, new_value, user_id, user_name, user_role, created_at) VALUES (640, 178, 'updated', 'workers', NULL, '["Konstantin"]', 12, 'Майя', 'designer', '2026-07-08T10:39:50.758511+00:00');
INSERT INTO order_history (id, order_id, action, field, old_value, new_value, user_id, user_name, user_role, created_at) VALUES (641, 178, 'updated', 'path', NULL, '\\\\192.168.1.150\\bufer\\!!!\\Алла визитки\\карточки\\В печать', 12, 'Майя', 'designer', '2026-07-08T10:39:50.758511+00:00');
INSERT INTO order_history (id, order_id, action, field, old_value, new_value, user_id, user_name, user_role, created_at) VALUES (642, 178, 'item_printed', 'item', NULL, 'Карточки', 14, 'Константин', 'production', '2026-07-08T10:51:26.870442+00:00');
INSERT INTO order_history (id, order_id, action, field, old_value, new_value, user_id, user_name, user_role, created_at) VALUES (643, 178, 'item_completed', 'item', NULL, 'Карточки', 14, 'Константин', 'production', '2026-07-08T10:51:29.414841+00:00');
INSERT INTO order_history (id, order_id, action, field, old_value, new_value, user_id, user_name, user_role, created_at) VALUES (644, 178, 'status_changed', 'status', 'Новый', 'Готов', 14, 'Константин', 'production', '2026-07-08T10:51:29.456082+00:00');
INSERT INTO order_history (id, order_id, action, field, old_value, new_value, user_id, user_name, user_role, created_at) VALUES (645, 180, 'created', NULL, NULL, 'Заказ #180 создан', 12, 'Майя', 'designer', '2026-07-08T11:11:37.454837+00:00');
INSERT INTO order_history (id, order_id, action, field, old_value, new_value, user_id, user_name, user_role, created_at) VALUES (646, 178, 'updated', 'workers', '["Konstantin"]', NULL, 9, 'Дмитрий', 'manager', '2026-07-08T11:16:49.982851+00:00');
INSERT INTO order_history (id, order_id, action, field, old_value, new_value, user_id, user_name, user_role, created_at) VALUES (647, 181, 'created', NULL, NULL, 'Заказ #181 создан', 11, 'Александра', 'designer', '2026-07-08T11:27:57.860510+00:00');
INSERT INTO order_history (id, order_id, action, field, old_value, new_value, user_id, user_name, user_role, created_at) VALUES (648, 182, 'created', NULL, NULL, 'Заказ #182 создан', 11, 'Александра', 'designer', '2026-07-08T11:32:44.482950+00:00');
INSERT INTO order_history (id, order_id, action, field, old_value, new_value, user_id, user_name, user_role, created_at) VALUES (649, 180, 'updated', 'description', 'Стенд ПВХ 3мм, 1400х1750мм
Карманы 10х15см', 'Стенд ПВХ 3мм, 1400х1750мм
Карманы 10х15см
Табличка 100х75см пвх 3мм с глянцевой ламинацией 
', 9, 'Дмитрий', 'manager', '2026-07-08T11:34:09.945520+00:00');
INSERT INTO order_history (id, order_id, action, field, old_value, new_value, user_id, user_name, user_role, created_at) VALUES (650, 180, 'updated', 'workers', '["Konstantin", "Sergey"]', NULL, 9, 'Дмитрий', 'manager', '2026-07-08T11:34:09.945520+00:00');
INSERT INTO order_history (id, order_id, action, field, old_value, new_value, user_id, user_name, user_role, created_at) VALUES (651, 178, 'status_changed', 'status', 'Готов', 'Отдали', 9, 'Дмитрий', 'manager', '2026-07-08T11:35:05.301462+00:00');
INSERT INTO order_history (id, order_id, action, field, old_value, new_value, user_id, user_name, user_role, created_at) VALUES (652, 183, 'created', NULL, NULL, 'Заказ #183 создан', 11, 'Александра', 'designer', '2026-07-08T11:38:15.044249+00:00');
INSERT INTO order_history (id, order_id, action, field, old_value, new_value, user_id, user_name, user_role, created_at) VALUES (655, 180, 'updated', 'workers', NULL, '["Ко и Се"]', 12, 'Майя', 'designer', '2026-07-08T11:41:32.820751+00:00');
INSERT INTO order_history (id, order_id, action, field, old_value, new_value, user_id, user_name, user_role, created_at) VALUES (656, 183, 'updated', 'description', NULL, 'Карточки 10х6см, бумага 200 гр мат, 4+0 — 210 шт', 11, 'Александра', 'designer', '2026-07-08T11:42:04.515063+00:00');
INSERT INTO order_history (id, order_id, action, field, old_value, new_value, user_id, user_name, user_role, created_at) VALUES (657, 185, 'created', NULL, NULL, 'Заказ #185 создан', 11, 'Александра', 'designer', '2026-07-08T11:47:05.966562+00:00');
INSERT INTO order_history (id, order_id, action, field, old_value, new_value, user_id, user_name, user_role, created_at) VALUES (658, 186, 'created', NULL, NULL, 'Заказ #186 создан', 1, 'Administrator', 'admin', '2026-07-08T11:53:08.291222+00:00');
INSERT INTO order_history (id, order_id, action, field, old_value, new_value, user_id, user_name, user_role, created_at) VALUES (659, 186, 'updated', 'description', NULL, 'Медали — 45 шт', 1, 'Administrator', 'admin', '2026-07-08T11:53:41.538884+00:00');
INSERT INTO order_history (id, order_id, action, field, old_value, new_value, user_id, user_name, user_role, created_at) VALUES (660, 186, 'updated', 'deadline', NULL, '2026-07-09 21:00:00+00:00', 1, 'Administrator', 'admin', '2026-07-08T11:53:41.538884+00:00');
INSERT INTO order_history (id, order_id, action, field, old_value, new_value, user_id, user_name, user_role, created_at) VALUES (661, 186, 'updated', 'deadline_start', NULL, '2026-07-09 21:00:00+00:00', 1, 'Administrator', 'admin', '2026-07-08T11:53:41.538884+00:00');
INSERT INTO order_history (id, order_id, action, field, old_value, new_value, user_id, user_name, user_role, created_at) VALUES (662, 181, 'updated', 'workers', '["Konstantin"]', '["Konstantin", "Константин"]', 11, 'Александра', 'designer', '2026-07-08T11:55:31.711840+00:00');
INSERT INTO order_history (id, order_id, action, field, old_value, new_value, user_id, user_name, user_role, created_at) VALUES (663, 181, 'updated', 'workers', '["Konstantin", "Константин"]', '["Константин"]', 11, 'Александра', 'designer', '2026-07-08T11:55:34.955833+00:00');
INSERT INTO order_history (id, order_id, action, field, old_value, new_value, user_id, user_name, user_role, created_at) VALUES (664, 187, 'created', NULL, NULL, 'Заказ #187 создан', 9, 'Дмитрий', 'manager', '2026-07-08T12:06:30.134007+00:00');
INSERT INTO order_history (id, order_id, action, field, old_value, new_value, user_id, user_name, user_role, created_at) VALUES (665, 188, 'created', NULL, NULL, 'Заказ #188 создан', 13, 'Сергей', 'designer', '2026-07-08T12:07:39.219011+00:00');
INSERT INTO order_history (id, order_id, action, field, old_value, new_value, user_id, user_name, user_role, created_at) VALUES (666, 188, 'updated', 'description', NULL, 'Таблички ПВХ 3мм  — 14 шт
Таблички ПВХ 3мм — 69 шт
Таблички ПВХ 3мм — 4 шт
Самоклейка 1.3м Наклейки на стекло — 19 шт', 13, 'Сергей', 'designer', '2026-07-08T12:08:44.498829+00:00');
INSERT INTO order_history (id, order_id, action, field, old_value, new_value, user_id, user_name, user_role, created_at) VALUES (667, 188, 'updated', 'designer', NULL, 'Sergey', 13, 'Сергей', 'designer', '2026-07-08T12:08:44.498829+00:00');
INSERT INTO order_history (id, order_id, action, field, old_value, new_value, user_id, user_name, user_role, created_at) VALUES (668, 188, 'updated', 'layout_type', NULL, 'Утвержден', 13, 'Сергей', 'designer', '2026-07-08T12:08:44.498829+00:00');
INSERT INTO order_history (id, order_id, action, field, old_value, new_value, user_id, user_name, user_role, created_at) VALUES (669, 188, 'updated', 'path', NULL, '\\\\192.168.1.150\\bufer\\Анатолий\\08.07.26', 13, 'Сергей', 'designer', '2026-07-08T12:08:44.498829+00:00');
INSERT INTO order_history (id, order_id, action, field, old_value, new_value, user_id, user_name, user_role, created_at) VALUES (670, 188, 'updated', 'source', NULL, 'вк', 13, 'Сергей', 'designer', '2026-07-08T12:08:44.498829+00:00');
INSERT INTO order_history (id, order_id, action, field, old_value, new_value, user_id, user_name, user_role, created_at) VALUES (671, 188, 'updated', 'workers', NULL, '["Ко и Се"]', 13, 'Сергей', 'designer', '2026-07-08T12:08:52.850319+00:00');
INSERT INTO order_history (id, order_id, action, field, old_value, new_value, user_id, user_name, user_role, created_at) VALUES (672, 182, 'updated', 'workers', '["Nastya_Irina"]', '["Nastya_Irina", "Настя и Ирина"]', 16, 'Настя и Ирина', 'production', '2026-07-08T12:14:58.818821+00:00');
INSERT INTO order_history (id, order_id, action, field, old_value, new_value, user_id, user_name, user_role, created_at) VALUES (673, 185, 'updated', 'workers', '["Nastya_Irina"]', '["Nastya_Irina", "Настя и Ирина"]', 16, 'Настя и Ирина', 'production', '2026-07-08T12:15:02.327931+00:00');
INSERT INTO order_history (id, order_id, action, field, old_value, new_value, user_id, user_name, user_role, created_at) VALUES (674, 185, 'updated', 'workers', '["Nastya_Irina", "Настя и Ирина"]', '["Настя и Ирина"]', 16, 'Настя и Ирина', 'production', '2026-07-08T12:15:04.516696+00:00');
INSERT INTO order_history (id, order_id, action, field, old_value, new_value, user_id, user_name, user_role, created_at) VALUES (675, 182, 'updated', 'workers', '["Nastya_Irina", "Настя и Ирина"]', '["Настя и Ирина"]', 16, 'Настя и Ирина', 'production', '2026-07-08T12:15:06.467032+00:00');
INSERT INTO order_history (id, order_id, action, field, old_value, new_value, user_id, user_name, user_role, created_at) VALUES (676, 189, 'created', NULL, NULL, 'Заказ #189 создан', 11, 'Александра', 'designer', '2026-07-08T12:21:51.584861+00:00');
INSERT INTO order_history (id, order_id, action, field, old_value, new_value, user_id, user_name, user_role, created_at) VALUES (677, 189, 'updated', 'workers', '["Nastya_Irina"]', '["Nastya_Irina", "Настя и Ирина"]', 11, 'Александра', 'designer', '2026-07-08T12:22:37.691806+00:00');
INSERT INTO order_history (id, order_id, action, field, old_value, new_value, user_id, user_name, user_role, created_at) VALUES (678, 189, 'updated', 'workers', '["Nastya_Irina", "Настя и Ирина"]', '["Настя и Ирина"]', 11, 'Александра', 'designer', '2026-07-08T12:22:51.024461+00:00');
INSERT INTO order_history (id, order_id, action, field, old_value, new_value, user_id, user_name, user_role, created_at) VALUES (679, 190, 'created', NULL, NULL, 'Заказ #190 создан', 9, 'Дмитрий', 'manager', '2026-07-08T12:33:11.766857+00:00');
INSERT INTO order_history (id, order_id, action, field, old_value, new_value, user_id, user_name, user_role, created_at) VALUES (680, 183, 'updated', 'layout_type', 'В работе', 'Утвержден', 1, 'Administrator', 'admin', '2026-07-08T12:33:34.619433+00:00');
INSERT INTO order_history (id, order_id, action, field, old_value, new_value, user_id, user_name, user_role, created_at) VALUES (681, 183, 'updated', 'layout_type', 'Утвержден', 'В работе', 1, 'Administrator', 'admin', '2026-07-08T12:33:36.323952+00:00');
INSERT INTO order_history (id, order_id, action, field, old_value, new_value, user_id, user_name, user_role, created_at) VALUES (682, 187, 'updated', 'description', NULL, 'ПВХ табличка  — 1 шт', 9, 'Дмитрий', 'manager', '2026-07-08T12:34:16.622861+00:00');
INSERT INTO order_history (id, order_id, action, field, old_value, new_value, user_id, user_name, user_role, created_at) VALUES (683, 178, 'updated', 'workers', NULL, '["Ко и Се"]', 1, 'Administrator', 'admin', '2026-07-08T12:36:57.853828+00:00');
INSERT INTO order_history (id, order_id, action, field, old_value, new_value, user_id, user_name, user_role, created_at) VALUES (684, 187, 'updated', 'description', 'ПВХ табличка  — 1 шт', 'ПВХ 5мм. таблички  — 5 шт. Размер 1000х260мм', 10, 'Алёна', 'designer', '2026-07-08T12:37:14.828172+00:00');
INSERT INTO order_history (id, order_id, action, field, old_value, new_value, user_id, user_name, user_role, created_at) VALUES (685, 187, 'updated', 'layout_type', 'Не взят', 'В работе', 10, 'Алёна', 'designer', '2026-07-08T12:37:14.828172+00:00');
INSERT INTO order_history (id, order_id, action, field, old_value, new_value, user_id, user_name, user_role, created_at) VALUES (686, 178, 'updated', 'layout_type', 'В работе', 'Утвержден', 1, 'Administrator', 'admin', '2026-07-08T12:43:33.219434+00:00');
INSERT INTO order_history (id, order_id, action, field, old_value, new_value, user_id, user_name, user_role, created_at) VALUES (687, 190, 'updated', 'notes', NULL, 'НЕ ХВАТАЕТ 1 СКАНА!', 9, 'Дмитрий', 'manager', '2026-07-08T12:50:32.796000+00:00');
INSERT INTO order_history (id, order_id, action, field, old_value, new_value, user_id, user_name, user_role, created_at) VALUES (688, 190, 'updated', 'designer', NULL, 'Maya', 9, 'Дмитрий', 'manager', '2026-07-08T12:50:32.796000+00:00');
INSERT INTO order_history (id, order_id, action, field, old_value, new_value, user_id, user_name, user_role, created_at) VALUES (689, 190, 'updated', 'path', NULL, '\\\\192.168.1.150\\bufer\\Елена (с улицы)\\Исходники', 9, 'Дмитрий', 'manager', '2026-07-08T12:50:32.796000+00:00');
INSERT INTO order_history (id, order_id, action, field, old_value, new_value, user_id, user_name, user_role, created_at) VALUES (690, 186, 'updated', 'designer', NULL, 'Sergey', 1, 'Administrator', 'admin', '2026-07-08T12:57:31.203757+00:00');
INSERT INTO order_history (id, order_id, action, field, old_value, new_value, user_id, user_name, user_role, created_at) VALUES (691, 186, 'updated', 'workers', NULL, '["Ри и Се"]', 1, 'Administrator', 'admin', '2026-07-08T12:57:35.911840+00:00');
INSERT INTO order_history (id, order_id, action, field, old_value, new_value, user_id, user_name, user_role, created_at) VALUES (692, 186, 'item_printed', 'item', NULL, 'Медали', 1, 'Administrator', 'admin', '2026-07-08T13:03:14.119474+00:00');
INSERT INTO order_history (id, order_id, action, field, old_value, new_value, user_id, user_name, user_role, created_at) VALUES (693, 186, 'status_changed', 'status', 'Новый', 'В работе', 1, 'Administrator', 'admin', '2026-07-08T13:03:24.402412+00:00');
INSERT INTO order_history (id, order_id, action, field, old_value, new_value, user_id, user_name, user_role, created_at) VALUES (694, 186, 'updated', 'workers', '["Ри и Се"]', '["Ри и Се", "Настя и Ирина"]', 1, 'Administrator', 'admin', '2026-07-08T13:03:35.623972+00:00');
INSERT INTO order_history (id, order_id, action, field, old_value, new_value, user_id, user_name, user_role, created_at) VALUES (695, 186, 'status_changed', 'status', 'В работе', 'Новый', 1, 'Administrator', 'admin', '2026-07-08T13:04:07.537775+00:00');
INSERT INTO order_history (id, order_id, action, field, old_value, new_value, user_id, user_name, user_role, created_at) VALUES (696, 186, 'status_changed', 'status', 'Новый', 'В работе', 1, 'Administrator', 'admin', '2026-07-08T13:04:10.852005+00:00');
INSERT INTO order_history (id, order_id, action, field, old_value, new_value, user_id, user_name, user_role, created_at) VALUES (697, 191, 'created', NULL, NULL, 'Заказ #191 создан', 12, 'Майя', 'designer', '2026-07-08T13:12:17.369297+00:00');
INSERT INTO order_history (id, order_id, action, field, old_value, new_value, user_id, user_name, user_role, created_at) VALUES (698, 187, 'updated', 'description', 'ПВХ 5мм. таблички  — 5 шт. Размер 1000х260мм', 'ПВХ 5мм. таблички  — 5 шт. Размер 1000х260мм
ПВХ 5мм. таблички  — 1 шт. Размер 1000х260мм (суворова) ИЗ МАКСА', 12, 'Майя', 'designer', '2026-07-08T13:17:52.332659+00:00');
INSERT INTO order_history (id, order_id, action, field, old_value, new_value, user_id, user_name, user_role, created_at) VALUES (699, 186, 'status_changed', 'status', 'В работе', 'Новый', 1, 'Administrator', 'admin', '2026-07-08T13:27:17.534153+00:00');
INSERT INTO order_history (id, order_id, action, field, old_value, new_value, user_id, user_name, user_role, created_at) VALUES (700, 186, 'status_changed', 'status', 'Новый', 'В работе', 1, 'Administrator', 'admin', '2026-07-08T13:27:48.666719+00:00');
INSERT INTO order_history (id, order_id, action, field, old_value, new_value, user_id, user_name, user_role, created_at) VALUES (701, 183, 'updated', 'notes', 'Карточки 10х6см, припуски 3мм, 4+0 на SRA3, бумага 200 гр мат, 210 шт', 'Карточки 10х6см, припуски 3мм, 4+0 на SRA3, бумага 200 гр мат, 240 шт', 11, 'Александра', 'designer', '2026-07-08T13:28:36.956839+00:00');
INSERT INTO order_history (id, order_id, action, field, old_value, new_value, user_id, user_name, user_role, created_at) VALUES (702, 183, 'updated', 'workers', NULL, '["Константин"]', 11, 'Александра', 'designer', '2026-07-08T13:28:36.956839+00:00');
INSERT INTO order_history (id, order_id, action, field, old_value, new_value, user_id, user_name, user_role, created_at) VALUES (703, 183, 'updated', 'layout_type', 'В работе', 'Утвержден', 11, 'Александра', 'designer', '2026-07-08T13:28:36.956839+00:00');
INSERT INTO order_history (id, order_id, action, field, old_value, new_value, user_id, user_name, user_role, created_at) VALUES (704, 183, 'updated', 'path', NULL, '\\\\192.168.1.150\\bufer\\Холсты Лусине Любовь Кротость\\Карточки\\08.07.26', 11, 'Александра', 'designer', '2026-07-08T13:28:36.956839+00:00');
INSERT INTO order_history (id, order_id, action, field, old_value, new_value, user_id, user_name, user_role, created_at) VALUES (705, 192, 'created', NULL, NULL, 'Заказ #192 создан', 10, 'Алёна', 'designer', '2026-07-08T13:34:18.723771+00:00');
INSERT INTO order_history (id, order_id, action, field, old_value, new_value, user_id, user_name, user_role, created_at) VALUES (706, 192, 'status_changed', 'status', 'В работе', 'Новый', 10, 'Алёна', 'designer', '2026-07-08T13:34:37.471787+00:00');
INSERT INTO order_history (id, order_id, action, field, old_value, new_value, user_id, user_name, user_role, created_at) VALUES (707, 186, 'status_changed', 'status', 'В работе', 'Новый', 1, 'Administrator', 'admin', '2026-07-08T13:37:18.179206+00:00');
INSERT INTO order_history (id, order_id, action, field, old_value, new_value, user_id, user_name, user_role, created_at) VALUES (708, 186, 'status_changed', 'status', 'Новый', 'В работе', 1, 'Administrator', 'admin', '2026-07-08T13:37:25.353767+00:00');
INSERT INTO order_history (id, order_id, action, field, old_value, new_value, user_id, user_name, user_role, created_at) VALUES (709, 190, 'updated', 'description', 'Копирование листовок А, печать каждой по 50шт (1000шт)', 'Копирование листовок А5, печать каждой по 50шт (1000шт)', 9, 'Дмитрий', 'manager', '2026-07-08T13:45:09.116850+00:00');
INSERT INTO order_history (id, order_id, action, field, old_value, new_value, user_id, user_name, user_role, created_at) VALUES (710, 190, 'updated', 'workers', '["Konstantin"]', NULL, 9, 'Дмитрий', 'manager', '2026-07-08T13:45:09.116850+00:00');
INSERT INTO order_history (id, order_id, action, field, old_value, new_value, user_id, user_name, user_role, created_at) VALUES (711, 187, 'updated', 'description', 'ПВХ 5мм. таблички  — 5 шт. Размер 1000х260мм
ПВХ 5мм. таблички  — 1 шт. Размер 1000х260мм (суворова) ИЗ МАКСА', 'ПВХ 5мм. таблички  — 5 шт. Размер 1000х260мм
Композит таблички  — 1 шт. Размер 1000х260мм (суворова) ИЗ МАКСА', 12, 'Майя', 'designer', '2026-07-08T13:55:13.374831+00:00');
INSERT INTO order_history (id, order_id, action, field, old_value, new_value, user_id, user_name, user_role, created_at) VALUES (712, 191, 'updated', 'path', NULL, '\\\\192.168.1.150\\bufer\\Первые\\Юнаты\\Флешки', 12, 'Майя', 'designer', '2026-07-08T14:00:09.007848+00:00');
INSERT INTO order_history (id, order_id, action, field, old_value, new_value, user_id, user_name, user_role, created_at) VALUES (713, 190, 'updated', 'layout_type', 'Не взят', 'В работе', 12, 'Майя', 'designer', '2026-07-08T14:00:15.693895+00:00');
INSERT INTO order_history (id, order_id, action, field, old_value, new_value, user_id, user_name, user_role, created_at) VALUES (714, 191, 'updated', 'workers', NULL, '["Ри и Се"]', 12, 'Майя', 'designer', '2026-07-08T14:00:25.409654+00:00');
INSERT INTO order_history (id, order_id, action, field, old_value, new_value, user_id, user_name, user_role, created_at) VALUES (715, 187, 'updated', 'description', 'ПВХ 5мм. таблички  — 5 шт. Размер 1000х260мм
Композит таблички  — 1 шт. Размер 1000х260мм (суворова) ИЗ МАКСА', 'ПВХ 5мм. таблички  — 5 шт. Размер 1000х260мм
Композит таблички дырочками 4 шт и креплением для кирпичной стены  — 1 шт. Размер 1000х260мм (суворова) ИЗ МАКСА', 12, 'Майя', 'designer', '2026-07-08T14:01:43.308450+00:00');
INSERT INTO order_history (id, order_id, action, field, old_value, new_value, user_id, user_name, user_role, created_at) VALUES (716, 187, 'updated', 'description', 'ПВХ 5мм. таблички  — 5 шт. Размер 1000х260мм
Композит таблички дырочками 4 шт и креплением для кирпичной стены  — 1 шт. Размер 1000х260мм (суворова) ИЗ МАКСА', 'ПВХ 5мм. таблички  — 5 шт. Размер 1000х260мм
Композит таблички дырочками 4 шт и креплением для кирпичной стены  — 1 шт. Размер 1000х260мм (суворова) ИЗ МАКСА
Билеты — 208 шт.', 10, 'Алёна', 'designer', '2026-07-08T14:05:22.832850+00:00');
INSERT INTO order_history (id, order_id, action, field, old_value, new_value, user_id, user_name, user_role, created_at) VALUES (717, 187, 'updated', 'workers', NULL, '["Konstantin"]', 10, 'Алёна', 'designer', '2026-07-08T14:05:22.832850+00:00');
INSERT INTO order_history (id, order_id, action, field, old_value, new_value, user_id, user_name, user_role, created_at) VALUES (775, 186, 'updated', 'source', NULL, 'вк', 9, 'Дмитрий', 'manager', '2026-07-09T09:31:19.595508+00:00');
INSERT INTO order_history (id, order_id, action, field, old_value, new_value, user_id, user_name, user_role, created_at) VALUES (718, 187, 'updated', 'path', NULL, '\\\\192.168.1.150\\bufer\\ИГЭУ\\Антонюк\\Аншлаги', 10, 'Алёна', 'designer', '2026-07-08T14:05:22.832850+00:00');
INSERT INTO order_history (id, order_id, action, field, old_value, new_value, user_id, user_name, user_role, created_at) VALUES (719, 187, 'updated', 'workers', '["Konstantin"]', NULL, 10, 'Алёна', 'designer', '2026-07-08T14:12:00.495855+00:00');
INSERT INTO order_history (id, order_id, action, field, old_value, new_value, user_id, user_name, user_role, created_at) VALUES (720, 186, 'status_changed', 'status', 'В работе', 'Новый', 1, 'Administrator', 'admin', '2026-07-08T14:21:03.404102+00:00');
INSERT INTO order_history (id, order_id, action, field, old_value, new_value, user_id, user_name, user_role, created_at) VALUES (721, 186, 'status_changed', 'status', 'Новый', 'В работе', 1, 'Administrator', 'admin', '2026-07-08T14:21:21.058787+00:00');
INSERT INTO order_history (id, order_id, action, field, old_value, new_value, user_id, user_name, user_role, created_at) VALUES (722, 193, 'created', NULL, NULL, 'Заказ #193 создан', 1, 'Administrator', 'admin', '2026-07-08T14:50:30.240042+00:00');
INSERT INTO order_history (id, order_id, action, field, old_value, new_value, user_id, user_name, user_role, created_at) VALUES (723, 193, 'status_changed', 'status', 'Новый', 'Готов', 1, 'Administrator', 'admin', '2026-07-08T14:50:34.356954+00:00');
INSERT INTO order_history (id, order_id, action, field, old_value, new_value, user_id, user_name, user_role, created_at) VALUES (724, 181, 'item_completed', 'item', NULL, 'Листовки и аниме бумага', 14, 'Константин', 'production', '2026-07-08T15:01:12.622861+00:00');
INSERT INTO order_history (id, order_id, action, field, old_value, new_value, user_id, user_name, user_role, created_at) VALUES (725, 181, 'status_changed', 'status', 'Новый', 'Готов', 14, 'Константин', 'production', '2026-07-08T15:01:12.654833+00:00');
INSERT INTO order_history (id, order_id, action, field, old_value, new_value, user_id, user_name, user_role, created_at) VALUES (726, 183, 'item_completed', 'item', NULL, 'Карточки 10х6см, бумага 200 гр мат, 4+0', 14, 'Константин', 'production', '2026-07-08T15:02:01.365218+00:00');
INSERT INTO order_history (id, order_id, action, field, old_value, new_value, user_id, user_name, user_role, created_at) VALUES (727, 183, 'status_changed', 'status', 'Новый', 'Готов', 14, 'Константин', 'production', '2026-07-08T15:02:01.393504+00:00');
INSERT INTO order_history (id, order_id, action, field, old_value, new_value, user_id, user_name, user_role, created_at) VALUES (728, 177, 'status_changed', 'status', 'Новый', 'В работе', 1, 'Administrator', 'admin', '2026-07-08T15:07:33.750840+00:00');
INSERT INTO order_history (id, order_id, action, field, old_value, new_value, user_id, user_name, user_role, created_at) VALUES (729, 190, 'updated', 'layout_type', 'В работе', 'Утвержден', 12, 'Майя', 'designer', '2026-07-08T15:30:32.847108+00:00');
INSERT INTO order_history (id, order_id, action, field, old_value, new_value, user_id, user_name, user_role, created_at) VALUES (730, 190, 'updated', 'path', '\\\\192.168.1.150\\bufer\\Елена (с улицы)\\Исходники', '\\\\192.168.1.150\\bufer\\Елена (с улицы)\\В печать', 12, 'Майя', 'designer', '2026-07-08T16:03:28.001069+00:00');
INSERT INTO order_history (id, order_id, action, field, old_value, new_value, user_id, user_name, user_role, created_at) VALUES (731, 190, 'updated', 'workers', NULL, '["Константин"]', 12, 'Майя', 'designer', '2026-07-08T16:03:36.534057+00:00');
INSERT INTO order_history (id, order_id, action, field, old_value, new_value, user_id, user_name, user_role, created_at) VALUES (732, 177, 'status_changed', 'status', 'В работе', 'Готов', 1, 'Administrator', 'admin', '2026-07-08T16:28:28.697792+00:00');
INSERT INTO order_history (id, order_id, action, field, old_value, new_value, user_id, user_name, user_role, created_at) VALUES (733, 187, 'updated', 'description', 'ПВХ 5мм. таблички  — 5 шт. Размер 1000х260мм
Композит таблички дырочками 4 шт и креплением для кирпичной стены  — 1 шт. Размер 1000х260мм (суворова) ИЗ МАКСА
Билеты — 208 шт.', 'ПВХ 5мм. таблички  — 5 шт. Размер 1000х260мм
Композит таблички дырочками 4 шт диаметр 8мм — 1 шт. Размер 1000х260мм (суворова) ИЗ МАКСА
Билеты — 208 шт.', 12, 'Майя', 'designer', '2026-07-09T07:42:24.122377+00:00');
INSERT INTO order_history (id, order_id, action, field, old_value, new_value, user_id, user_name, user_role, created_at) VALUES (734, 194, 'created', NULL, NULL, 'Заказ #194 создан', 12, 'Майя', 'designer', '2026-07-09T07:47:07.363429+00:00');
INSERT INTO order_history (id, order_id, action, field, old_value, new_value, user_id, user_name, user_role, created_at) VALUES (735, 187, 'updated', 'workers', NULL, '["Константин"]', 12, 'Майя', 'designer', '2026-07-09T07:47:51.011044+00:00');
INSERT INTO order_history (id, order_id, action, field, old_value, new_value, user_id, user_name, user_role, created_at) VALUES (736, 195, 'created', NULL, NULL, 'Заказ #195 создан', 10, 'Алёна', 'designer', '2026-07-09T08:32:00.008848+00:00');
INSERT INTO order_history (id, order_id, action, field, old_value, new_value, user_id, user_name, user_role, created_at) VALUES (737, 192, 'updated', 'workers', '["Sergey"]', '["Sergey", "Ри и Се"]', 10, 'Алёна', 'designer', '2026-07-09T08:33:47.114662+00:00');
INSERT INTO order_history (id, order_id, action, field, old_value, new_value, user_id, user_name, user_role, created_at) VALUES (738, 191, 'updated', 'path', '\\\\192.168.1.150\\bufer\\Первые\\Юнаты\\Флешки', '\\\\192.168.1.150\\bufer\\Первые\\Юнаты\\Флешки
\\\\192.168.1.150\\bufer\\Первые\\Юнаты\\Лупа', 12, 'Майя', 'designer', '2026-07-09T08:44:31.312753+00:00');
INSERT INTO order_history (id, order_id, action, field, old_value, new_value, user_id, user_name, user_role, created_at) VALUES (739, 188, 'updated', 'workers', '["Ко и Се"]', '["Ко и Се", "Константин"]', 1, 'Administrator', 'admin', '2026-07-09T09:01:35.166853+00:00');
INSERT INTO order_history (id, order_id, action, field, old_value, new_value, user_id, user_name, user_role, created_at) VALUES (740, 188, 'updated', 'workers', '["Ко и Се", "Константин"]', '["Константин"]', 1, 'Administrator', 'admin', '2026-07-09T09:01:39.466821+00:00');
INSERT INTO order_history (id, order_id, action, field, old_value, new_value, user_id, user_name, user_role, created_at) VALUES (741, 193, 'status_changed', 'status', 'Готов', 'Отдали', 9, 'Дмитрий', 'manager', '2026-07-09T09:02:56.407038+00:00');
INSERT INTO order_history (id, order_id, action, field, old_value, new_value, user_id, user_name, user_role, created_at) VALUES (742, 191, 'updated', 'description', 'Флешки 16гб, уф печать - 40шт
Блокнот А6, пружина сверху- 400шт
Лупа с уф печать-150шт', 'Флешки 16гб, уф печать - 40шт
Блокнот А6, пружина сверху, блок с печатью 1+0, задник без печати- 400шт
Лупа уф печать-150шт', 12, 'Майя', 'designer', '2026-07-09T09:16:39.234185+00:00');
INSERT INTO order_history (id, order_id, action, field, old_value, new_value, user_id, user_name, user_role, created_at) VALUES (743, 191, 'updated', 'workers', '["Ри и Се"]', '["Ко и Ри и Се"]', 12, 'Майя', 'designer', '2026-07-09T09:16:39.234185+00:00');
INSERT INTO order_history (id, order_id, action, field, old_value, new_value, user_id, user_name, user_role, created_at) VALUES (744, 191, 'updated', 'layout_type', 'В работе', 'Утвержден', 12, 'Майя', 'designer', '2026-07-09T09:16:39.234185+00:00');
INSERT INTO order_history (id, order_id, action, field, old_value, new_value, user_id, user_name, user_role, created_at) VALUES (745, 191, 'updated', 'path', '\\\\192.168.1.150\\bufer\\Первые\\Юнаты\\Флешки
\\\\192.168.1.150\\bufer\\Первые\\Юнаты\\Лупа', '\\\\192.168.1.150\\bufer\\Первые\\Юнаты\\Флешки
\\\\192.168.1.150\\bufer\\Первые\\Юнаты\\Лупа
\\\\192.168.1.150\\bufer\\Первые\\Юнаты\\Блокнот А6\\в печать', 12, 'Майя', 'designer', '2026-07-09T09:16:39.234185+00:00');
INSERT INTO order_history (id, order_id, action, field, old_value, new_value, user_id, user_name, user_role, created_at) VALUES (746, 190, 'item_completed', 'item', NULL, 'Копирование листовок А5, 150г, 4+4', 14, 'Константин', 'production', '2026-07-09T09:25:45.837815+00:00');
INSERT INTO order_history (id, order_id, action, field, old_value, new_value, user_id, user_name, user_role, created_at) VALUES (747, 190, 'item_uncompleted', 'item', NULL, 'Копирование листовок А5, 150г, 4+4', 14, 'Константин', 'production', '2026-07-09T09:25:49.504939+00:00');
INSERT INTO order_history (id, order_id, action, field, old_value, new_value, user_id, user_name, user_role, created_at) VALUES (748, 190, 'item_completed', 'item', NULL, 'Копирование листовок А5, 150г, 4+4', 14, 'Константин', 'production', '2026-07-09T09:25:50.866561+00:00');
INSERT INTO order_history (id, order_id, action, field, old_value, new_value, user_id, user_name, user_role, created_at) VALUES (749, 190, 'item_uncompleted', 'item', NULL, 'Копирование листовок А5, 150г, 4+4', 14, 'Константин', 'production', '2026-07-09T09:25:51.332602+00:00');
INSERT INTO order_history (id, order_id, action, field, old_value, new_value, user_id, user_name, user_role, created_at) VALUES (750, 190, 'item_completed', 'item', NULL, 'Копирование листовок А5, 150г, 4+4', 14, 'Константин', 'production', '2026-07-09T09:25:51.872994+00:00');
INSERT INTO order_history (id, order_id, action, field, old_value, new_value, user_id, user_name, user_role, created_at) VALUES (751, 190, 'item_uncompleted', 'item', NULL, 'Копирование листовок А5, 150г, 4+4', 14, 'Константин', 'production', '2026-07-09T09:25:52.102589+00:00');
INSERT INTO order_history (id, order_id, action, field, old_value, new_value, user_id, user_name, user_role, created_at) VALUES (752, 190, 'item_completed', 'item', NULL, 'Копирование листовок А5, 150г, 4+4', 14, 'Константин', 'production', '2026-07-09T09:25:56.214391+00:00');
INSERT INTO order_history (id, order_id, action, field, old_value, new_value, user_id, user_name, user_role, created_at) VALUES (753, 190, 'item_unprinted', 'item', NULL, 'Копирование листовок А5, 150г, 4+4', 14, 'Константин', 'production', '2026-07-09T09:25:56.977393+00:00');
INSERT INTO order_history (id, order_id, action, field, old_value, new_value, user_id, user_name, user_role, created_at) VALUES (754, 190, 'item_completed', 'item', NULL, 'Копирование листовок А5, 150г, 4+4', 14, 'Константин', 'production', '2026-07-09T09:26:01.727267+00:00');
INSERT INTO order_history (id, order_id, action, field, old_value, new_value, user_id, user_name, user_role, created_at) VALUES (755, 190, 'item_uncompleted', 'item', NULL, 'Копирование листовок А5, 150г, 4+4', 14, 'Константин', 'production', '2026-07-09T09:26:10.578275+00:00');
INSERT INTO order_history (id, order_id, action, field, old_value, new_value, user_id, user_name, user_role, created_at) VALUES (756, 190, 'item_completed', 'item', NULL, 'Копирование листовок А5, 150г, 4+4', 14, 'Константин', 'production', '2026-07-09T09:26:14.979749+00:00');
INSERT INTO order_history (id, order_id, action, field, old_value, new_value, user_id, user_name, user_role, created_at) VALUES (757, 190, 'item_uncompleted', 'item', NULL, 'Копирование листовок А5, 150г, 4+4', 14, 'Константин', 'production', '2026-07-09T09:26:30.452277+00:00');
INSERT INTO order_history (id, order_id, action, field, old_value, new_value, user_id, user_name, user_role, created_at) VALUES (758, 190, 'item_completed', 'item', NULL, 'Копирование листовок А5, 150г, 4+4', 14, 'Константин', 'production', '2026-07-09T09:27:14.961387+00:00');
INSERT INTO order_history (id, order_id, action, field, old_value, new_value, user_id, user_name, user_role, created_at) VALUES (759, 190, 'item_unprinted', 'item', NULL, 'Копирование листовок А5, 150г, 4+4', 14, 'Константин', 'production', '2026-07-09T09:27:16.067043+00:00');
INSERT INTO order_history (id, order_id, action, field, old_value, new_value, user_id, user_name, user_role, created_at) VALUES (760, 190, 'item_printed', 'item', NULL, 'Копирование листовок А5, 150г, 4+4', 14, 'Константин', 'production', '2026-07-09T09:27:17.630384+00:00');
INSERT INTO order_history (id, order_id, action, field, old_value, new_value, user_id, user_name, user_role, created_at) VALUES (761, 190, 'item_unprinted', 'item', NULL, 'Копирование листовок А5, 150г, 4+4', 14, 'Константин', 'production', '2026-07-09T09:27:18.994640+00:00');
INSERT INTO order_history (id, order_id, action, field, old_value, new_value, user_id, user_name, user_role, created_at) VALUES (762, 190, 'item_printed', 'item', NULL, 'Копирование листовок А5, 150г, 4+4', 14, 'Константин', 'production', '2026-07-09T09:27:19.825053+00:00');
INSERT INTO order_history (id, order_id, action, field, old_value, new_value, user_id, user_name, user_role, created_at) VALUES (763, 190, 'item_unprinted', 'item', NULL, 'Копирование листовок А5, 150г, 4+4', 14, 'Константин', 'production', '2026-07-09T09:27:21.707177+00:00');
INSERT INTO order_history (id, order_id, action, field, old_value, new_value, user_id, user_name, user_role, created_at) VALUES (764, 190, 'item_completed', 'item', NULL, 'Копирование листовок А5, 150г, 4+4', 14, 'Константин', 'production', '2026-07-09T09:27:23.049194+00:00');
INSERT INTO order_history (id, order_id, action, field, old_value, new_value, user_id, user_name, user_role, created_at) VALUES (765, 190, 'item_uncompleted', 'item', NULL, 'Копирование листовок А5, 150г, 4+4', 14, 'Константин', 'production', '2026-07-09T09:27:23.961189+00:00');
INSERT INTO order_history (id, order_id, action, field, old_value, new_value, user_id, user_name, user_role, created_at) VALUES (770, 190, 'item_unprinted', 'item', NULL, 'Копирование листовок А5, 150г, 4+4', 14, 'Константин', 'production', '2026-07-09T09:27:25.686628+00:00');
INSERT INTO order_history (id, order_id, action, field, old_value, new_value, user_id, user_name, user_role, created_at) VALUES (766, 190, 'item_completed', 'item', NULL, 'Копирование листовок А5, 150г, 4+4', 14, 'Константин', 'production', '2026-07-09T09:27:24.141575+00:00');
INSERT INTO order_history (id, order_id, action, field, old_value, new_value, user_id, user_name, user_role, created_at) VALUES (767, 190, 'item_uncompleted', 'item', NULL, 'Копирование листовок А5, 150г, 4+4', 14, 'Константин', 'production', '2026-07-09T09:27:24.319447+00:00');
INSERT INTO order_history (id, order_id, action, field, old_value, new_value, user_id, user_name, user_role, created_at) VALUES (768, 190, 'item_completed', 'item', NULL, 'Копирование листовок А5, 150г, 4+4', 14, 'Константин', 'production', '2026-07-09T09:27:24.875775+00:00');
INSERT INTO order_history (id, order_id, action, field, old_value, new_value, user_id, user_name, user_role, created_at) VALUES (769, 190, 'item_uncompleted', 'item', NULL, 'Копирование листовок А5, 150г, 4+4', 14, 'Константин', 'production', '2026-07-09T09:27:25.068860+00:00');
INSERT INTO order_history (id, order_id, action, field, old_value, new_value, user_id, user_name, user_role, created_at) VALUES (771, 190, 'item_completed', 'item', NULL, 'Копирование листовок А5, 150г, 4+4', 14, 'Константин', 'production', '2026-07-09T09:27:41.960621+00:00');
INSERT INTO order_history (id, order_id, action, field, old_value, new_value, user_id, user_name, user_role, created_at) VALUES (772, 190, 'status_changed', 'status', 'Новый', 'Готов', 14, 'Константин', 'production', '2026-07-09T09:27:42.001884+00:00');
INSERT INTO order_history (id, order_id, action, field, old_value, new_value, user_id, user_name, user_role, created_at) VALUES (773, 190, 'updated', 'workers', '["Константин"]', NULL, 9, 'Дмитрий', 'manager', '2026-07-09T09:30:40.495005+00:00');
INSERT INTO order_history (id, order_id, action, field, old_value, new_value, user_id, user_name, user_role, created_at) VALUES (774, 176, 'updated', 'source', NULL, 'МАХ', 9, 'Дмитрий', 'manager', '2026-07-09T09:31:16.347369+00:00');
INSERT INTO order_history (id, order_id, action, field, old_value, new_value, user_id, user_name, user_role, created_at) VALUES (776, 194, 'item_completed', 'item', NULL, 'Карточки', 14, 'Константин', 'production', '2026-07-09T09:40:20.082831+00:00');
INSERT INTO order_history (id, order_id, action, field, old_value, new_value, user_id, user_name, user_role, created_at) VALUES (777, 194, 'status_changed', 'status', 'Новый', 'Готов', 14, 'Константин', 'production', '2026-07-09T09:40:20.119596+00:00');
INSERT INTO order_history (id, order_id, action, field, old_value, new_value, user_id, user_name, user_role, created_at) VALUES (778, 196, 'created', NULL, NULL, 'Заказ #196 создан', 13, 'Сергей', 'designer', '2026-07-09T09:51:40.565219+00:00');
INSERT INTO order_history (id, order_id, action, field, old_value, new_value, user_id, user_name, user_role, created_at) VALUES (779, 192, 'status_changed', 'status', 'Новый', 'Готов', 1, 'Administrator', 'admin', '2026-07-09T10:29:56.575837+00:00');
INSERT INTO order_history (id, order_id, action, field, old_value, new_value, user_id, user_name, user_role, created_at) VALUES (780, 194, 'status_changed', 'status', 'Готов', 'Отдали', 9, 'Дмитрий', 'manager', '2026-07-09T10:34:34.977759+00:00');
INSERT INTO order_history (id, order_id, action, field, old_value, new_value, user_id, user_name, user_role, created_at) VALUES (781, 190, 'status_changed', 'status', 'Готов', 'Отдали', 9, 'Дмитрий', 'manager', '2026-07-09T10:34:43.778334+00:00');
INSERT INTO order_history (id, order_id, action, field, old_value, new_value, user_id, user_name, user_role, created_at) VALUES (782, 177, 'status_changed', 'status', 'Готов', 'Отдали', 9, 'Дмитрий', 'manager', '2026-07-09T10:41:25.500970+00:00');
INSERT INTO order_history (id, order_id, action, field, old_value, new_value, user_id, user_name, user_role, created_at) VALUES (783, 181, 'status_changed', 'status', 'Готов', 'Отдали', 9, 'Дмитрий', 'manager', '2026-07-09T11:00:10.988474+00:00');
INSERT INTO order_history (id, order_id, action, field, old_value, new_value, user_id, user_name, user_role, created_at) VALUES (784, 192, 'status_changed', 'status', 'Готов', 'Отдали', 9, 'Дмитрий', 'manager', '2026-07-09T11:00:23.705500+00:00');
INSERT INTO order_history (id, order_id, action, field, old_value, new_value, user_id, user_name, user_role, created_at) VALUES (785, 186, 'status_changed', 'status', 'В работе', 'Готов', 9, 'Дмитрий', 'manager', '2026-07-09T11:05:14.310869+00:00');
INSERT INTO order_history (id, order_id, action, field, old_value, new_value, user_id, user_name, user_role, created_at) VALUES (786, 187, 'updated', 'description', 'ПВХ 5мм. таблички  — 5 шт. Размер 1000х260мм
Композит таблички дырочками 4 шт диаметр 8мм — 1 шт. Размер 1000х260мм (суворова) ИЗ МАКСА
Билеты — 208 шт.', 'ПВХ 5мм. таблички  — 5 шт. Размер 1000х260мм
Композит таблички дырочками 4 шт диаметр 8мм — 1 шт. Размер 1000х260мм (суворова) ИЗ МАКСА
Билеты — 250 шт. 115гр глянец, 4+0', 10, 'Алёна', 'designer', '2026-07-09T11:10:51.139408+00:00');
INSERT INTO order_history (id, order_id, action, field, old_value, new_value, user_id, user_name, user_role, created_at) VALUES (787, 187, 'updated', 'layout_type', 'В работе', 'Утвержден', 10, 'Алёна', 'designer', '2026-07-09T11:10:51.139408+00:00');
INSERT INTO order_history (id, order_id, action, field, old_value, new_value, user_id, user_name, user_role, created_at) VALUES (788, 187, 'updated', 'path', '\\\\192.168.1.150\\bufer\\ИГЭУ\\Антонюк\\Аншлаги', '\\\\192.168.1.150\\bufer\\ИГЭУ\\Антонюк\\Аншлаги
\\\\192.168.1.150\\bufer\\Харинка\\Билеты Харинка', 10, 'Алёна', 'designer', '2026-07-09T11:10:51.139408+00:00');
INSERT INTO order_history (id, order_id, action, field, old_value, new_value, user_id, user_name, user_role, created_at) VALUES (789, 197, 'created', NULL, NULL, 'Заказ #197 создан', 13, 'Сергей', 'designer', '2026-07-09T11:36:12.182907+00:00');
INSERT INTO order_history (id, order_id, action, field, old_value, new_value, user_id, user_name, user_role, created_at) VALUES (790, 198, 'created', NULL, NULL, 'Заказ #198 создан', 13, 'Сергей', 'designer', '2026-07-09T12:50:17.505827+00:00');
INSERT INTO order_history (id, order_id, action, field, old_value, new_value, user_id, user_name, user_role, created_at) VALUES (791, 199, 'created', NULL, NULL, 'Заказ #199 создан', 11, 'Александра', 'designer', '2026-07-09T12:53:13.891659+00:00');
INSERT INTO order_history (id, order_id, action, field, old_value, new_value, user_id, user_name, user_role, created_at) VALUES (792, 197, 'item_printed', 'item', NULL, 'Самоклейка 1.3м наклейки ', 14, 'Константин', 'production', '2026-07-09T13:03:57.495394+00:00');
INSERT INTO order_history (id, order_id, action, field, old_value, new_value, user_id, user_name, user_role, created_at) VALUES (793, 197, 'item_unprinted', 'item', NULL, 'Самоклейка 1.3м наклейки ', 14, 'Константин', 'production', '2026-07-09T13:03:58.988804+00:00');
INSERT INTO order_history (id, order_id, action, field, old_value, new_value, user_id, user_name, user_role, created_at) VALUES (794, 197, 'item_printed', 'item', NULL, 'Самоклейка 1.3м наклейки ', 14, 'Константин', 'production', '2026-07-09T13:04:03.663042+00:00');
INSERT INTO order_history (id, order_id, action, field, old_value, new_value, user_id, user_name, user_role, created_at) VALUES (795, 197, 'item_unprinted', 'item', NULL, 'Самоклейка 1.3м наклейки ', 14, 'Константин', 'production', '2026-07-09T13:04:07.417439+00:00');
INSERT INTO order_history (id, order_id, action, field, old_value, new_value, user_id, user_name, user_role, created_at) VALUES (796, 197, 'updated', 'workers', '["Константин"]', '["Константин", "Ко и Ри"]', 14, 'Константин', 'production', '2026-07-09T13:05:17.503811+00:00');
INSERT INTO order_history (id, order_id, action, field, old_value, new_value, user_id, user_name, user_role, created_at) VALUES (797, 197, 'updated', 'workers', '["Константин", "Ко и Ри"]', '["Константин"]', 14, 'Константин', 'production', '2026-07-09T13:06:05.988395+00:00');
INSERT INTO order_history (id, order_id, action, field, old_value, new_value, user_id, user_name, user_role, created_at) VALUES (798, 196, 'status_changed', 'status', 'Новый', 'В работе', 14, 'Константин', 'production', '2026-07-09T13:06:35.931019+00:00');
INSERT INTO order_history (id, order_id, action, field, old_value, new_value, user_id, user_name, user_role, created_at) VALUES (799, 197, 'status_changed', 'status', 'Новый', 'В работе', 14, 'Константин', 'production', '2026-07-09T13:06:39.634279+00:00');
INSERT INTO order_history (id, order_id, action, field, old_value, new_value, user_id, user_name, user_role, created_at) VALUES (800, 197, 'item_completed', 'item', NULL, 'Самоклейка 1.3м наклейки ', 14, 'Константин', 'production', '2026-07-09T13:20:32.137744+00:00');
INSERT INTO order_history (id, order_id, action, field, old_value, new_value, user_id, user_name, user_role, created_at) VALUES (801, 197, 'status_changed', 'status', 'В работе', 'Готов', 14, 'Константин', 'production', '2026-07-09T13:20:32.159841+00:00');
INSERT INTO order_history (id, order_id, action, field, old_value, new_value, user_id, user_name, user_role, created_at) VALUES (802, 199, 'updated', 'workers', NULL, '["Сергей"]', 11, 'Александра', 'designer', '2026-07-09T13:31:18.966151+00:00');
INSERT INTO order_history (id, order_id, action, field, old_value, new_value, user_id, user_name, user_role, created_at) VALUES (803, 196, 'item_completed', 'item', NULL, 'Самоклейка 1.3м наклейки ', 14, 'Константин', 'production', '2026-07-09T13:49:56.004704+00:00');
INSERT INTO order_history (id, order_id, action, field, old_value, new_value, user_id, user_name, user_role, created_at) VALUES (804, 196, 'status_changed', 'status', 'В работе', 'Готов', 14, 'Константин', 'production', '2026-07-09T13:49:56.030030+00:00');
INSERT INTO order_history (id, order_id, action, field, old_value, new_value, user_id, user_name, user_role, created_at) VALUES (805, 200, 'created', NULL, NULL, 'Заказ #200 создан', 9, 'Дмитрий', 'manager', '2026-07-09T14:16:30.897887+00:00');
INSERT INTO order_history (id, order_id, action, field, old_value, new_value, user_id, user_name, user_role, created_at) VALUES (806, 185, 'status_changed', 'status', 'Новый', 'Готов', 9, 'Дмитрий', 'manager', '2026-07-09T14:39:56.667369+00:00');
INSERT INTO order_history (id, order_id, action, field, old_value, new_value, user_id, user_name, user_role, created_at) VALUES (807, 200, 'updated', 'source', NULL, 'вк', 9, 'Дмитрий', 'manager', '2026-07-09T14:40:14.618184+00:00');
INSERT INTO order_history (id, order_id, action, field, old_value, new_value, user_id, user_name, user_role, created_at) VALUES (808, 195, 'item_printed', 'item', NULL, 'Таблички ', 1, 'Administrator', 'admin', '2026-07-09T15:32:41.726633+00:00');
INSERT INTO order_history (id, order_id, action, field, old_value, new_value, user_id, user_name, user_role, created_at) VALUES (809, 195, 'status_changed', 'status', 'Новый', 'В работе', 1, 'Administrator', 'admin', '2026-07-09T15:32:51.523647+00:00');
SELECT setval(''order_history_id_seq'::regclass', 809);

DROP SEQUENCE IF EXISTS 'order_item_raw_materials_id_seq'::regclass CASCADE;
CREATE SEQUENCE 'order_item_raw_materials_id_seq'::regclass START WITH 52 INCREMENT BY 1 NO MINVALUE NO MAXVALUE CACHE 1;
DROP TABLE IF EXISTS order_item_raw_materials CASCADE;
CREATE TABLE order_item_raw_materials (
  id integer NOT NULL,
  order_item_id integer NOT NULL,
  raw_material_id integer NOT NULL,
  raw_material_qty double precision,
  cut_width_mm double precision,
  cut_height_mm double precision,
  PRIMARY KEY (id)
);
ALTER TABLE order_item_raw_materials ALTER COLUMN id SET DEFAULT nextval(''order_item_raw_materials_id_seq'::regclass'::regclass);
INSERT INTO order_item_raw_materials (id, order_item_id, raw_material_id, raw_material_qty, cut_width_mm, cut_height_mm) VALUES (3, 254, 3, 0.5, 210.0, 297.0);
INSERT INTO order_item_raw_materials (id, order_item_id, raw_material_id, raw_material_qty, cut_width_mm, cut_height_mm) VALUES (4, 266, 2, 0.033333, 90.0, 50.0);
INSERT INTO order_item_raw_materials (id, order_item_id, raw_material_id, raw_material_qty, cut_width_mm, cut_height_mm) VALUES (5, 269, 2, 0.033333, 90.0, 50.0);
INSERT INTO order_item_raw_materials (id, order_item_id, raw_material_id, raw_material_qty, cut_width_mm, cut_height_mm) VALUES (6, 287, 3, 0.5, 210.0, 297.0);
INSERT INTO order_item_raw_materials (id, order_item_id, raw_material_id, raw_material_qty, cut_width_mm, cut_height_mm) VALUES (7, 288, 1, 1.0, 1000.0, 1000.0);
INSERT INTO order_item_raw_materials (id, order_item_id, raw_material_id, raw_material_qty, cut_width_mm, cut_height_mm) VALUES (8, 290, 1, 3.0, 3000.0, 1000.0);
INSERT INTO order_item_raw_materials (id, order_item_id, raw_material_id, raw_material_qty, cut_width_mm, cut_height_mm) VALUES (9, 291, 8, 0.0027778, 110.0, 150.0);
INSERT INTO order_item_raw_materials (id, order_item_id, raw_material_id, raw_material_qty, cut_width_mm, cut_height_mm) VALUES (10, 292, 8, 0.25, 1200.0, 800.0);
INSERT INTO order_item_raw_materials (id, order_item_id, raw_material_id, raw_material_qty, cut_width_mm, cut_height_mm) VALUES (11, 293, 8, 0.25, 1200.0, 800.0);
INSERT INTO order_item_raw_materials (id, order_item_id, raw_material_id, raw_material_qty, cut_width_mm, cut_height_mm) VALUES (12, 294, 8, 0.25, 1200.0, 800.0);
INSERT INTO order_item_raw_materials (id, order_item_id, raw_material_id, raw_material_qty, cut_width_mm, cut_height_mm) VALUES (13, 295, 8, 0.25, 1200.0, 800.0);
INSERT INTO order_item_raw_materials (id, order_item_id, raw_material_id, raw_material_qty, cut_width_mm, cut_height_mm) VALUES (14, 296, 8, 0.07692307692307693, 110.0, 160.0);
INSERT INTO order_item_raw_materials (id, order_item_id, raw_material_id, raw_material_qty, cut_width_mm, cut_height_mm) VALUES (15, 297, 8, 0.5, 1200.0, 800.0);
INSERT INTO order_item_raw_materials (id, order_item_id, raw_material_id, raw_material_qty, cut_width_mm, cut_height_mm) VALUES (16, 298, 8, 0.5, 1200.0, 800.0);
INSERT INTO order_item_raw_materials (id, order_item_id, raw_material_id, raw_material_qty, cut_width_mm, cut_height_mm) VALUES (17, 299, 8, 0.25, 1200.0, 800.0);
INSERT INTO order_item_raw_materials (id, order_item_id, raw_material_id, raw_material_qty, cut_width_mm, cut_height_mm) VALUES (18, 300, 8, 0.25, 1200.0, 800.0);
INSERT INTO order_item_raw_materials (id, order_item_id, raw_material_id, raw_material_qty, cut_width_mm, cut_height_mm) VALUES (19, 301, 8, 0.05, 120.0, 150.0);
INSERT INTO order_item_raw_materials (id, order_item_id, raw_material_id, raw_material_qty, cut_width_mm, cut_height_mm) VALUES (20, 302, 8, 0.038461538461538464, 120.0, 100.0);
INSERT INTO order_item_raw_materials (id, order_item_id, raw_material_id, raw_material_qty, cut_width_mm, cut_height_mm) VALUES (21, 303, 8, 0.047619047619047616, 120.0, 80.0);
INSERT INTO order_item_raw_materials (id, order_item_id, raw_material_id, raw_material_qty, cut_width_mm, cut_height_mm) VALUES (22, 305, 8, 1.0, 120.0, 100.0);
INSERT INTO order_item_raw_materials (id, order_item_id, raw_material_id, raw_material_qty, cut_width_mm, cut_height_mm) VALUES (23, 306, 8, 1.0, 120.0, 100.0);
INSERT INTO order_item_raw_materials (id, order_item_id, raw_material_id, raw_material_qty, cut_width_mm, cut_height_mm) VALUES (24, 307, 8, 0.25, 1200.0, 800.0);
INSERT INTO order_item_raw_materials (id, order_item_id, raw_material_id, raw_material_qty, cut_width_mm, cut_height_mm) VALUES (25, 308, 8, 0.047619047619047616, 120.0, 80.0);
INSERT INTO order_item_raw_materials (id, order_item_id, raw_material_id, raw_material_qty, cut_width_mm, cut_height_mm) VALUES (26, 309, 8, 0.25, 1200.0, 800.0);
INSERT INTO order_item_raw_materials (id, order_item_id, raw_material_id, raw_material_qty, cut_width_mm, cut_height_mm) VALUES (27, 310, 8, 0.0, 120.0, 80.0);
INSERT INTO order_item_raw_materials (id, order_item_id, raw_material_id, raw_material_qty, cut_width_mm, cut_height_mm) VALUES (28, 311, 8, 0.0, 120.0, 95.0);
INSERT INTO order_item_raw_materials (id, order_item_id, raw_material_id, raw_material_qty, cut_width_mm, cut_height_mm) VALUES (29, 312, 8, 0.25, 1200.0, 800.0);
INSERT INTO order_item_raw_materials (id, order_item_id, raw_material_id, raw_material_qty, cut_width_mm, cut_height_mm) VALUES (30, 313, 8, 0.0, 120.0, 80.0);
INSERT INTO order_item_raw_materials (id, order_item_id, raw_material_id, raw_material_qty, cut_width_mm, cut_height_mm) VALUES (31, 314, 8, 0.25, 1200.0, 800.0);
INSERT INTO order_item_raw_materials (id, order_item_id, raw_material_id, raw_material_qty, cut_width_mm, cut_height_mm) VALUES (32, 315, 8, 0.0, 120.0, 80.0);
INSERT INTO order_item_raw_materials (id, order_item_id, raw_material_id, raw_material_qty, cut_width_mm, cut_height_mm) VALUES (33, 316, 8, 0.0016, 120.0, 80.0);
INSERT INTO order_item_raw_materials (id, order_item_id, raw_material_id, raw_material_qty, cut_width_mm, cut_height_mm) VALUES (34, 317, 8, 0.0, 120.0, 80.0);
INSERT INTO order_item_raw_materials (id, order_item_id, raw_material_id, raw_material_qty, cut_width_mm, cut_height_mm) VALUES (35, 318, 8, 0.0, 120.0, 80.0);
INSERT INTO order_item_raw_materials (id, order_item_id, raw_material_id, raw_material_qty, cut_width_mm, cut_height_mm) VALUES (36, 319, 8, 0.0, 1200.0, 800.0);
INSERT INTO order_item_raw_materials (id, order_item_id, raw_material_id, raw_material_qty, cut_width_mm, cut_height_mm) VALUES (37, 320, 8, 0.0, 1200.0, 800.0);
INSERT INTO order_item_raw_materials (id, order_item_id, raw_material_id, raw_material_qty, cut_width_mm, cut_height_mm) VALUES (38, 321, 8, 0.0, 1200.0, 800.0);
INSERT INTO order_item_raw_materials (id, order_item_id, raw_material_id, raw_material_qty, cut_width_mm, cut_height_mm) VALUES (39, 322, 8, 0.25, 1200.0, 800.0);
INSERT INTO order_item_raw_materials (id, order_item_id, raw_material_id, raw_material_qty, cut_width_mm, cut_height_mm) VALUES (40, 323, 8, 0.0, 120.0, 80.0);
INSERT INTO order_item_raw_materials (id, order_item_id, raw_material_id, raw_material_qty, cut_width_mm, cut_height_mm) VALUES (41, 324, 8, 0.25, 1200.0, 800.0);
INSERT INTO order_item_raw_materials (id, order_item_id, raw_material_id, raw_material_qty, cut_width_mm, cut_height_mm) VALUES (42, 325, 8, 0.0, 120.0, 80.0);
INSERT INTO order_item_raw_materials (id, order_item_id, raw_material_id, raw_material_qty, cut_width_mm, cut_height_mm) VALUES (43, 326, 8, 0.25, 1200.0, 800.0);
INSERT INTO order_item_raw_materials (id, order_item_id, raw_material_id, raw_material_qty, cut_width_mm, cut_height_mm) VALUES (44, 327, 8, 0.0, 120.0, 80.0);
INSERT INTO order_item_raw_materials (id, order_item_id, raw_material_id, raw_material_qty, cut_width_mm, cut_height_mm) VALUES (45, 328, 8, 0.0, 120.0, 80.0);
INSERT INTO order_item_raw_materials (id, order_item_id, raw_material_id, raw_material_qty, cut_width_mm, cut_height_mm) VALUES (46, 329, 8, 0.0, 120.0, 80.0);
INSERT INTO order_item_raw_materials (id, order_item_id, raw_material_id, raw_material_qty, cut_width_mm, cut_height_mm) VALUES (49, 393, 9, 0.02631578947368421, 90.0, 40.0);
INSERT INTO order_item_raw_materials (id, order_item_id, raw_material_id, raw_material_qty, cut_width_mm, cut_height_mm) VALUES (52, 407, 10, 0.000667, 60.0, 66.0);
SELECT setval(''order_item_raw_materials_id_seq'::regclass', 52);

DROP SEQUENCE IF EXISTS 'order_items_id_seq'::regclass CASCADE;
CREATE SEQUENCE 'order_items_id_seq'::regclass START WITH 470 INCREMENT BY 1 NO MINVALUE NO MAXVALUE CACHE 1;
DROP TABLE IF EXISTS order_items CASCADE;
CREATE TABLE order_items (
  id integer NOT NULL,
  order_id integer NOT NULL,
  product_id integer,
  product_name_snapshot character varying(255),
  product_unit_snapshot character varying(50),
  product_formula_snapshot text,
  product_formula_script_snapshot character varying(255),
  raw_material_id integer,
  raw_material_qty double precision,
  cut_width_mm double precision,
  cut_height_mm double precision,
  quantity integer NOT NULL,
  unit_price double precision NOT NULL,
  is_completed boolean NOT NULL,
  is_printed boolean NOT NULL,
  manual_writeoff_pending boolean DEFAULT false,
  manual_writeoff_raw_material_id integer,
  manual_writeoff_cut_width_mm double precision,
  manual_writeoff_cut_height_mm double precision,
  manual_writeoff_quantity double precision,
  processing_method character varying(100),
  PRIMARY KEY (id)
);
ALTER TABLE order_items ALTER COLUMN id SET DEFAULT nextval(''order_items_id_seq'::regclass'::regclass);
INSERT INTO order_items (id, order_id, product_id, product_name_snapshot, product_unit_snapshot, product_formula_snapshot, product_formula_script_snapshot, raw_material_id, raw_material_qty, cut_width_mm, cut_height_mm, quantity, unit_price, is_completed, is_printed, manual_writeoff_pending, manual_writeoff_raw_material_id, manual_writeoff_cut_width_mm, manual_writeoff_cut_height_mm, manual_writeoff_quantity, processing_method) VALUES (394, 181, NULL, 'Листовки и аниме бумага', 'шт', NULL, NULL, NULL, NULL, NULL, NULL, 1, 0.0, TRUE, TRUE, FALSE, NULL, NULL, NULL, NULL, NULL);
INSERT INTO order_items (id, order_id, product_id, product_name_snapshot, product_unit_snapshot, product_formula_snapshot, product_formula_script_snapshot, raw_material_id, raw_material_qty, cut_width_mm, cut_height_mm, quantity, unit_price, is_completed, is_printed, manual_writeoff_pending, manual_writeoff_raw_material_id, manual_writeoff_cut_width_mm, manual_writeoff_cut_height_mm, manual_writeoff_quantity, processing_method) VALUES (432, 183, NULL, 'Карточки 10х6см, бумага 200 гр мат, 4+0', 'шт', NULL, NULL, NULL, NULL, NULL, NULL, 240, 0.0, TRUE, TRUE, FALSE, NULL, NULL, NULL, NULL, NULL);
INSERT INTO order_items (id, order_id, product_id, product_name_snapshot, product_unit_snapshot, product_formula_snapshot, product_formula_script_snapshot, raw_material_id, raw_material_qty, cut_width_mm, cut_height_mm, quantity, unit_price, is_completed, is_printed, manual_writeoff_pending, manual_writeoff_raw_material_id, manual_writeoff_cut_width_mm, manual_writeoff_cut_height_mm, manual_writeoff_quantity, processing_method) VALUES (460, 196, NULL, 'Самоклейка 1.3м наклейки ', 'шт', NULL, NULL, NULL, NULL, 80.0, 30.0, 1000, 0.0, TRUE, TRUE, FALSE, NULL, NULL, NULL, NULL, NULL);
INSERT INTO order_items (id, order_id, product_id, product_name_snapshot, product_unit_snapshot, product_formula_snapshot, product_formula_script_snapshot, raw_material_id, raw_material_qty, cut_width_mm, cut_height_mm, quantity, unit_price, is_completed, is_printed, manual_writeoff_pending, manual_writeoff_raw_material_id, manual_writeoff_cut_width_mm, manual_writeoff_cut_height_mm, manual_writeoff_quantity, processing_method) VALUES (352, 176, NULL, 'Карманный календарь, 300г, 4+4, лам - глянц тонкая ', 'шт', NULL, NULL, NULL, NULL, NULL, NULL, 1, 195.0, FALSE, FALSE, FALSE, NULL, NULL, NULL, NULL, NULL);
INSERT INTO order_items (id, order_id, product_id, product_name_snapshot, product_unit_snapshot, product_formula_snapshot, product_formula_script_snapshot, raw_material_id, raw_material_qty, cut_width_mm, cut_height_mm, quantity, unit_price, is_completed, is_printed, manual_writeoff_pending, manual_writeoff_raw_material_id, manual_writeoff_cut_width_mm, manual_writeoff_cut_height_mm, manual_writeoff_quantity, processing_method) VALUES (353, 176, NULL, 'Ручка пластик УФ печать', 'шт', NULL, NULL, NULL, NULL, NULL, NULL, 1, 85.0, FALSE, FALSE, FALSE, NULL, NULL, NULL, NULL, NULL);
INSERT INTO order_items (id, order_id, product_id, product_name_snapshot, product_unit_snapshot, product_formula_snapshot, product_formula_script_snapshot, raw_material_id, raw_material_qty, cut_width_mm, cut_height_mm, quantity, unit_price, is_completed, is_printed, manual_writeoff_pending, manual_writeoff_raw_material_id, manual_writeoff_cut_width_mm, manual_writeoff_cut_height_mm, manual_writeoff_quantity, processing_method) VALUES (354, 176, NULL, 'Подставка для телефона с гравировкой', 'шт', NULL, NULL, NULL, NULL, NULL, NULL, 1, 315.0, FALSE, FALSE, FALSE, NULL, NULL, NULL, NULL, NULL);
INSERT INTO order_items (id, order_id, product_id, product_name_snapshot, product_unit_snapshot, product_formula_snapshot, product_formula_script_snapshot, raw_material_id, raw_material_qty, cut_width_mm, cut_height_mm, quantity, unit_price, is_completed, is_printed, manual_writeoff_pending, manual_writeoff_raw_material_id, manual_writeoff_cut_width_mm, manual_writeoff_cut_height_mm, manual_writeoff_quantity, processing_method) VALUES (355, 176, NULL, 'Ремувка ', 'шт', NULL, NULL, NULL, NULL, NULL, NULL, 1, 1.0, FALSE, FALSE, FALSE, NULL, NULL, NULL, NULL, NULL);
INSERT INTO order_items (id, order_id, product_id, product_name_snapshot, product_unit_snapshot, product_formula_snapshot, product_formula_script_snapshot, raw_material_id, raw_material_qty, cut_width_mm, cut_height_mm, quantity, unit_price, is_completed, is_printed, manual_writeoff_pending, manual_writeoff_raw_material_id, manual_writeoff_cut_width_mm, manual_writeoff_cut_height_mm, manual_writeoff_quantity, processing_method) VALUES (356, 176, NULL, 'Значок  38мм', 'шт', NULL, NULL, NULL, NULL, NULL, NULL, 1, 40.0, FALSE, FALSE, FALSE, NULL, NULL, NULL, NULL, NULL);
INSERT INTO order_items (id, order_id, product_id, product_name_snapshot, product_unit_snapshot, product_formula_snapshot, product_formula_script_snapshot, raw_material_id, raw_material_qty, cut_width_mm, cut_height_mm, quantity, unit_price, is_completed, is_printed, manual_writeoff_pending, manual_writeoff_raw_material_id, manual_writeoff_cut_width_mm, manual_writeoff_cut_height_mm, manual_writeoff_quantity, processing_method) VALUES (357, 176, NULL, 'Значок  56мм', 'шт', NULL, NULL, NULL, NULL, NULL, NULL, 1, 60.0, FALSE, FALSE, FALSE, NULL, NULL, NULL, NULL, NULL);
INSERT INTO order_items (id, order_id, product_id, product_name_snapshot, product_unit_snapshot, product_formula_snapshot, product_formula_script_snapshot, raw_material_id, raw_material_qty, cut_width_mm, cut_height_mm, quantity, unit_price, is_completed, is_printed, manual_writeoff_pending, manual_writeoff_raw_material_id, manual_writeoff_cut_width_mm, manual_writeoff_cut_height_mm, manual_writeoff_quantity, processing_method) VALUES (358, 176, NULL, 'Изготовление брелка', 'шт', NULL, NULL, NULL, NULL, NULL, NULL, 1, 150.0, FALSE, FALSE, FALSE, NULL, NULL, NULL, NULL, NULL);
INSERT INTO order_items (id, order_id, product_id, product_name_snapshot, product_unit_snapshot, product_formula_snapshot, product_formula_script_snapshot, raw_material_id, raw_material_qty, cut_width_mm, cut_height_mm, quantity, unit_price, is_completed, is_printed, manual_writeoff_pending, manual_writeoff_raw_material_id, manual_writeoff_cut_width_mm, manual_writeoff_cut_height_mm, manual_writeoff_quantity, processing_method) VALUES (359, 176, NULL, 'ДТФ нанесение на сумки', 'шт', NULL, NULL, NULL, NULL, NULL, NULL, 1, 550.0, FALSE, FALSE, FALSE, NULL, NULL, NULL, NULL, NULL);
INSERT INTO order_items (id, order_id, product_id, product_name_snapshot, product_unit_snapshot, product_formula_snapshot, product_formula_script_snapshot, raw_material_id, raw_material_qty, cut_width_mm, cut_height_mm, quantity, unit_price, is_completed, is_printed, manual_writeoff_pending, manual_writeoff_raw_material_id, manual_writeoff_cut_width_mm, manual_writeoff_cut_height_mm, manual_writeoff_quantity, processing_method) VALUES (360, 176, NULL, 'Кепка с вышивкой', 'шт', NULL, NULL, NULL, NULL, NULL, NULL, 1, 1.0, FALSE, FALSE, FALSE, NULL, NULL, NULL, NULL, NULL);
INSERT INTO order_items (id, order_id, product_id, product_name_snapshot, product_unit_snapshot, product_formula_snapshot, product_formula_script_snapshot, raw_material_id, raw_material_qty, cut_width_mm, cut_height_mm, quantity, unit_price, is_completed, is_printed, manual_writeoff_pending, manual_writeoff_raw_material_id, manual_writeoff_cut_width_mm, manual_writeoff_cut_height_mm, manual_writeoff_quantity, processing_method) VALUES (361, 176, NULL, 'стикерпак А6', 'шт', NULL, NULL, NULL, NULL, NULL, NULL, 60, 15.0, FALSE, FALSE, FALSE, NULL, NULL, NULL, NULL, NULL);
INSERT INTO order_items (id, order_id, product_id, product_name_snapshot, product_unit_snapshot, product_formula_snapshot, product_formula_script_snapshot, raw_material_id, raw_material_qty, cut_width_mm, cut_height_mm, quantity, unit_price, is_completed, is_printed, manual_writeoff_pending, manual_writeoff_raw_material_id, manual_writeoff_cut_width_mm, manual_writeoff_cut_height_mm, manual_writeoff_quantity, processing_method) VALUES (362, 176, NULL, 'Бутылки с УФ печатью', 'шт', NULL, NULL, NULL, NULL, NULL, NULL, 30, 450.0, FALSE, FALSE, FALSE, NULL, NULL, NULL, NULL, NULL);
INSERT INTO order_items (id, order_id, product_id, product_name_snapshot, product_unit_snapshot, product_formula_snapshot, product_formula_script_snapshot, raw_material_id, raw_material_qty, cut_width_mm, cut_height_mm, quantity, unit_price, is_completed, is_printed, manual_writeoff_pending, manual_writeoff_raw_material_id, manual_writeoff_cut_width_mm, manual_writeoff_cut_height_mm, manual_writeoff_quantity, processing_method) VALUES (363, 176, NULL, 'Коврик для мыши', 'шт', NULL, NULL, NULL, NULL, NULL, NULL, 10, 395.0, FALSE, FALSE, FALSE, NULL, NULL, NULL, NULL, NULL);
INSERT INTO order_items (id, order_id, product_id, product_name_snapshot, product_unit_snapshot, product_formula_snapshot, product_formula_script_snapshot, raw_material_id, raw_material_qty, cut_width_mm, cut_height_mm, quantity, unit_price, is_completed, is_printed, manual_writeoff_pending, manual_writeoff_raw_material_id, manual_writeoff_cut_width_mm, manual_writeoff_cut_height_mm, manual_writeoff_quantity, processing_method) VALUES (364, 176, NULL, 'Кружка керамическая с нанесением', 'шт', NULL, NULL, NULL, NULL, NULL, NULL, 30, 270.0, FALSE, FALSE, FALSE, NULL, NULL, NULL, NULL, NULL);
INSERT INTO order_items (id, order_id, product_id, product_name_snapshot, product_unit_snapshot, product_formula_snapshot, product_formula_script_snapshot, raw_material_id, raw_material_qty, cut_width_mm, cut_height_mm, quantity, unit_price, is_completed, is_printed, manual_writeoff_pending, manual_writeoff_raw_material_id, manual_writeoff_cut_width_mm, manual_writeoff_cut_height_mm, manual_writeoff_quantity, processing_method) VALUES (445, 193, NULL, 'Ручки паркер', 'шт', NULL, NULL, NULL, NULL, 0.0, 0.0, 8, 0.0, TRUE, FALSE, FALSE, NULL, NULL, NULL, NULL, NULL);
INSERT INTO order_items (id, order_id, product_id, product_name_snapshot, product_unit_snapshot, product_formula_snapshot, product_formula_script_snapshot, raw_material_id, raw_material_qty, cut_width_mm, cut_height_mm, quantity, unit_price, is_completed, is_printed, manual_writeoff_pending, manual_writeoff_raw_material_id, manual_writeoff_cut_width_mm, manual_writeoff_cut_height_mm, manual_writeoff_quantity, processing_method) VALUES (433, 192, NULL, 'УФ печать', 'шт', NULL, NULL, NULL, NULL, NULL, NULL, 3, 0.0, TRUE, FALSE, FALSE, NULL, NULL, NULL, NULL, NULL);
INSERT INTO order_items (id, order_id, product_id, product_name_snapshot, product_unit_snapshot, product_formula_snapshot, product_formula_script_snapshot, raw_material_id, raw_material_qty, cut_width_mm, cut_height_mm, quantity, unit_price, is_completed, is_printed, manual_writeoff_pending, manual_writeoff_raw_material_id, manual_writeoff_cut_width_mm, manual_writeoff_cut_height_mm, manual_writeoff_quantity, processing_method) VALUES (367, 177, 27, 'Попсокет', 'piece', NULL, NULL, NULL, NULL, NULL, NULL, 160, 90.0, TRUE, FALSE, FALSE, NULL, NULL, NULL, NULL, NULL);
INSERT INTO order_items (id, order_id, product_id, product_name_snapshot, product_unit_snapshot, product_formula_snapshot, product_formula_script_snapshot, raw_material_id, raw_material_qty, cut_width_mm, cut_height_mm, quantity, unit_price, is_completed, is_printed, manual_writeoff_pending, manual_writeoff_raw_material_id, manual_writeoff_cut_width_mm, manual_writeoff_cut_height_mm, manual_writeoff_quantity, processing_method) VALUES (386, 179, NULL, 'Визитки 4+4, бумага перламутровая светло-серая', 'шт', NULL, NULL, NULL, NULL, 50.0, 90.0, 200, 0.0, FALSE, FALSE, FALSE, NULL, NULL, NULL, NULL, NULL);
INSERT INTO order_items (id, order_id, product_id, product_name_snapshot, product_unit_snapshot, product_formula_snapshot, product_formula_script_snapshot, raw_material_id, raw_material_qty, cut_width_mm, cut_height_mm, quantity, unit_price, is_completed, is_printed, manual_writeoff_pending, manual_writeoff_raw_material_id, manual_writeoff_cut_width_mm, manual_writeoff_cut_height_mm, manual_writeoff_quantity, processing_method) VALUES (387, 179, NULL, '4+4, бумага перламутровая светло-серая с фольгированием', 'шт', NULL, NULL, NULL, NULL, 50.0, 90.0, 250, 0.0, FALSE, FALSE, FALSE, NULL, NULL, NULL, NULL, NULL);
INSERT INTO order_items (id, order_id, product_id, product_name_snapshot, product_unit_snapshot, product_formula_snapshot, product_formula_script_snapshot, raw_material_id, raw_material_qty, cut_width_mm, cut_height_mm, quantity, unit_price, is_completed, is_printed, manual_writeoff_pending, manual_writeoff_raw_material_id, manual_writeoff_cut_width_mm, manual_writeoff_cut_height_mm, manual_writeoff_quantity, processing_method) VALUES (388, 179, NULL, 'Конверт', 'шт', NULL, NULL, NULL, NULL, 220.0, 110.0, 100, 0.0, FALSE, FALSE, FALSE, NULL, NULL, NULL, NULL, NULL);
INSERT INTO order_items (id, order_id, product_id, product_name_snapshot, product_unit_snapshot, product_formula_snapshot, product_formula_script_snapshot, raw_material_id, raw_material_qty, cut_width_mm, cut_height_mm, quantity, unit_price, is_completed, is_printed, manual_writeoff_pending, manual_writeoff_raw_material_id, manual_writeoff_cut_width_mm, manual_writeoff_cut_height_mm, manual_writeoff_quantity, processing_method) VALUES (389, 179, NULL, 'Таблички ПВХ 3мм', 'шт', NULL, NULL, NULL, NULL, 400.0, 200.0, 2, 0.0, FALSE, FALSE, FALSE, NULL, NULL, NULL, NULL, 'Ручная резка');
INSERT INTO order_items (id, order_id, product_id, product_name_snapshot, product_unit_snapshot, product_formula_snapshot, product_formula_script_snapshot, raw_material_id, raw_material_qty, cut_width_mm, cut_height_mm, quantity, unit_price, is_completed, is_printed, manual_writeoff_pending, manual_writeoff_raw_material_id, manual_writeoff_cut_width_mm, manual_writeoff_cut_height_mm, manual_writeoff_quantity, processing_method) VALUES (456, 191, NULL, 'Блокнот А6', 'шт', NULL, NULL, NULL, NULL, NULL, NULL, 400, 0.0, FALSE, FALSE, FALSE, NULL, NULL, NULL, NULL, NULL);
INSERT INTO order_items (id, order_id, product_id, product_name_snapshot, product_unit_snapshot, product_formula_snapshot, product_formula_script_snapshot, raw_material_id, raw_material_qty, cut_width_mm, cut_height_mm, quantity, unit_price, is_completed, is_printed, manual_writeoff_pending, manual_writeoff_raw_material_id, manual_writeoff_cut_width_mm, manual_writeoff_cut_height_mm, manual_writeoff_quantity, processing_method) VALUES (457, 191, NULL, 'Лупа', 'шт', NULL, NULL, NULL, NULL, NULL, NULL, 150, 0.0, FALSE, FALSE, FALSE, NULL, NULL, NULL, NULL, NULL);
INSERT INTO order_items (id, order_id, product_id, product_name_snapshot, product_unit_snapshot, product_formula_snapshot, product_formula_script_snapshot, raw_material_id, raw_material_qty, cut_width_mm, cut_height_mm, quantity, unit_price, is_completed, is_printed, manual_writeoff_pending, manual_writeoff_raw_material_id, manual_writeoff_cut_width_mm, manual_writeoff_cut_height_mm, manual_writeoff_quantity, processing_method) VALUES (458, 191, NULL, 'флешки', 'шт', NULL, NULL, NULL, NULL, NULL, NULL, 40, 0.0, FALSE, FALSE, FALSE, NULL, NULL, NULL, NULL, NULL);
INSERT INTO order_items (id, order_id, product_id, product_name_snapshot, product_unit_snapshot, product_formula_snapshot, product_formula_script_snapshot, raw_material_id, raw_material_qty, cut_width_mm, cut_height_mm, quantity, unit_price, is_completed, is_printed, manual_writeoff_pending, manual_writeoff_raw_material_id, manual_writeoff_cut_width_mm, manual_writeoff_cut_height_mm, manual_writeoff_quantity, processing_method) VALUES (393, 178, NULL, 'Карточки', 'шт', NULL, NULL, 9, 0.02631578947368421, 90.0, 40.0, 38, 4.0, FALSE, FALSE, FALSE, NULL, NULL, NULL, NULL, 'Ручная резка');
INSERT INTO order_items (id, order_id, product_id, product_name_snapshot, product_unit_snapshot, product_formula_snapshot, product_formula_script_snapshot, raw_material_id, raw_material_qty, cut_width_mm, cut_height_mm, quantity, unit_price, is_completed, is_printed, manual_writeoff_pending, manual_writeoff_raw_material_id, manual_writeoff_cut_width_mm, manual_writeoff_cut_height_mm, manual_writeoff_quantity, processing_method) VALUES (395, 182, NULL, 'Футболки 10 шт. с ДТФ печатью', 'шт', NULL, NULL, NULL, NULL, NULL, NULL, 10, 0.0, FALSE, FALSE, FALSE, NULL, NULL, NULL, NULL, NULL);
INSERT INTO order_items (id, order_id, product_id, product_name_snapshot, product_unit_snapshot, product_formula_snapshot, product_formula_script_snapshot, raw_material_id, raw_material_qty, cut_width_mm, cut_height_mm, quantity, unit_price, is_completed, is_printed, manual_writeoff_pending, manual_writeoff_raw_material_id, manual_writeoff_cut_width_mm, manual_writeoff_cut_height_mm, manual_writeoff_quantity, processing_method) VALUES (396, 180, NULL, 'Стенд пвх 3мм', 'шт', NULL, NULL, NULL, NULL, 1400.0, 1750.0, 1, 8760.0, FALSE, FALSE, FALSE, NULL, NULL, NULL, NULL, NULL);
INSERT INTO order_items (id, order_id, product_id, product_name_snapshot, product_unit_snapshot, product_formula_snapshot, product_formula_script_snapshot, raw_material_id, raw_material_qty, cut_width_mm, cut_height_mm, quantity, unit_price, is_completed, is_printed, manual_writeoff_pending, manual_writeoff_raw_material_id, manual_writeoff_cut_width_mm, manual_writeoff_cut_height_mm, manual_writeoff_quantity, processing_method) VALUES (397, 180, NULL, 'Карманы ', 'шт', NULL, NULL, NULL, NULL, 100.0, 150.0, 45, 106.0, FALSE, FALSE, FALSE, NULL, NULL, NULL, NULL, NULL);
INSERT INTO order_items (id, order_id, product_id, product_name_snapshot, product_unit_snapshot, product_formula_snapshot, product_formula_script_snapshot, raw_material_id, raw_material_qty, cut_width_mm, cut_height_mm, quantity, unit_price, is_completed, is_printed, manual_writeoff_pending, manual_writeoff_raw_material_id, manual_writeoff_cut_width_mm, manual_writeoff_cut_height_mm, manual_writeoff_quantity, processing_method) VALUES (398, 180, NULL, 'Табличка 100х75см пвх 3мм с глянцевой ламинацией ', 'шт', NULL, NULL, NULL, NULL, NULL, NULL, 9, 2850.0, FALSE, FALSE, FALSE, NULL, NULL, NULL, NULL, NULL);
INSERT INTO order_items (id, order_id, product_id, product_name_snapshot, product_unit_snapshot, product_formula_snapshot, product_formula_script_snapshot, raw_material_id, raw_material_qty, cut_width_mm, cut_height_mm, quantity, unit_price, is_completed, is_printed, manual_writeoff_pending, manual_writeoff_raw_material_id, manual_writeoff_cut_width_mm, manual_writeoff_cut_height_mm, manual_writeoff_quantity, processing_method) VALUES (407, 186, NULL, 'Медали', 'шт', NULL, NULL, 10, 0.022222222222222223, 60.0, 66.0, 45, 1.0, TRUE, TRUE, FALSE, NULL, NULL, NULL, NULL, 'Лазер');
INSERT INTO order_items (id, order_id, product_id, product_name_snapshot, product_unit_snapshot, product_formula_snapshot, product_formula_script_snapshot, raw_material_id, raw_material_qty, cut_width_mm, cut_height_mm, quantity, unit_price, is_completed, is_printed, manual_writeoff_pending, manual_writeoff_raw_material_id, manual_writeoff_cut_width_mm, manual_writeoff_cut_height_mm, manual_writeoff_quantity, processing_method) VALUES (461, 187, NULL, 'Билеты', 'шт', NULL, NULL, NULL, NULL, NULL, NULL, 250, 0.0, FALSE, FALSE, FALSE, NULL, NULL, NULL, NULL, NULL);
INSERT INTO order_items (id, order_id, product_id, product_name_snapshot, product_unit_snapshot, product_formula_snapshot, product_formula_script_snapshot, raw_material_id, raw_material_qty, cut_width_mm, cut_height_mm, quantity, unit_price, is_completed, is_printed, manual_writeoff_pending, manual_writeoff_raw_material_id, manual_writeoff_cut_width_mm, manual_writeoff_cut_height_mm, manual_writeoff_quantity, processing_method) VALUES (462, 187, NULL, 'ПВХ табличка Антонюк', 'шт', NULL, NULL, NULL, NULL, 1000.0, 250.0, 5, 975.0, FALSE, FALSE, FALSE, NULL, NULL, NULL, NULL, NULL);
INSERT INTO order_items (id, order_id, product_id, product_name_snapshot, product_unit_snapshot, product_formula_snapshot, product_formula_script_snapshot, raw_material_id, raw_material_qty, cut_width_mm, cut_height_mm, quantity, unit_price, is_completed, is_printed, manual_writeoff_pending, manual_writeoff_raw_material_id, manual_writeoff_cut_width_mm, manual_writeoff_cut_height_mm, manual_writeoff_quantity, processing_method) VALUES (463, 187, NULL, 'Табличка композит Жадан дырочками 4 шт диаметр 8мм', 'шт', NULL, NULL, NULL, NULL, NULL, NULL, 1, 0.0, FALSE, FALSE, FALSE, NULL, NULL, NULL, NULL, NULL);
INSERT INTO order_items (id, order_id, product_id, product_name_snapshot, product_unit_snapshot, product_formula_snapshot, product_formula_script_snapshot, raw_material_id, raw_material_qty, cut_width_mm, cut_height_mm, quantity, unit_price, is_completed, is_printed, manual_writeoff_pending, manual_writeoff_raw_material_id, manual_writeoff_cut_width_mm, manual_writeoff_cut_height_mm, manual_writeoff_quantity, processing_method) VALUES (465, 198, NULL, 'Плакат А4, 4+0 115гр мат, припуски 3мм ', 'шт', NULL, NULL, NULL, NULL, 297.0, 210.0, 130, 0.0, FALSE, FALSE, FALSE, NULL, NULL, NULL, NULL, NULL);
INSERT INTO order_items (id, order_id, product_id, product_name_snapshot, product_unit_snapshot, product_formula_snapshot, product_formula_script_snapshot, raw_material_id, raw_material_qty, cut_width_mm, cut_height_mm, quantity, unit_price, is_completed, is_printed, manual_writeoff_pending, manual_writeoff_raw_material_id, manual_writeoff_cut_width_mm, manual_writeoff_cut_height_mm, manual_writeoff_quantity, processing_method) VALUES (467, 200, NULL, 'ПВХ табличка формат А4', 'шт', NULL, NULL, NULL, NULL, 210.0, 297.0, 3, 370.0, FALSE, FALSE, FALSE, NULL, NULL, NULL, NULL, 'Фреза');
INSERT INTO order_items (id, order_id, product_id, product_name_snapshot, product_unit_snapshot, product_formula_snapshot, product_formula_script_snapshot, raw_material_id, raw_material_qty, cut_width_mm, cut_height_mm, quantity, unit_price, is_completed, is_printed, manual_writeoff_pending, manual_writeoff_raw_material_id, manual_writeoff_cut_width_mm, manual_writeoff_cut_height_mm, manual_writeoff_quantity, processing_method) VALUES (468, 200, 30, 'Бутылка с металл крышкой УФ-печать', 'piece', NULL, NULL, NULL, NULL, NULL, NULL, 5, 450.0, FALSE, FALSE, FALSE, NULL, NULL, NULL, NULL, NULL);
INSERT INTO order_items (id, order_id, product_id, product_name_snapshot, product_unit_snapshot, product_formula_snapshot, product_formula_script_snapshot, raw_material_id, raw_material_qty, cut_width_mm, cut_height_mm, quantity, unit_price, is_completed, is_printed, manual_writeoff_pending, manual_writeoff_raw_material_id, manual_writeoff_cut_width_mm, manual_writeoff_cut_height_mm, manual_writeoff_quantity, processing_method) VALUES (403, 185, NULL, 'Футболки от заказчика 2 шт. с ДТФ печатью', 'шт', NULL, NULL, NULL, NULL, NULL, NULL, 2, 0.0, TRUE, FALSE, FALSE, NULL, NULL, NULL, NULL, NULL);
INSERT INTO order_items (id, order_id, product_id, product_name_snapshot, product_unit_snapshot, product_formula_snapshot, product_formula_script_snapshot, raw_material_id, raw_material_qty, cut_width_mm, cut_height_mm, quantity, unit_price, is_completed, is_printed, manual_writeoff_pending, manual_writeoff_raw_material_id, manual_writeoff_cut_width_mm, manual_writeoff_cut_height_mm, manual_writeoff_quantity, processing_method) VALUES (459, 190, 32, 'Копирование листовок А5, 150г, 4+4', 'шт', NULL, NULL, NULL, NULL, NULL, NULL, 1000, 21.0, FALSE, FALSE, FALSE, NULL, NULL, NULL, NULL, NULL);
INSERT INTO order_items (id, order_id, product_id, product_name_snapshot, product_unit_snapshot, product_formula_snapshot, product_formula_script_snapshot, raw_material_id, raw_material_qty, cut_width_mm, cut_height_mm, quantity, unit_price, is_completed, is_printed, manual_writeoff_pending, manual_writeoff_raw_material_id, manual_writeoff_cut_width_mm, manual_writeoff_cut_height_mm, manual_writeoff_quantity, processing_method) VALUES (451, 194, NULL, 'Карточки', 'шт', NULL, NULL, NULL, NULL, 90.0, 40.0, 8, 0.0, TRUE, TRUE, FALSE, NULL, NULL, NULL, NULL, NULL);
INSERT INTO order_items (id, order_id, product_id, product_name_snapshot, product_unit_snapshot, product_formula_snapshot, product_formula_script_snapshot, raw_material_id, raw_material_qty, cut_width_mm, cut_height_mm, quantity, unit_price, is_completed, is_printed, manual_writeoff_pending, manual_writeoff_raw_material_id, manual_writeoff_cut_width_mm, manual_writeoff_cut_height_mm, manual_writeoff_quantity, processing_method) VALUES (464, 197, NULL, 'Самоклейка 1.3м наклейки ', 'шт', NULL, NULL, NULL, NULL, 90.0, 41.0, 10, 0.0, TRUE, TRUE, FALSE, NULL, NULL, NULL, NULL, NULL);
INSERT INTO order_items (id, order_id, product_id, product_name_snapshot, product_unit_snapshot, product_formula_snapshot, product_formula_script_snapshot, raw_material_id, raw_material_qty, cut_width_mm, cut_height_mm, quantity, unit_price, is_completed, is_printed, manual_writeoff_pending, manual_writeoff_raw_material_id, manual_writeoff_cut_width_mm, manual_writeoff_cut_height_mm, manual_writeoff_quantity, processing_method) VALUES (417, 189, NULL, 'Футболки 90 шт. с ДТФ печатью, 2 нанесения на груди, футболки белые наши', 'шт', NULL, NULL, NULL, NULL, NULL, NULL, 90, 0.0, FALSE, FALSE, FALSE, NULL, NULL, NULL, NULL, NULL);
INSERT INTO order_items (id, order_id, product_id, product_name_snapshot, product_unit_snapshot, product_formula_snapshot, product_formula_script_snapshot, raw_material_id, raw_material_qty, cut_width_mm, cut_height_mm, quantity, unit_price, is_completed, is_printed, manual_writeoff_pending, manual_writeoff_raw_material_id, manual_writeoff_cut_width_mm, manual_writeoff_cut_height_mm, manual_writeoff_quantity, processing_method) VALUES (418, 189, NULL, 'Зонты 19 шт с ДТФ печатью', 'шт', NULL, NULL, NULL, NULL, NULL, NULL, 19, 0.0, FALSE, FALSE, FALSE, NULL, NULL, NULL, NULL, NULL);
INSERT INTO order_items (id, order_id, product_id, product_name_snapshot, product_unit_snapshot, product_formula_snapshot, product_formula_script_snapshot, raw_material_id, raw_material_qty, cut_width_mm, cut_height_mm, quantity, unit_price, is_completed, is_printed, manual_writeoff_pending, manual_writeoff_raw_material_id, manual_writeoff_cut_width_mm, manual_writeoff_cut_height_mm, manual_writeoff_quantity, processing_method) VALUES (469, 199, NULL, 'Брелоки прозрачный пластик 2 мм с УФ печатью', 'шт', NULL, NULL, NULL, NULL, NULL, NULL, 160, 40.0, FALSE, FALSE, FALSE, NULL, NULL, NULL, NULL, NULL);
INSERT INTO order_items (id, order_id, product_id, product_name_snapshot, product_unit_snapshot, product_formula_snapshot, product_formula_script_snapshot, raw_material_id, raw_material_qty, cut_width_mm, cut_height_mm, quantity, unit_price, is_completed, is_printed, manual_writeoff_pending, manual_writeoff_raw_material_id, manual_writeoff_cut_width_mm, manual_writeoff_cut_height_mm, manual_writeoff_quantity, processing_method) VALUES (421, 188, NULL, 'Таблички ПВХ 3мм', 'шт', NULL, NULL, NULL, NULL, 300.0, 60.0, 4, 71.0, FALSE, FALSE, FALSE, NULL, NULL, NULL, NULL, 'Ручная резка');
INSERT INTO order_items (id, order_id, product_id, product_name_snapshot, product_unit_snapshot, product_formula_snapshot, product_formula_script_snapshot, raw_material_id, raw_material_qty, cut_width_mm, cut_height_mm, quantity, unit_price, is_completed, is_printed, manual_writeoff_pending, manual_writeoff_raw_material_id, manual_writeoff_cut_width_mm, manual_writeoff_cut_height_mm, manual_writeoff_quantity, processing_method) VALUES (422, 188, NULL, 'Таблички ПВХ 3мм ', 'шт', NULL, NULL, NULL, NULL, 300.0, 120.0, 14, 22.0, FALSE, FALSE, FALSE, NULL, NULL, NULL, NULL, NULL);
INSERT INTO order_items (id, order_id, product_id, product_name_snapshot, product_unit_snapshot, product_formula_snapshot, product_formula_script_snapshot, raw_material_id, raw_material_qty, cut_width_mm, cut_height_mm, quantity, unit_price, is_completed, is_printed, manual_writeoff_pending, manual_writeoff_raw_material_id, manual_writeoff_cut_width_mm, manual_writeoff_cut_height_mm, manual_writeoff_quantity, processing_method) VALUES (423, 188, NULL, 'Самоклейка 1.3м Наклейки на стекло', 'шт', NULL, NULL, NULL, NULL, NULL, NULL, 19, 0.0, FALSE, FALSE, FALSE, NULL, NULL, NULL, NULL, NULL);
INSERT INTO order_items (id, order_id, product_id, product_name_snapshot, product_unit_snapshot, product_formula_snapshot, product_formula_script_snapshot, raw_material_id, raw_material_qty, cut_width_mm, cut_height_mm, quantity, unit_price, is_completed, is_printed, manual_writeoff_pending, manual_writeoff_raw_material_id, manual_writeoff_cut_width_mm, manual_writeoff_cut_height_mm, manual_writeoff_quantity, processing_method) VALUES (424, 188, NULL, 'Таблички ПВХ 3мм', 'шт', NULL, NULL, NULL, NULL, 100.0, 60.0, 69, 136.0, FALSE, FALSE, FALSE, NULL, NULL, NULL, NULL, NULL);
INSERT INTO order_items (id, order_id, product_id, product_name_snapshot, product_unit_snapshot, product_formula_snapshot, product_formula_script_snapshot, raw_material_id, raw_material_qty, cut_width_mm, cut_height_mm, quantity, unit_price, is_completed, is_printed, manual_writeoff_pending, manual_writeoff_raw_material_id, manual_writeoff_cut_width_mm, manual_writeoff_cut_height_mm, manual_writeoff_quantity, processing_method) VALUES (470, 199, NULL, 'Значок закатной 38мм', 'шт', NULL, NULL, NULL, NULL, NULL, NULL, 160, 75.0, FALSE, FALSE, FALSE, NULL, NULL, NULL, NULL, NULL);
INSERT INTO order_items (id, order_id, product_id, product_name_snapshot, product_unit_snapshot, product_formula_snapshot, product_formula_script_snapshot, raw_material_id, raw_material_qty, cut_width_mm, cut_height_mm, quantity, unit_price, is_completed, is_printed, manual_writeoff_pending, manual_writeoff_raw_material_id, manual_writeoff_cut_width_mm, manual_writeoff_cut_height_mm, manual_writeoff_quantity, processing_method) VALUES (452, 195, NULL, 'Таблички ', 'шт', NULL, NULL, NULL, NULL, NULL, NULL, 4, 0.0, FALSE, TRUE, FALSE, NULL, NULL, NULL, NULL, NULL);
SELECT setval(''order_items_id_seq'::regclass', 470);

DROP SEQUENCE IF EXISTS 'order_settings_id_seq'::regclass CASCADE;
CREATE SEQUENCE 'order_settings_id_seq'::regclass START WITH 33 INCREMENT BY 1 NO MINVALUE NO MAXVALUE CACHE 1;
DROP TABLE IF EXISTS order_settings CASCADE;
CREATE TABLE order_settings (
  id integer NOT NULL,
  setting_type character varying(50) NOT NULL,
  name character varying(255) NOT NULL,
  color character varying(20) NOT NULL,
  sort_order integer NOT NULL,
  PRIMARY KEY (id)
);
ALTER TABLE order_settings ALTER COLUMN id SET DEFAULT nextval(''order_settings_id_seq'::regclass'::regclass);
INSERT INTO order_settings (id, setting_type, name, color, sort_order) VALUES (2, 'status_color', 'В работе', '#fa8c16', 0);
INSERT INTO order_settings (id, setting_type, name, color, sort_order) VALUES (3, 'status_color', 'Готов', '#52c41a', 0);
INSERT INTO order_settings (id, setting_type, name, color, sort_order) VALUES (4, 'status_color', 'Отдали', '#8c8c8c', 0);
INSERT INTO order_settings (id, setting_type, name, color, sort_order) VALUES (31, 'designer_color', 'Sergey', 'rgb(255,126,0)', 3);
INSERT INTO order_settings (id, setting_type, name, color, sort_order) VALUES (32, 'source', 'МАХ', 'rgb(120,120,120)', 2);
INSERT INTO order_settings (id, setting_type, name, color, sort_order) VALUES (33, 'source', 'Почта', 'rgb(143,171,210)', 3);
INSERT INTO order_settings (id, setting_type, name, color, sort_order) VALUES (30, 'designer_color', 'Maya', 'rgb(221,87,154)', 2);
INSERT INTO order_settings (id, setting_type, name, color, sort_order) VALUES (1, 'status_color', 'Новый', 'rgb(246,59,59)', 0);
INSERT INTO order_settings (id, setting_type, name, color, sort_order) VALUES (15, 'source', 'вк', '#1677ff', 0);
INSERT INTO order_settings (id, setting_type, name, color, sort_order) VALUES (16, 'source', 'тг', 'rgb(123,22,255)', 1);
INSERT INTO order_settings (id, setting_type, name, color, sort_order) VALUES (18, 'layout', 'Не взят', 'rgb(226,0,4)', 0);
INSERT INTO order_settings (id, setting_type, name, color, sort_order) VALUES (21, 'worker_color', 'Ко и Ри и Се', 'rgb(3,182,143)', 4);
INSERT INTO order_settings (id, setting_type, name, color, sort_order) VALUES (12, 'worker_color', 'Ко и Се', 'rgb(3,182,143)', 5);
INSERT INTO order_settings (id, setting_type, name, color, sort_order) VALUES (22, 'worker_color', 'Ко и Ри', 'rgb(3,182,143)', 3);
INSERT INTO order_settings (id, setting_type, name, color, sort_order) VALUES (23, 'worker_color', 'Ри и Се', 'rgb(3,182,143)', 4);
INSERT INTO order_settings (id, setting_type, name, color, sort_order) VALUES (24, 'worker_color', 'Константин', 'rgb(3,182,143)', 5);
INSERT INTO order_settings (id, setting_type, name, color, sort_order) VALUES (25, 'worker_color', 'Ринат', 'rgb(3,182,143)', 6);
INSERT INTO order_settings (id, setting_type, name, color, sort_order) VALUES (26, 'worker_color', 'Сергей', 'rgb(3,182,143)', 7);
INSERT INTO order_settings (id, setting_type, name, color, sort_order) VALUES (27, 'worker_color', 'Настя и Ирина', 'rgb(22,127,255)', 8);
INSERT INTO order_settings (id, setting_type, name, color, sort_order) VALUES (20, 'layout', 'Утвержден', 'rgb(0,210,32)', 2);
INSERT INTO order_settings (id, setting_type, name, color, sort_order) VALUES (28, 'designer_color', 'Alena', '#1677ff', 1);
INSERT INTO order_settings (id, setting_type, name, color, sort_order) VALUES (29, 'designer_color', 'Alexandra', 'rgb(205,22,255)', 1);
INSERT INTO order_settings (id, setting_type, name, color, sort_order) VALUES (19, 'layout', 'В работе', 'rgba(0,47,255,0.77)', 1);
SELECT setval(''order_settings_id_seq'::regclass', 33);

DROP SEQUENCE IF EXISTS 'order_templates_id_seq'::regclass CASCADE;
CREATE SEQUENCE 'order_templates_id_seq'::regclass START WITH 1 INCREMENT BY 1 NO MINVALUE NO MAXVALUE CACHE 1;
DROP TABLE IF EXISTS order_templates CASCADE;
CREATE TABLE order_templates (
  id integer NOT NULL,
  name character varying(255) NOT NULL,
  items json NOT NULL,
  created_by integer,
  PRIMARY KEY (id)
);
ALTER TABLE order_templates ALTER COLUMN id SET DEFAULT nextval(''order_templates_id_seq'::regclass'::regclass);
SELECT setval(''order_templates_id_seq'::regclass', 0);

DROP SEQUENCE IF EXISTS 'orders_id_seq'::regclass CASCADE;
CREATE SEQUENCE 'orders_id_seq'::regclass START WITH 200 INCREMENT BY 1 NO MINVALUE NO MAXVALUE CACHE 1;
DROP TABLE IF EXISTS orders CASCADE;
CREATE TABLE orders (
  id integer NOT NULL,
  client_id integer NOT NULL,
  total_price double precision NOT NULL,
  status character varying(50) NOT NULL,
  description text,
  notes text,
  deadline timestamp with time zone,
  designer character varying(255),
  workers text,
  layout_type character varying(100),
  path text,
  source character varying(100),
  created_by integer,
  created_by_name character varying(255),
  created_by_role character varying(100),
  created_at timestamp with time zone NOT NULL DEFAULT now(),
  updated_at timestamp with time zone NOT NULL DEFAULT now(),
  deadline_start timestamp with time zone,
  PRIMARY KEY (id)
);
ALTER TABLE orders ALTER COLUMN id SET DEFAULT nextval(''orders_id_seq'::regclass'::regclass);
INSERT INTO orders (id, client_id, total_price, status, description, notes, deadline, designer, workers, layout_type, path, source, created_by, created_by_name, created_by_role, created_at, updated_at, deadline_start) VALUES (194, 28, 0.0, 'delivered', 'Карточки 300гр, мат, 1+0', NULL, '2026-07-08T21:00:00+00:00', 'Maya', '["Константин"]', 'Утвержден', '\\\\192.168.1.150\\bufer\\!!!\\Алла визитки\\карточки\\В печать\\еще', 'МАХ', 12, 'Майя', 'designer', '2026-07-09T07:47:07.342896+00:00', '2026-07-09T10:34:34.960220+00:00', '2026-07-08T21:00:00+00:00');
INSERT INTO orders (id, client_id, total_price, status, description, notes, deadline, designer, workers, layout_type, path, source, created_by, created_by_name, created_by_role, created_at, updated_at, deadline_start) VALUES (191, 40, 0.0, 'new', 'Флешки 16гб, уф печать - 40шт
Блокнот А6, пружина сверху, блок с печатью 1+0, задник без печати- 400шт
Лупа уф печать-150шт', NULL, '2026-07-19T21:00:00+00:00', 'Maya', '["Ко и Ри и Се"]', 'Утвержден', '\\\\192.168.1.150\\bufer\\Первые\\Юнаты\\Флешки
\\\\192.168.1.150\\bufer\\Первые\\Юнаты\\Лупа
\\\\192.168.1.150\\bufer\\Первые\\Юнаты\\Блокнот А6\\в печать', 'МАХ', 12, 'Майя', 'designer', '2026-07-08T13:12:17.352266+00:00', '2026-07-09T09:16:39.206392+00:00', '2026-07-19T21:00:00+00:00');
INSERT INTO orders (id, client_id, total_price, status, description, notes, deadline, designer, workers, layout_type, path, source, created_by, created_by_name, created_by_role, created_at, updated_at, deadline_start) VALUES (177, 25, 14400.0, 'delivered', 'Попсокет 160 шт, УФ печать', 'Сдать до пятницы, сначала сделать 1 пробный', '2026-07-09T21:00:00+00:00', 'Alexandra', '["Ри и Се"]', 'Утвержден', '\\\\192.168.1.150\\bufer\\Детский лагерь\\Попсокет', 'МАХ', 11, 'Александра', 'designer', '2026-07-08T08:35:05.638849+00:00', '2026-07-09T10:41:25.483283+00:00', '2026-07-07T21:00:00+00:00');
INSERT INTO orders (id, client_id, total_price, status, description, notes, deadline, designer, workers, layout_type, path, source, created_by, created_by_name, created_by_role, created_at, updated_at, deadline_start) VALUES (179, 29, 0.0, 'new', 'Визитки 4+4, бумага перламутровая светло-серая — 200 шт
4+4, бумага перламутровая светло-серая с фольгированием — 250 шт
Конверт — 100 шт
Таблички ПВХ 3мм — 2 шт', NULL, '2026-07-16T21:00:00+00:00', 'Sergey', '["Ко и Се"]', 'Утвержден', '\\\\192.168.1.150\\bufer\\ИвГУ\\17.07.26\\Визитки
\\\\192.168.1.150\\bufer\\ИвГУ\\17.07.26\\конверты
\\\\192.168.1.150\\bufer\\ИвГУ\\17.07.26\\ПВХ', 'МАХ', 13, 'Сергей', 'designer', '2026-07-08T10:29:22.173935+00:00', '2026-07-08T10:37:01.830871+00:00', NULL);
INSERT INTO orders (id, client_id, total_price, status, description, notes, deadline, designer, workers, layout_type, path, source, created_by, created_by_name, created_by_role, created_at, updated_at, deadline_start) VALUES (180, 30, 39180.0, 'new', 'Стенд ПВХ 3мм, 1400х1750мм
Карманы 10х15см
Табличка 100х75см пвх 3мм с глянцевой ламинацией 
', NULL, '2026-07-16T21:00:00+00:00', 'Maya', '["Ко и Се"]', 'Утвержден', '\\\\192.168.1.150\\bufer\\Школы\\Школа 58\\Стенд', 'вк', 12, 'Майя', 'designer', '2026-07-08T11:11:37.434211+00:00', '2026-07-08T11:41:32.814846+00:00', NULL);
INSERT INTO orders (id, client_id, total_price, status, description, notes, deadline, designer, workers, layout_type, path, source, created_by, created_by_name, created_by_role, created_at, updated_at, deadline_start) VALUES (176, 24, 27847.0, 'new', NULL, NULL, '2026-07-25T21:00:00+00:00', 'Sergey', NULL, NULL, NULL, 'МАХ', 9, 'Дмитрий', 'manager', '2026-07-07T10:06:59.432764+00:00', '2026-07-09T09:31:16.338823+00:00', NULL);
INSERT INTO orders (id, client_id, total_price, status, description, notes, deadline, designer, workers, layout_type, path, source, created_by, created_by_name, created_by_role, created_at, updated_at, deadline_start) VALUES (188, 37, 9976.0, 'new', 'Таблички ПВХ 3мм  — 14 шт
Таблички ПВХ 3мм — 69 шт
Таблички ПВХ 3мм — 4 шт
Самоклейка 1.3м Наклейки на стекло — 19 шт', NULL, '2026-07-30T21:00:00+00:00', 'Sergey', '["Константин"]', 'Утвержден', '\\\\192.168.1.150\\bufer\\Анатолий\\08.07.26', 'вк', 13, 'Сергей', 'designer', '2026-07-08T12:07:39.195630+00:00', '2026-07-09T09:01:39.456291+00:00', '2026-07-07T21:00:00+00:00');
INSERT INTO orders (id, client_id, total_price, status, description, notes, deadline, designer, workers, layout_type, path, source, created_by, created_by_name, created_by_role, created_at, updated_at, deadline_start) VALUES (192, 42, 0.0, 'delivered', 'Ремень и обложка для паспорта Уф печать ', NULL, '2026-07-09T15:00:00+00:00', 'Alena', '["Sergey", "Ри и Се"]', 'Утвержден', '\\\\192.168.1.150\\bufer\\Михаил Муравьёв\\Ремень и обложка на паспорт\\08.07.26', 'вк', 10, 'Алёна', 'designer', '2026-07-08T13:34:18.697159+00:00', '2026-07-09T11:00:23.687595+00:00', '2026-07-09T15:00:00+00:00');
INSERT INTO orders (id, client_id, total_price, status, description, notes, deadline, designer, workers, layout_type, path, source, created_by, created_by_name, created_by_role, created_at, updated_at, deadline_start) VALUES (182, 31, 0.0, 'new', 'Футболки 10 шт. с ДТФ печатью', 'Нанесение на спине размер -
Нанесение на груди - размер', '2026-07-12T21:00:00+00:00', 'Alexandra', '["Настя и Ирина"]', 'В работе', NULL, 'МАХ', 11, 'Александра', 'designer', '2026-07-08T11:32:44.466849+00:00', '2026-07-08T12:15:06.458386+00:00', '2026-07-07T21:00:00+00:00');
INSERT INTO orders (id, client_id, total_price, status, description, notes, deadline, designer, workers, layout_type, path, source, created_by, created_by_name, created_by_role, created_at, updated_at, deadline_start) VALUES (195, 45, 0.0, 'in_progress', 'Таблички прозрачный пластик 2 мм + белый пластик 2мм - 4шт. (1 табличка с карманом 200х40мм)', NULL, '2026-07-09T15:00:00+00:00', 'Alena', '["Сергей"]', 'Утвержден', '\\\\192.168.1.150\\bufer\\Тубдиспансер\\Таблички\\Режим работы и таблички проз и белый пластик\\уф печать все таблички', 'МАХ', 10, 'Алёна', 'designer', '2026-07-09T08:31:59.994080+00:00', '2026-07-09T15:32:51.503369+00:00', '2026-07-09T15:00:00+00:00');
INSERT INTO orders (id, client_id, total_price, status, description, notes, deadline, designer, workers, layout_type, path, source, created_by, created_by_name, created_by_role, created_at, updated_at, deadline_start) VALUES (196, 46, 0.0, 'ready', NULL, NULL, '2026-07-09T15:00:00+00:00', 'Sergey', '["Константин"]', 'Утвержден', '\\\\192.168.1.150\\bufer\\KWS\\Наклейки', 'МАХ', 13, 'Сергей', 'designer', '2026-07-09T09:51:40.550520+00:00', '2026-07-09T13:49:56.019794+00:00', '2026-07-09T15:00:00+00:00');
INSERT INTO orders (id, client_id, total_price, status, description, notes, deadline, designer, workers, layout_type, path, source, created_by, created_by_name, created_by_role, created_at, updated_at, deadline_start) VALUES (189, 39, 0.0, 'new', NULL, NULL, '2026-07-30T21:00:00+00:00', 'Alexandra', '["Настя и Ирина"]', 'Утвержден', NULL, 'МАХ', 11, 'Александра', 'designer', '2026-07-08T12:21:51.566737+00:00', '2026-07-08T12:22:51.012288+00:00', '2026-07-07T21:00:00+00:00');
INSERT INTO orders (id, client_id, total_price, status, description, notes, deadline, designer, workers, layout_type, path, source, created_by, created_by_name, created_by_role, created_at, updated_at, deadline_start) VALUES (183, 33, 0.0, 'ready', 'Карточки 10х6см, бумага 200 гр мат, 4+0 — 210 шт', 'Карточки 10х6см, припуски 3мм, 4+0 на SRA3, бумага 200 гр мат, 240 шт', '2026-07-07T21:00:00+00:00', 'Alexandra', '["Константин"]', 'Утвержден', '\\\\192.168.1.150\\bufer\\Холсты Лусине Любовь Кротость\\Карточки\\08.07.26', 'вк', 11, 'Александра', 'designer', '2026-07-08T11:38:15.031401+00:00', '2026-07-08T15:02:01.379778+00:00', '2026-07-07T21:00:00+00:00');
INSERT INTO orders (id, client_id, total_price, status, description, notes, deadline, designer, workers, layout_type, path, source, created_by, created_by_name, created_by_role, created_at, updated_at, deadline_start) VALUES (193, 43, 0.0, 'delivered', NULL, NULL, NULL, NULL, '["Сергей"]', 'Утвержден', '\\\\192.168.1.150\\bufer\\Валерия\\8.07.26', 'вк', 1, 'Administrator', 'admin', '2026-07-08T14:50:30.221381+00:00', '2026-07-09T09:02:56.389053+00:00', NULL);
INSERT INTO orders (id, client_id, total_price, status, description, notes, deadline, designer, workers, layout_type, path, source, created_by, created_by_name, created_by_role, created_at, updated_at, deadline_start) VALUES (178, 28, 152.0, 'delivered', 'Карточки 90х40мм, бумага 300гр, мат, 1+0', NULL, '2026-07-07T21:00:00+00:00', 'Maya', '["Ко и Се"]', 'Утвержден', '\\\\192.168.1.150\\bufer\\!!!\\Алла визитки\\карточки\\В печать', 'МАХ', 12, 'Майя', 'designer', '2026-07-08T09:35:39.727628+00:00', '2026-07-08T12:43:33.196952+00:00', NULL);
INSERT INTO orders (id, client_id, total_price, status, description, notes, deadline, designer, workers, layout_type, path, source, created_by, created_by_name, created_by_role, created_at, updated_at, deadline_start) VALUES (190, 38, 1000.0, 'delivered', 'Копирование листовок А5, печать каждой по 50шт (1000шт)', 'НЕ ХВАТАЕТ 1 СКАНА!', '2026-07-09T08:00:00+00:00', 'Maya', NULL, 'Утвержден', '\\\\192.168.1.150\\bufer\\Елена (с улицы)\\В печать', NULL, 9, 'Дмитрий', 'manager', '2026-07-08T12:33:11.750276+00:00', '2026-07-09T10:34:43.762454+00:00', '2026-07-07T21:00:00+00:00');
INSERT INTO orders (id, client_id, total_price, status, description, notes, deadline, designer, workers, layout_type, path, source, created_by, created_by_name, created_by_role, created_at, updated_at, deadline_start) VALUES (181, 26, 0.0, 'delivered', NULL, 'В папке цифра будет еще одна папка от 07.07, как подготовлю файлы, подойду и скажу, их тоже надо будет запустить, поэтому карточку не закрывай пожалуйста', '2026-07-09T21:00:00+00:00', 'Alexandra', '["Константин"]', 'Утвержден', '\\\\192.168.1.150\\bufer\\Сироткин\\08.07.26', 'МАХ', 11, 'Александра', 'designer', '2026-07-08T11:27:57.846387+00:00', '2026-07-09T11:00:10.970831+00:00', '2026-07-07T21:00:00+00:00');
INSERT INTO orders (id, client_id, total_price, status, description, notes, deadline, designer, workers, layout_type, path, source, created_by, created_by_name, created_by_role, created_at, updated_at, deadline_start) VALUES (186, 35, 45.0, 'ready', 'Медали — 45 шт', NULL, '2026-07-09T21:00:00+00:00', 'Sergey', '["Ри и Се", "Настя и Ирина"]', 'Утвержден', '\\\\192.168.1.150\\bufer\\Рома Каменщиков\\медали 6х6', 'вк', 1, 'Administrator', 'admin', '2026-07-08T11:53:08.270397+00:00', '2026-07-09T11:05:14.272370+00:00', '2026-07-09T21:00:00+00:00');
INSERT INTO orders (id, client_id, total_price, status, description, notes, deadline, designer, workers, layout_type, path, source, created_by, created_by_name, created_by_role, created_at, updated_at, deadline_start) VALUES (185, 34, 0.0, 'ready', 'Футболки от заказчика 2 шт. фиолетовая и черная с ДТФ печатью', NULL, '2026-07-08T21:00:00+00:00', 'Alexandra', '["Настя и Ирина"]', 'В работе', NULL, 'МАХ', 11, 'Александра', 'designer', '2026-07-08T11:47:05.952632+00:00', '2026-07-09T14:39:56.653377+00:00', '2026-07-07T21:00:00+00:00');
INSERT INTO orders (id, client_id, total_price, status, description, notes, deadline, designer, workers, layout_type, path, source, created_by, created_by_name, created_by_role, created_at, updated_at, deadline_start) VALUES (187, 36, 4875.0, 'new', 'ПВХ 5мм. таблички  — 5 шт. Размер 1000х260мм
Композит таблички дырочками 4 шт диаметр 8мм — 1 шт. Размер 1000х260мм (суворова) ИЗ МАКСА
Билеты — 250 шт. 115гр глянец, 4+0', 'Проверить размеры табличек и изменить по необходимости ', '2026-07-15T21:00:00+00:00', 'Alena', '["Константин"]', 'Утвержден', '\\\\192.168.1.150\\bufer\\ИГЭУ\\Антонюк\\Аншлаги
\\\\192.168.1.150\\bufer\\Харинка\\Билеты Харинка', 'вк', 9, 'Дмитрий', 'manager', '2026-07-08T12:06:30.119643+00:00', '2026-07-09T11:10:51.110819+00:00', '2026-07-07T21:00:00+00:00');
INSERT INTO orders (id, client_id, total_price, status, description, notes, deadline, designer, workers, layout_type, path, source, created_by, created_by_name, created_by_role, created_at, updated_at, deadline_start) VALUES (198, 48, 0.0, 'new', NULL, NULL, '2026-07-10T15:00:00+00:00', 'Sergey', '["Константин"]', 'Утвержден', '\\\\192.168.1.150\\bufer\\Олимпиец\\Плакаты', 'МАХ', 13, 'Сергей', 'designer', '2026-07-09T12:50:17.492816+00:00', '2026-07-09T12:50:17.492816+00:00', '2026-07-10T15:00:00+00:00');
INSERT INTO orders (id, client_id, total_price, status, description, notes, deadline, designer, workers, layout_type, path, source, created_by, created_by_name, created_by_role, created_at, updated_at, deadline_start) VALUES (197, 47, 0.0, 'ready', NULL, NULL, '2026-07-09T15:00:00+00:00', 'Sergey', '["Константин"]', 'Утвержден', '\\\\192.168.1.150\\bufer\\Serovski\\Наклейки 09.07.26', 'МАХ', 13, 'Сергей', 'designer', '2026-07-09T11:36:12.170209+00:00', '2026-07-09T13:20:32.150613+00:00', '2026-07-09T15:00:00+00:00');
INSERT INTO orders (id, client_id, total_price, status, description, notes, deadline, designer, workers, layout_type, path, source, created_by, created_by_name, created_by_role, created_at, updated_at, deadline_start) VALUES (200, 49, 3360.0, 'new', NULL, NULL, NULL, 'Sergey', NULL, 'Не взят', NULL, 'вк', 9, 'Дмитрий', 'manager', '2026-07-09T14:16:30.879231+00:00', '2026-07-09T14:40:14.610227+00:00', NULL);
INSERT INTO orders (id, client_id, total_price, status, description, notes, deadline, designer, workers, layout_type, path, source, created_by, created_by_name, created_by_role, created_at, updated_at, deadline_start) VALUES (199, 25, 18400.0, 'new', 'Брелоки 160 шт, прозрачный пластик 2 мм с УФ печатью', NULL, '2026-07-09T21:00:00+00:00', 'Alexandra', '["Сергей"]', 'Утвержден', '\\\\192.168.1.150\\bufer\\Детский лагерь\\Брелок\\Брелоки спортивные 2026', 'МАХ', 11, 'Александра', 'designer', '2026-07-09T12:53:13.875631+00:00', '2026-07-09T14:41:45.343851+00:00', '2026-07-08T21:00:00+00:00');
SELECT setval(''orders_id_seq'::regclass', 200);

DROP SEQUENCE IF EXISTS 'permissions_id_seq'::regclass CASCADE;
CREATE SEQUENCE 'permissions_id_seq'::regclass START WITH 23 INCREMENT BY 1 NO MINVALUE NO MAXVALUE CACHE 1;
DROP TABLE IF EXISTS permissions CASCADE;
CREATE TABLE permissions (
  id integer NOT NULL,
  name character varying(100) NOT NULL,
  description character varying(255),
  PRIMARY KEY (id)
);
ALTER TABLE permissions ALTER COLUMN id SET DEFAULT nextval(''permissions_id_seq'::regclass'::regclass);
INSERT INTO permissions (id, name, description) VALUES (1, 'clients.view', 'View clients');
INSERT INTO permissions (id, name, description) VALUES (2, 'clients.create', 'Create clients');
INSERT INTO permissions (id, name, description) VALUES (3, 'clients.edit', 'Edit clients');
INSERT INTO permissions (id, name, description) VALUES (4, 'clients.delete', 'Delete clients');
INSERT INTO permissions (id, name, description) VALUES (5, 'products.view', 'View products');
INSERT INTO permissions (id, name, description) VALUES (6, 'products.create', 'Create products');
INSERT INTO permissions (id, name, description) VALUES (7, 'products.edit', 'Edit products');
INSERT INTO permissions (id, name, description) VALUES (8, 'products.delete', 'Delete products');
INSERT INTO permissions (id, name, description) VALUES (9, 'orders.view', 'View orders');
INSERT INTO permissions (id, name, description) VALUES (10, 'orders.create', 'Create orders');
INSERT INTO permissions (id, name, description) VALUES (11, 'orders.edit', 'Edit orders');
INSERT INTO permissions (id, name, description) VALUES (12, 'orders.delete', 'Delete orders');
INSERT INTO permissions (id, name, description) VALUES (13, 'warehouse.view', 'View warehouse');
INSERT INTO permissions (id, name, description) VALUES (14, 'warehouse.create', 'Create warehouse items');
INSERT INTO permissions (id, name, description) VALUES (15, 'warehouse.edit', 'Edit warehouse items');
INSERT INTO permissions (id, name, description) VALUES (16, 'warehouse.delete', 'Delete warehouse items');
INSERT INTO permissions (id, name, description) VALUES (17, 'hermes.view', 'View hermes agents');
INSERT INTO permissions (id, name, description) VALUES (18, 'hermes.manage', 'Manage hermes agents');
INSERT INTO permissions (id, name, description) VALUES (19, 'users.view', 'View users');
INSERT INTO permissions (id, name, description) VALUES (20, 'users.manage', 'Manage users');
INSERT INTO permissions (id, name, description) VALUES (21, 'roles.manage', 'Manage roles');
INSERT INTO permissions (id, name, description) VALUES (22, 'prices.view', 'View prices');
INSERT INTO permissions (id, name, description) VALUES (23, 'prices.revenue', 'View total revenue');
SELECT setval(''permissions_id_seq'::regclass', 23);

DROP SEQUENCE IF EXISTS 'product_raw_materials_id_seq'::regclass CASCADE;
CREATE SEQUENCE 'product_raw_materials_id_seq'::regclass START WITH 11 INCREMENT BY 1 NO MINVALUE NO MAXVALUE CACHE 1;
DROP TABLE IF EXISTS product_raw_materials CASCADE;
CREATE TABLE product_raw_materials (
  id integer NOT NULL,
  product_id integer NOT NULL,
  raw_material_id integer NOT NULL,
  coefficient double precision NOT NULL,
  PRIMARY KEY (id)
);
ALTER TABLE product_raw_materials ALTER COLUMN id SET DEFAULT nextval(''product_raw_materials_id_seq'::regclass'::regclass);
INSERT INTO product_raw_materials (id, product_id, raw_material_id, coefficient) VALUES (11, 39, 9, 1.0);
SELECT setval(''product_raw_materials_id_seq'::regclass', 11);

DROP SEQUENCE IF EXISTS 'products_id_seq'::regclass CASCADE;
CREATE SEQUENCE 'products_id_seq'::regclass START WITH 39 INCREMENT BY 1 NO MINVALUE NO MAXVALUE CACHE 1;
DROP TABLE IF EXISTS products CASCADE;
CREATE TABLE products (
  id integer NOT NULL,
  name character varying(255) NOT NULL,
  description text,
  unit_price double precision NOT NULL,
  unit_type character varying(50) NOT NULL,
  category character varying(100),
  formula text,
  formula_script character varying(255),
  raw_material_id integer,
  material_coefficient double precision NOT NULL,
  created_at timestamp with time zone NOT NULL DEFAULT now(),
  supplier_url character varying(500),
  default_cut_width_mm double precision,
  default_cut_height_mm double precision,
  PRIMARY KEY (id)
);
ALTER TABLE products ALTER COLUMN id SET DEFAULT nextval(''products_id_seq'::regclass'::regclass);
INSERT INTO products (id, name, description, unit_price, unit_type, category, formula, formula_script, raw_material_id, material_coefficient, created_at, supplier_url, default_cut_width_mm, default_cut_height_mm) VALUES (27, 'Попсокет', NULL, 90.0, 'piece', NULL, NULL, NULL, NULL, 1.0, '2026-07-08T08:40:27.739298+00:00', 'https://www.oasiscatalog.com/item/1-000037943', NULL, NULL);
INSERT INTO products (id, name, description, unit_price, unit_type, category, formula, formula_script, raw_material_id, material_coefficient, created_at, supplier_url, default_cut_width_mm, default_cut_height_mm) VALUES (28, 'Канрандаш', 'карандаш с цветной уф-печатью с одной стороны', 45.0, 'piece', NULL, NULL, NULL, NULL, 1.0, '2026-07-08T12:50:04.725071+00:00', 'https://www.oasiscatalog.com/item/1-000096232', NULL, NULL);
INSERT INTO products (id, name, description, unit_price, unit_type, category, formula, formula_script, raw_material_id, material_coefficient, created_at, supplier_url, default_cut_width_mm, default_cut_height_mm) VALUES (29, 'Бутылка с гравировкой на крышке', NULL, 395.0, 'piece', NULL, NULL, NULL, NULL, 1.0, '2026-07-08T12:55:54.609957+00:00', 'https://www.oasiscatalog.com/item/1-000058567', NULL, NULL);
INSERT INTO products (id, name, description, unit_price, unit_type, category, formula, formula_script, raw_material_id, material_coefficient, created_at, supplier_url, default_cut_width_mm, default_cut_height_mm) VALUES (30, 'Бутылка с металл крышкой УФ-печать', NULL, 450.0, 'piece', NULL, NULL, NULL, NULL, 1.0, '2026-07-08T13:03:03.529969+00:00', 'https://www.oasiscatalog.com/item/1-000058567', NULL, NULL);
INSERT INTO products (id, name, description, unit_price, unit_type, category, formula, formula_script, raw_material_id, material_coefficient, created_at, supplier_url, default_cut_width_mm, default_cut_height_mm) VALUES (31, 'Бутылка пластик прозрачная', 'пластик с уф-печатью ', 400.0, 'piece', NULL, NULL, NULL, NULL, 1.0, '2026-07-08T13:06:01.812195+00:00', 'https://www.oasiscatalog.com/item/1-000037895', NULL, NULL);
INSERT INTO products (id, name, description, unit_price, unit_type, category, formula, formula_script, raw_material_id, material_coefficient, created_at, supplier_url, default_cut_width_mm, default_cut_height_mm) VALUES (32, 'Копирование листовок А5, 150г, 4+4', NULL, 1.0, 'шт', NULL, NULL, NULL, NULL, 1.0, '2026-07-08T15:31:50.453370+00:00', NULL, NULL, NULL);
INSERT INTO products (id, name, description, unit_price, unit_type, category, formula, formula_script, raw_material_id, material_coefficient, created_at, supplier_url, default_cut_width_mm, default_cut_height_mm) VALUES (33, 'Кружка сублимация станд.', NULL, 270.0, 'piece', NULL, NULL, NULL, NULL, 1.0, '2026-07-09T07:58:54.635094+00:00', 'https://zenonline.ru/cat/00000098574', NULL, NULL);
INSERT INTO products (id, name, description, unit_price, unit_type, category, formula, formula_script, raw_material_id, material_coefficient, created_at, supplier_url, default_cut_width_mm, default_cut_height_mm) VALUES (34, 'Кружка сублимация станд. с коробкой', NULL, 305.0, 'piece', NULL, NULL, NULL, NULL, 1.0, '2026-07-09T08:00:17.133914+00:00', 'https://zenonline.ru/cat/00000098574', NULL, NULL);
INSERT INTO products (id, name, description, unit_price, unit_type, category, formula, formula_script, raw_material_id, material_coefficient, created_at, supplier_url, default_cut_width_mm, default_cut_height_mm) VALUES (35, 'Кружка сублимация станд. с коробкой, наклейка 8х8см', NULL, 313.0, 'piece', NULL, NULL, NULL, NULL, 1.0, '2026-07-09T08:39:15.391236+00:00', 'https://zenonline.ru/cat/00000098574', NULL, NULL);
INSERT INTO products (id, name, description, unit_price, unit_type, category, formula, formula_script, raw_material_id, material_coefficient, created_at, supplier_url, default_cut_width_mm, default_cut_height_mm) VALUES (36, 'ручка пластик уф-печать с 1 стороны', NULL, 85.0, 'piece', NULL, NULL, NULL, NULL, 1.0, '2026-07-09T08:50:49.404294+00:00', 'https://vivagifts.ru/catalog/plastikovye-ruchki/', NULL, NULL);
INSERT INTO products (id, name, description, unit_price, unit_type, category, formula, formula_script, raw_material_id, material_coefficient, created_at, supplier_url, default_cut_width_mm, default_cut_height_mm) VALUES (38, 'вымпел А5 субл. 4+4', NULL, 585.0, 'piece', NULL, NULL, NULL, NULL, 1.0, '2026-07-09T09:19:21.595091+00:00', 'https://zenonline.ru/cat/00000041199', NULL, NULL);
INSERT INTO products (id, name, description, unit_price, unit_type, category, formula, formula_script, raw_material_id, material_coefficient, created_at, supplier_url, default_cut_width_mm, default_cut_height_mm) VALUES (37, 'вымпел А5 субл. 4+0', NULL, 340.0, 'piece', NULL, NULL, NULL, NULL, 1.0, '2026-07-09T09:18:29.113326+00:00', 'https://zenonline.ru/cat/00000041199', NULL, NULL);
INSERT INTO products (id, name, description, unit_price, unit_type, category, formula, formula_script, raw_material_id, material_coefficient, created_at, supplier_url, default_cut_width_mm, default_cut_height_mm) VALUES (39, 'Печать А4, 250г, 4+0', 'дипломы/грамоты/сертификаты/благодарности 
плотность - 250г
Цвет - 4+0', 45.0, 'piece', 'Печать', NULL, NULL, 9, 1.0, '2026-07-09T09:44:08.670949+00:00', NULL, NULL, NULL);
SELECT setval(''products_id_seq'::regclass', 39);

DROP SEQUENCE IF EXISTS 'raw_materials_id_seq'::regclass CASCADE;
CREATE SEQUENCE 'raw_materials_id_seq'::regclass START WITH 13 INCREMENT BY 1 NO MINVALUE NO MAXVALUE CACHE 1;
DROP TABLE IF EXISTS raw_materials CASCADE;
CREATE TABLE raw_materials (
  id integer NOT NULL,
  name character varying(255) NOT NULL,
  description text,
  width_mm integer,
  height_mm integer,
  roll_width_m double precision,
  roll_length_m double precision,
  density character varying(100),
  color_finish character varying(100),
  unit_type character varying(50) NOT NULL,
  unit_price double precision NOT NULL,
  display_format_script character varying(255),
  created_at timestamp with time zone NOT NULL DEFAULT now(),
  stock_calculation_script character varying(255),
  PRIMARY KEY (id)
);
ALTER TABLE raw_materials ALTER COLUMN id SET DEFAULT nextval(''raw_materials_id_seq'::regclass'::regclass);
INSERT INTO raw_materials (id, name, description, width_mm, height_mm, roll_width_m, roll_length_m, density, color_finish, unit_type, unit_price, display_format_script, created_at, stock_calculation_script) VALUES (10, 'Акрил 4 мм Белый', NULL, 3000, 2000, NULL, NULL, NULL, NULL, 'sheet', 0.0, NULL, '2026-07-08T10:59:17.040241+00:00', NULL);
INSERT INTO raw_materials (id, name, description, width_mm, height_mm, roll_width_m, roll_length_m, density, color_finish, unit_type, unit_price, display_format_script, created_at, stock_calculation_script) VALUES (9, 'Бумага SRA3, 300г, мат', NULL, 320, 450, NULL, NULL, '300', 'матовый', 'sheet', 0.0, NULL, '2026-07-08T10:11:40.874904+00:00', NULL);
INSERT INTO raw_materials (id, name, description, width_mm, height_mm, roll_width_m, roll_length_m, density, color_finish, unit_type, unit_price, display_format_script, created_at, stock_calculation_script) VALUES (11, 'Бумага SRA3 250г, мат', 'Бумага SRA3 250г, мат', 320, 450, NULL, NULL, '250', 'матовый', 'sheet', 0.0, NULL, '2026-07-09T09:45:14.717948+00:00', NULL);
INSERT INTO raw_materials (id, name, description, width_mm, height_mm, roll_width_m, roll_length_m, density, color_finish, unit_type, unit_price, display_format_script, created_at, stock_calculation_script) VALUES (12, 'Бумага SRA3 250г, глянц', NULL, 320, 450, NULL, NULL, '250', 'глянцевый', 'sheet', 0.0, NULL, '2026-07-09T09:46:33.013050+00:00', NULL);
INSERT INTO raw_materials (id, name, description, width_mm, height_mm, roll_width_m, roll_length_m, density, color_finish, unit_type, unit_price, display_format_script, created_at, stock_calculation_script) VALUES (13, 'Бумага SRA3, 300г, глянц', NULL, 320, 450, NULL, NULL, '300', 'глянцевый', 'sheet', 0.0, NULL, '2026-07-09T09:47:47.958288+00:00', NULL);
SELECT setval(''raw_materials_id_seq'::regclass', 13);

DROP TABLE IF EXISTS role_permissions CASCADE;
CREATE TABLE role_permissions (
  role_id integer NOT NULL,
  permission_id integer NOT NULL,
  PRIMARY KEY (role_id, permission_id)
);
INSERT INTO role_permissions (role_id, permission_id) VALUES (1, 1);
INSERT INTO role_permissions (role_id, permission_id) VALUES (2, 1);
INSERT INTO role_permissions (role_id, permission_id) VALUES (3, 1);
INSERT INTO role_permissions (role_id, permission_id) VALUES (4, 1);
INSERT INTO role_permissions (role_id, permission_id) VALUES (6, 1);
INSERT INTO role_permissions (role_id, permission_id) VALUES (1, 5);
INSERT INTO role_permissions (role_id, permission_id) VALUES (2, 5);
INSERT INTO role_permissions (role_id, permission_id) VALUES (3, 5);
INSERT INTO role_permissions (role_id, permission_id) VALUES (4, 5);
INSERT INTO role_permissions (role_id, permission_id) VALUES (5, 5);
INSERT INTO role_permissions (role_id, permission_id) VALUES (6, 5);
INSERT INTO role_permissions (role_id, permission_id) VALUES (1, 18);
INSERT INTO role_permissions (role_id, permission_id) VALUES (2, 18);
INSERT INTO role_permissions (role_id, permission_id) VALUES (1, 11);
INSERT INTO role_permissions (role_id, permission_id) VALUES (2, 11);
INSERT INTO role_permissions (role_id, permission_id) VALUES (3, 11);
INSERT INTO role_permissions (role_id, permission_id) VALUES (1, 2);
INSERT INTO role_permissions (role_id, permission_id) VALUES (2, 2);
INSERT INTO role_permissions (role_id, permission_id) VALUES (3, 2);
INSERT INTO role_permissions (role_id, permission_id) VALUES (1, 6);
INSERT INTO role_permissions (role_id, permission_id) VALUES (2, 6);
INSERT INTO role_permissions (role_id, permission_id) VALUES (3, 6);
INSERT INTO role_permissions (role_id, permission_id) VALUES (1, 19);
INSERT INTO role_permissions (role_id, permission_id) VALUES (2, 19);
INSERT INTO role_permissions (role_id, permission_id) VALUES (4, 19);
INSERT INTO role_permissions (role_id, permission_id) VALUES (6, 19);
INSERT INTO role_permissions (role_id, permission_id) VALUES (1, 13);
INSERT INTO role_permissions (role_id, permission_id) VALUES (2, 13);
INSERT INTO role_permissions (role_id, permission_id) VALUES (4, 13);
INSERT INTO role_permissions (role_id, permission_id) VALUES (5, 13);
INSERT INTO role_permissions (role_id, permission_id) VALUES (6, 13);
INSERT INTO role_permissions (role_id, permission_id) VALUES (1, 20);
INSERT INTO role_permissions (role_id, permission_id) VALUES (1, 12);
INSERT INTO role_permissions (role_id, permission_id) VALUES (2, 12);
INSERT INTO role_permissions (role_id, permission_id) VALUES (1, 7);
INSERT INTO role_permissions (role_id, permission_id) VALUES (2, 7);
INSERT INTO role_permissions (role_id, permission_id) VALUES (3, 7);
INSERT INTO role_permissions (role_id, permission_id) VALUES (1, 21);
INSERT INTO role_permissions (role_id, permission_id) VALUES (1, 14);
INSERT INTO role_permissions (role_id, permission_id) VALUES (2, 14);
INSERT INTO role_permissions (role_id, permission_id) VALUES (1, 8);
INSERT INTO role_permissions (role_id, permission_id) VALUES (2, 8);
INSERT INTO role_permissions (role_id, permission_id) VALUES (1, 22);
INSERT INTO role_permissions (role_id, permission_id) VALUES (2, 22);
INSERT INTO role_permissions (role_id, permission_id) VALUES (1, 3);
INSERT INTO role_permissions (role_id, permission_id) VALUES (2, 3);
INSERT INTO role_permissions (role_id, permission_id) VALUES (3, 3);
INSERT INTO role_permissions (role_id, permission_id) VALUES (1, 15);
INSERT INTO role_permissions (role_id, permission_id) VALUES (2, 15);
INSERT INTO role_permissions (role_id, permission_id) VALUES (5, 15);
INSERT INTO role_permissions (role_id, permission_id) VALUES (1, 9);
INSERT INTO role_permissions (role_id, permission_id) VALUES (2, 9);
INSERT INTO role_permissions (role_id, permission_id) VALUES (3, 9);
INSERT INTO role_permissions (role_id, permission_id) VALUES (4, 9);
INSERT INTO role_permissions (role_id, permission_id) VALUES (6, 9);
INSERT INTO role_permissions (role_id, permission_id) VALUES (1, 23);
INSERT INTO role_permissions (role_id, permission_id) VALUES (2, 23);
INSERT INTO role_permissions (role_id, permission_id) VALUES (1, 16);
INSERT INTO role_permissions (role_id, permission_id) VALUES (2, 16);
INSERT INTO role_permissions (role_id, permission_id) VALUES (1, 4);
INSERT INTO role_permissions (role_id, permission_id) VALUES (2, 4);
INSERT INTO role_permissions (role_id, permission_id) VALUES (1, 17);
INSERT INTO role_permissions (role_id, permission_id) VALUES (2, 17);
INSERT INTO role_permissions (role_id, permission_id) VALUES (4, 17);
INSERT INTO role_permissions (role_id, permission_id) VALUES (6, 17);
INSERT INTO role_permissions (role_id, permission_id) VALUES (1, 10);
INSERT INTO role_permissions (role_id, permission_id) VALUES (2, 10);
INSERT INTO role_permissions (role_id, permission_id) VALUES (3, 10);
INSERT INTO role_permissions (role_id, permission_id) VALUES (4, 12);
INSERT INTO role_permissions (role_id, permission_id) VALUES (4, 10);
INSERT INTO role_permissions (role_id, permission_id) VALUES (4, 11);
INSERT INTO role_permissions (role_id, permission_id) VALUES (3, 13);
INSERT INTO role_permissions (role_id, permission_id) VALUES (3, 4);
INSERT INTO role_permissions (role_id, permission_id) VALUES (3, 8);
INSERT INTO role_permissions (role_id, permission_id) VALUES (3, 12);
INSERT INTO role_permissions (role_id, permission_id) VALUES (3, 19);
INSERT INTO role_permissions (role_id, permission_id) VALUES (5, 9);
INSERT INTO role_permissions (role_id, permission_id) VALUES (5, 11);
INSERT INTO role_permissions (role_id, permission_id) VALUES (3, 22);

DROP SEQUENCE IF EXISTS 'roles_id_seq'::regclass CASCADE;
CREATE SEQUENCE 'roles_id_seq'::regclass START WITH 6 INCREMENT BY 1 NO MINVALUE NO MAXVALUE CACHE 1;
DROP TABLE IF EXISTS roles CASCADE;
CREATE TABLE roles (
  id integer NOT NULL,
  name character varying(100) NOT NULL,
  description character varying(255),
  PRIMARY KEY (id)
);
ALTER TABLE roles ALTER COLUMN id SET DEFAULT nextval(''roles_id_seq'::regclass'::regclass);
INSERT INTO roles (id, name, description) VALUES (1, 'admin', 'Администратор');
INSERT INTO roles (id, name, description) VALUES (2, 'director', 'Руководитель');
INSERT INTO roles (id, name, description) VALUES (3, 'manager', 'Менеджер');
INSERT INTO roles (id, name, description) VALUES (4, 'designer', 'Дизайнер');
INSERT INTO roles (id, name, description) VALUES (5, 'production', 'Работник производства');
INSERT INTO roles (id, name, description) VALUES (6, 'user', 'Пользователь');
SELECT setval(''roles_id_seq'::regclass', 6);

DROP SEQUENCE IF EXISTS 'stock_writeoffs_id_seq'::regclass CASCADE;
CREATE SEQUENCE 'stock_writeoffs_id_seq'::regclass START WITH 114 INCREMENT BY 1 NO MINVALUE NO MAXVALUE CACHE 1;
DROP TABLE IF EXISTS stock_writeoffs CASCADE;
CREATE TABLE stock_writeoffs (
  id integer NOT NULL,
  item_type character varying(20) NOT NULL,
  product_id integer,
  raw_material_id integer,
  quantity double precision NOT NULL,
  reason text,
  created_by integer,
  created_by_name character varying(255),
  created_at timestamp with time zone NOT NULL DEFAULT now(),
  order_id integer,
  remaining_width double precision,
  remaining_height double precision,
  PRIMARY KEY (id)
);
ALTER TABLE stock_writeoffs ALTER COLUMN id SET DEFAULT nextval(''stock_writeoffs_id_seq'::regclass'::regclass);
INSERT INTO stock_writeoffs (id, item_type, product_id, raw_material_id, quantity, reason, created_by, created_by_name, created_at, order_id, remaining_width, remaining_height) VALUES (110, 'product', 27, NULL, 160.0, 'Заказ #177', NULL, NULL, '2026-07-08T16:32:29.718147+00:00', 177, NULL, NULL);
INSERT INTO stock_writeoffs (id, item_type, product_id, raw_material_id, quantity, reason, created_by, created_by_name, created_at, order_id, remaining_width, remaining_height) VALUES (112, 'product', 32, NULL, 1000.0, 'Заказ #190', NULL, NULL, '2026-07-09T09:30:40.455788+00:00', 190, NULL, NULL);
INSERT INTO stock_writeoffs (id, item_type, product_id, raw_material_id, quantity, reason, created_by, created_by_name, created_at, order_id, remaining_width, remaining_height) VALUES (114, 'raw_material', NULL, 10, 1.0, 'Использован обрезок 1300.0×900.0 мм для заказа #186', 9, 'Дмитрий', '2026-07-09T11:05:14.283525+00:00', 186, 1300.0, 693.0);
INSERT INTO stock_writeoffs (id, item_type, product_id, raw_material_id, quantity, reason, created_by, created_by_name, created_at, order_id, remaining_width, remaining_height) VALUES (104, 'raw_material', NULL, 9, 1.0, 'Заказ #178', NULL, NULL, '2026-07-08T11:16:49.928954+00:00', 178, NULL, NULL);
INSERT INTO stock_writeoffs (id, item_type, product_id, raw_material_id, quantity, reason, created_by, created_by_name, created_at, order_id, remaining_width, remaining_height) VALUES (109, 'raw_material', NULL, 10, 1.0, 'Заказ #186', NULL, NULL, '2026-07-08T14:21:21.026832+00:00', 186, NULL, NULL);
INSERT INTO stock_writeoffs (id, item_type, product_id, raw_material_id, quantity, reason, created_by, created_by_name, created_at, order_id, remaining_width, remaining_height) VALUES (113, 'raw_material', NULL, 10, 1.0, 'Использован обрезок 1300.0×900.0 мм для заказа #186', 9, 'Дмитрий', '2026-07-09T09:31:19.560392+00:00', 186, 1300.0, 693.0);
SELECT setval(''stock_writeoffs_id_seq'::regclass', 114);

DROP SEQUENCE IF EXISTS 'test_restore_id_seq'::regclass CASCADE;
CREATE SEQUENCE 'test_restore_id_seq'::regclass START WITH 2 INCREMENT BY 1 NO MINVALUE NO MAXVALUE CACHE 1;
DROP TABLE IF EXISTS test_restore CASCADE;
CREATE TABLE test_restore (
  id integer NOT NULL,
  name text,
  PRIMARY KEY (id)
);
ALTER TABLE test_restore ALTER COLUMN id SET DEFAULT nextval(''test_restore_id_seq'::regclass'::regclass);
INSERT INTO test_restore (id, name) VALUES (1, 'hello');
INSERT INTO test_restore (id, name) VALUES (2, 'world');
SELECT setval(''test_restore_id_seq'::regclass', 2);

DROP SEQUENCE IF EXISTS 'user_filter_states_id_seq'::regclass CASCADE;
CREATE SEQUENCE 'user_filter_states_id_seq'::regclass START WITH 24 INCREMENT BY 1 NO MINVALUE NO MAXVALUE CACHE 1;
DROP TABLE IF EXISTS user_filter_states CASCADE;
CREATE TABLE user_filter_states (
  id integer NOT NULL,
  user_id integer NOT NULL,
  entity character varying(50) NOT NULL,
  filters text NOT NULL,
  sort_field character varying(100),
  sort_direction character varying(10) NOT NULL,
  search character varying(255),
  created_at timestamp with time zone NOT NULL DEFAULT now(),
  updated_at timestamp with time zone NOT NULL DEFAULT now(),
  PRIMARY KEY (id)
);
ALTER TABLE user_filter_states ALTER COLUMN id SET DEFAULT nextval(''user_filter_states_id_seq'::regclass'::regclass);
INSERT INTO user_filter_states (id, user_id, entity, filters, sort_field, sort_direction, search, created_at, updated_at) VALUES (3, 1, 'products', '{}', NULL, 'asc', '', '2026-06-24T12:44:45+00:00', '2026-06-24T12:44:47+00:00');
INSERT INTO user_filter_states (id, user_id, entity, filters, sort_field, sort_direction, search, created_at, updated_at) VALUES (4, 1, 'clients', '{}', 'id', 'desc', '', '2026-06-24T13:10:47+00:00', '2026-06-27T12:29:03.724117+00:00');
INSERT INTO user_filter_states (id, user_id, entity, filters, sort_field, sort_direction, search, created_at, updated_at) VALUES (17, 15, 'orders', '{"workers": ["Ко и Ри", "Ко и Ри и Се", "Ри и Се", "Ринат", "Сергей"], "status": ["new", "in_progress"]}', NULL, 'asc', '', '2026-07-08T09:32:26.535764+00:00', '2026-07-09T13:50:49.297111+00:00');
INSERT INTO user_filter_states (id, user_id, entity, filters, sort_field, sort_direction, search, created_at, updated_at) VALUES (19, 9, 'dashboard', '{"status": null}', NULL, 'asc', '', '2026-07-08T10:04:44.638079+00:00', '2026-07-09T14:02:58.643200+00:00');
INSERT INTO user_filter_states (id, user_id, entity, filters, sort_field, sort_direction, search, created_at, updated_at) VALUES (5, 3, 'dashboard', '{"status": "ready"}', NULL, 'asc', '', '2026-06-29T08:48:18.096940+00:00', '2026-06-29T09:17:52.546126+00:00');
INSERT INTO user_filter_states (id, user_id, entity, filters, sort_field, sort_direction, search, created_at, updated_at) VALUES (1, 1, 'dashboard', '{"status": "ready"}', NULL, 'asc', '', '2026-06-23T21:09:24+00:00', '2026-07-09T14:27:06.974992+00:00');
INSERT INTO user_filter_states (id, user_id, entity, filters, sort_field, sort_direction, search, created_at, updated_at) VALUES (24, 9, 'rawMaterials', '{"name": null}', 'name', 'asc', '', '2026-07-09T09:45:46.550102+00:00', '2026-07-09T09:45:46.550102+00:00');
INSERT INTO user_filter_states (id, user_id, entity, filters, sort_field, sort_direction, search, created_at, updated_at) VALUES (8, 6, 'orders', '{"status": ["new", "in_progress"]}', NULL, 'asc', '', '2026-07-03T11:27:16.764938+00:00', '2026-07-03T11:27:16.764938+00:00');
INSERT INTO user_filter_states (id, user_id, entity, filters, sort_field, sort_direction, search, created_at, updated_at) VALUES (14, 12, 'dashboard', '{"status": null}', NULL, 'asc', '', '2026-07-07T11:47:39.062666+00:00', '2026-07-07T11:47:39.062666+00:00');
INSERT INTO user_filter_states (id, user_id, entity, filters, sort_field, sort_direction, search, created_at, updated_at) VALUES (9, 4, 'dashboard', '{"status": null}', NULL, 'asc', '', '2026-07-03T14:26:31.977940+00:00', '2026-07-03T14:26:40.359694+00:00');
INSERT INTO user_filter_states (id, user_id, entity, filters, sort_field, sort_direction, search, created_at, updated_at) VALUES (2, 1, 'orders', '{"status": ["new", "in_progress"], "workers": ["Ко и Ри и Се", "Ко и Се", "Сергей", "Ри и Се"]}', 'deadline', 'asc', '', '2026-06-23T21:10:18+00:00', '2026-07-09T10:07:50.019581+00:00');
INSERT INTO user_filter_states (id, user_id, entity, filters, sort_field, sort_direction, search, created_at, updated_at) VALUES (7, 3, 'warehouse', '{"min_quantity": null}', 'quantity', 'asc', '', '2026-06-29T20:19:54.096399+00:00', '2026-06-29T20:19:54.096399+00:00');
INSERT INTO user_filter_states (id, user_id, entity, filters, sort_field, sort_direction, search, created_at, updated_at) VALUES (12, 9, 'orders', '{"status": ["new", "in_progress", "ready"]}', NULL, 'asc', '', '2026-07-07T10:10:30.785270+00:00', '2026-07-09T14:38:13.140575+00:00');
INSERT INTO user_filter_states (id, user_id, entity, filters, sort_field, sort_direction, search, created_at, updated_at) VALUES (6, 3, 'orders', '{"status": ["new", "in_progress"]}', 'id', 'desc', '', '2026-06-29T20:17:52.802360+00:00', '2026-07-01T15:39:57.576911+00:00');
INSERT INTO user_filter_states (id, user_id, entity, filters, sort_field, sort_direction, search, created_at, updated_at) VALUES (20, 13, 'orders', '{}', NULL, 'asc', '', '2026-07-08T11:05:04.492364+00:00', '2026-07-08T11:05:04.492364+00:00');
INSERT INTO user_filter_states (id, user_id, entity, filters, sort_field, sort_direction, search, created_at, updated_at) VALUES (16, 14, 'orders', '{"status": ["new", "in_progress"], "workers": ["Ко и Ри", "Ко и Ри и Се", "Ко и Се", "Константин"]}', 'deadline', 'desc', '', '2026-07-08T08:54:40.311993+00:00', '2026-07-08T11:18:38.887927+00:00');
INSERT INTO user_filter_states (id, user_id, entity, filters, sort_field, sort_direction, search, created_at, updated_at) VALUES (22, 1, 'warehouse', '{"min_quantity": null}', 'id', 'asc', '', '2026-07-08T20:19:51.582629+00:00', '2026-07-08T20:19:56.644176+00:00');
INSERT INTO user_filter_states (id, user_id, entity, filters, sort_field, sort_direction, search, created_at, updated_at) VALUES (23, 8, 'dashboard', '{"status": "delivered"}', NULL, 'asc', '', '2026-07-09T07:24:09.642165+00:00', '2026-07-09T07:24:09.642165+00:00');
INSERT INTO user_filter_states (id, user_id, entity, filters, sort_field, sort_direction, search, created_at, updated_at) VALUES (15, 11, 'orders', '{"designer": ["Alexandra"], "status": ["ready", "in_progress", "new", "delivered"]}', 'deadline', 'asc', '', '2026-07-08T08:28:30.580303+00:00', '2026-07-09T11:41:30.758064+00:00');
INSERT INTO user_filter_states (id, user_id, entity, filters, sort_field, sort_direction, search, created_at, updated_at) VALUES (10, 1, 'archive', '{}', NULL, 'asc', '', '2026-07-06T16:28:52.433955+00:00', '2026-07-06T16:38:00.213975+00:00');
INSERT INTO user_filter_states (id, user_id, entity, filters, sort_field, sort_direction, search, created_at, updated_at) VALUES (18, 9, 'clients', '{}', 'name', 'asc', '', '2026-07-08T10:04:30.130189+00:00', '2026-07-09T11:45:49.565033+00:00');
INSERT INTO user_filter_states (id, user_id, entity, filters, sort_field, sort_direction, search, created_at, updated_at) VALUES (21, 16, 'orders', '{"status": ["new", "in_progress"], "workers": ["Настя и Ирина"]}', NULL, 'asc', '', '2026-07-08T12:14:48.650407+00:00', '2026-07-08T12:15:11.536997+00:00');
INSERT INTO user_filter_states (id, user_id, entity, filters, sort_field, sort_direction, search, created_at, updated_at) VALUES (11, 14, 'dashboard', '{"status": null}', NULL, 'asc', '', '2026-07-07T08:29:15.825959+00:00', '2026-07-07T08:29:30.142938+00:00');
INSERT INTO user_filter_states (id, user_id, entity, filters, sort_field, sort_direction, search, created_at, updated_at) VALUES (13, 10, 'orders', '{"status": ["in_progress", "new", "ready"], "designer": ["Alena", "Alexandra", "Maya", "Sergey"]}', 'deadline', 'asc', '', '2026-07-07T11:46:04.387151+00:00', '2026-07-09T13:13:40.105919+00:00');
SELECT setval(''user_filter_states_id_seq'::regclass', 24);

DROP TABLE IF EXISTS user_roles CASCADE;
CREATE TABLE user_roles (
  user_id integer NOT NULL,
  role_id integer NOT NULL,
  PRIMARY KEY (user_id, role_id)
);
INSERT INTO user_roles (user_id, role_id) VALUES (1, 1);
INSERT INTO user_roles (user_id, role_id) VALUES (7, 2);
INSERT INTO user_roles (user_id, role_id) VALUES (8, 3);
INSERT INTO user_roles (user_id, role_id) VALUES (9, 3);
INSERT INTO user_roles (user_id, role_id) VALUES (10, 4);
INSERT INTO user_roles (user_id, role_id) VALUES (11, 4);
INSERT INTO user_roles (user_id, role_id) VALUES (12, 4);
INSERT INTO user_roles (user_id, role_id) VALUES (13, 4);
INSERT INTO user_roles (user_id, role_id) VALUES (14, 5);
INSERT INTO user_roles (user_id, role_id) VALUES (15, 5);
INSERT INTO user_roles (user_id, role_id) VALUES (16, 5);

DROP SEQUENCE IF EXISTS 'users_id_seq'::regclass CASCADE;
CREATE SEQUENCE 'users_id_seq'::regclass START WITH 16 INCREMENT BY 1 NO MINVALUE NO MAXVALUE CACHE 1;
DROP TABLE IF EXISTS users CASCADE;
CREATE TABLE users (
  id integer NOT NULL,
  username character varying(100) NOT NULL,
  email character varying(255) NOT NULL,
  hashed_password character varying(500) NOT NULL,
  full_name character varying(255),
  is_active boolean NOT NULL,
  is_superuser boolean NOT NULL,
  created_at timestamp with time zone NOT NULL DEFAULT now(),
  PRIMARY KEY (id)
);
ALTER TABLE users ALTER COLUMN id SET DEFAULT nextval(''users_id_seq'::regclass'::regclass);
INSERT INTO users (id, username, email, hashed_password, full_name, is_active, is_superuser, created_at) VALUES (1, 'admin', 'admin@crm.local', '$2b$12$lwZB5yvBVsAGelkbSssFfObD.2MKvvzvqylWhGyT.70/gTGD/czTS', 'Administrator', TRUE, TRUE, '2026-06-23T21:06:56+00:00');
INSERT INTO users (id, username, email, hashed_password, full_name, is_active, is_superuser, created_at) VALUES (7, 'Natalya', 'tanatany@mail.ru', '$2b$12$cUGSuiVnQvfhAvmS4g5koueyIf.0/V94Fo9FJs0u4Q69FCEOxCKgy', 'Наталья', TRUE, FALSE, '2026-07-07T08:02:14.448430+00:00');
INSERT INTO users (id, username, email, hashed_password, full_name, is_active, is_superuser, created_at) VALUES (8, 'Darya', 't@t.com', '$2b$12$x1.lF4PUBYfQtP//btDCYud2VWwNt8zib5CSPf/AFDrmjn7MEO8se', 'Дарья', TRUE, FALSE, '2026-07-07T08:03:40.302832+00:00');
INSERT INTO users (id, username, email, hashed_password, full_name, is_active, is_superuser, created_at) VALUES (9, 'Dmitry', 't1@t.com', '$2b$12$q0ywQ6RqtqhYA28J.ly4yuyJFUEd.RNe3FbI9vM8IHeZKupCDi4U.', 'Дмитрий', TRUE, FALSE, '2026-07-07T08:05:00.956100+00:00');
INSERT INTO users (id, username, email, hashed_password, full_name, is_active, is_superuser, created_at) VALUES (10, 'Alena', 't3@t.com', '$2b$12$oeBFfdDmywj/3VUIm1SIyOZ5fdIK8Rn3jFCnV4xWm110/fqPOq06.', 'Алёна', TRUE, FALSE, '2026-07-07T08:07:20.538187+00:00');
INSERT INTO users (id, username, email, hashed_password, full_name, is_active, is_superuser, created_at) VALUES (11, 'Alexandra', 't4@t.com', '$2b$12$PxPi6BuKuXNnL6cH6.6NIOfMTluV4kOiWxSsbwQ/LjkfC8skQGScq', 'Александра', TRUE, FALSE, '2026-07-07T08:08:53.811995+00:00');
INSERT INTO users (id, username, email, hashed_password, full_name, is_active, is_superuser, created_at) VALUES (12, 'Maya', 't5@t.com', '$2b$12$KzUhm5lS/A7/bfrnWBWd7OXfCmuyjP9ovop9S3VtBe3xj7qILSSAa', 'Майя', TRUE, FALSE, '2026-07-07T08:10:10.832963+00:00');
INSERT INTO users (id, username, email, hashed_password, full_name, is_active, is_superuser, created_at) VALUES (13, 'Sergey', 't6@t.com', '$2b$12$yy35qVBESBJSCKPaodvjJ.mD1TfqIwSf9YzOGHR6aUid1/CO83uHi', 'Сергей', TRUE, FALSE, '2026-07-07T08:11:11.949122+00:00');
INSERT INTO users (id, username, email, hashed_password, full_name, is_active, is_superuser, created_at) VALUES (14, 'Konstantin', 't7@t.com', '$2b$12$7Wfu/mfhQtN9yoHIIH1SguMTkulQQ/rtUPy4IPU26P61.Ty2B2QNa', 'Константин', TRUE, FALSE, '2026-07-07T08:12:56.250908+00:00');
INSERT INTO users (id, username, email, hashed_password, full_name, is_active, is_superuser, created_at) VALUES (15, 'Rinat', 't8@t.com', '$2b$12$7YncsPoCX6aIjw40sKndp.4lXgohTunekwfq4btKkIY0rY4Boh.cu', 'Ринат', TRUE, FALSE, '2026-07-07T08:14:54.314595+00:00');
INSERT INTO users (id, username, email, hashed_password, full_name, is_active, is_superuser, created_at) VALUES (16, 'Nastya_Irina', 't9@t.com', '$2b$12$nxutN9RwpKQMaO1GxrrYie6YPMtF1F5towiG/rY.qxLyr0MJ.ZRaG', 'Настя и Ирина', TRUE, FALSE, '2026-07-07T08:16:51.256928+00:00');
SELECT setval(''users_id_seq'::regclass', 16);

DROP SEQUENCE IF EXISTS 'warehouse_id_seq'::regclass CASCADE;
CREATE SEQUENCE 'warehouse_id_seq'::regclass START WITH 32 INCREMENT BY 1 NO MINVALUE NO MAXVALUE CACHE 1;
DROP TABLE IF EXISTS warehouse CASCADE;
CREATE TABLE warehouse (
  id integer NOT NULL,
  product_id integer,
  raw_material_id integer,
  quantity double precision NOT NULL,
  min_quantity integer NOT NULL,
  defective_quantity integer NOT NULL,
  defective_reason character varying(500),
  updated_at timestamp with time zone NOT NULL DEFAULT now(),
  stock_calculation_script character varying(255),
  display_format_script character varying(255),
  PRIMARY KEY (id)
);
ALTER TABLE warehouse ALTER COLUMN id SET DEFAULT nextval(''warehouse_id_seq'::regclass'::regclass);
INSERT INTO warehouse (id, product_id, raw_material_id, quantity, min_quantity, defective_quantity, defective_reason, updated_at, stock_calculation_script, display_format_script) VALUES (30, 27, NULL, 40.0, 100, 0, '', '2026-07-08T10:14:56.528296+00:00', NULL, NULL);
INSERT INTO warehouse (id, product_id, raw_material_id, quantity, min_quantity, defective_quantity, defective_reason, updated_at, stock_calculation_script, display_format_script) VALUES (31, NULL, 10, 0.0, 1, 0, '', '2026-07-08T14:21:21.026832+00:00', 'sheet_stock_calc_v2', 'sheet_stock_calc_v2');
INSERT INTO warehouse (id, product_id, raw_material_id, quantity, min_quantity, defective_quantity, defective_reason, updated_at, stock_calculation_script, display_format_script) VALUES (32, 32, NULL, 98999.0, 10, 0, '', '2026-07-09T09:30:40.455788+00:00', NULL, NULL);
INSERT INTO warehouse (id, product_id, raw_material_id, quantity, min_quantity, defective_quantity, defective_reason, updated_at, stock_calculation_script, display_format_script) VALUES (29, NULL, 9, 529.0, 100, 0, '', '2026-07-08T11:16:49.928954+00:00', 'sheet_stock_calc', 'sheet_stock_calc');
SELECT setval(''warehouse_id_seq'::regclass', 32);
